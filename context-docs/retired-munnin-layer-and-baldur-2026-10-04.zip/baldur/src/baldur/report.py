"""The basis text and the day report: what makes an estimate defensible.

The basis is stored with every proposal (day_proposals.basis) and Odin later posts it as the Jira
worklog comment, so a figure can be defended months later without re-deriving it. It is written at
proposal time from the evidence the estimator used, never reconstructed afterwards.

The day report matters more than the per-ticket numbers. It separates what was measured (meetings)
from what was estimated (development) and says plainly what Baldur cannot see.
"""
from __future__ import annotations

from datetime import tzinfo
from typing import Dict, List, Optional

from .estimate import DayEstimate, Params, TicketDay, tour_minutes

BLIND_SPOT = ("  Not visible to Baldur: design talk, reading code, messages, planning.\n"
              "  If the day felt fuller than this, that is the gap.")
DISCLAIMER = "These are estimates inferred from commit times, not measured time."


def hm(minutes: float) -> str:
    """1h30m, 45m, 0m. Always whole minutes, floored: a display must not round a figure up."""
    m = max(0, int(minutes))
    hours, rest = divmod(m, 60)
    if hours and rest:
        return "{}h{:02d}m".format(hours, rest)
    return "{}h00m".format(hours) if hours else "{}m".format(rest)


def _clock(moment, tz: tzinfo) -> str:
    return moment.astimezone(tz).strftime("%H:%M")


def basis_lines(ticket: TicketDay, day: DayEstimate, params: Params, tz: tzinfo,
                run_id: Optional[int] = None, already_in_jira: int = 0) -> List[str]:
    sessions = [s for s in day.sessions if s.id in ticket.session_ids]
    windows = ", ".join("{}-{}".format(_clock(s.start, tz), _clock(s.end, tz)) for s in sessions)
    model = params.describe() + (" (run {})".format(run_id) if run_id is not None else "")
    lines = [
        "Baldur estimate: {} for {} on {}".format(hm(ticket.minutes), ticket.key, day.day.isoformat()),
        "Basis: {} commit{} in {} session{} ({}), repo {}".format(
            len(ticket.shas), "" if len(ticket.shas) == 1 else "s", len(sessions),
            "" if len(sessions) == 1 else "s", windows, ", ".join(sorted(ticket.repos))),
        "Model: " + model,
    ]
    if day.meeting_minutes:
        lines.append("Meetings that day: {}, logged separately".format(hm(day.meeting_minutes)))
    if already_in_jira:
        lines.append("Already in Jira: {}; this worklog adds {}".format(
            hm(already_in_jira), hm(max(0, ticket.minutes - already_in_jira))))
    if day.capped_from is not None:
        lines.append("Day cap: {} scaled down to {}".format(hm(day.capped_from), hm(day.cap)))
    leads = sorted({s.start_from for s in sessions})
    if leads == ["lead-in"]:
        lines.append("Session starts: {}m lead-in (no reflog checkout)".format(params.lead_in_minutes))
    elif "reflog" in leads:
        lines.append("Session starts: reflog checkout" + (" and lead-in" if "lead-in" in leads else ""))
    return lines


def day_report_lines(day: DayEstimate, params: Params, tz: tzinfo,
                     already_in_jira: Optional[Dict[str, int]] = None,
                     pr_reviews: int = 0) -> List[str]:
    already = already_in_jira or {}
    dev = day.dev_minutes
    per = ", ".join("{} {}".format(k, hm(t.minutes)) for k, t in day.tickets.items())
    pending = {k: max(0, t.minutes - already.get(k, 0)) for k, t in day.tickets.items()}
    lines = ["{:<52}policy: {}".format(day.day.strftime("%a %Y-%m-%d"), day.policy)]
    if day.policy == "independent" and not day.meeting_minutes:
        lines.append("  Meetings (calendar)                    not known")
    else:
        lines.append("  Meetings (calendar)                    {:<8}Odin logs these separately".format(
            hm(day.meeting_minutes)))
    lines.append("  Development (estimated from git)       {:<8}{}".format(hm(dev), per))
    if already:
        lines.append("  Already in Jira for these tickets      {:<8}{}".format(
            hm(sum(already.values())), ", ".join(sorted(k for k, v in already.items() if v))))
    lines.append("  Odin will post once approved           {:<8}{}".format(
        hm(sum(pending.values())), ", ".join("{} {}".format(k, hm(v)) for k, v in pending.items() if v)))
    lines.append("  Untracked commits (no Jira key)        {}".format(hm(day.untracked_raw)))
    if pr_reviews:
        lines.append("  Pull request reviews (not logged)      {}".format(pr_reviews))
    lines.append("  " + "-" * 48)
    lines.append("  Accounted                              {}".format(hm(day.meeting_minutes + dev)))
    tour = tour_minutes(params)
    lines.append("  Tour of duty                           {:<8}{}-{}, {}m unpaid".format(
        hm(tour), params.tour_start, params.tour_end, params.unpaid_minutes))
    overlap = day.meeting_minutes + dev - tour
    if day.policy != "independent" and overlap > 0:
        lines.append("  Overlap assumed                        {:<8}coding during calls".format(hm(overlap)))
    for flag in day.flags:
        lines.append("  ! " + flag)
    lines.append("")
    lines.append(BLIND_SPOT)
    return lines
