"""Jira keys: what counts as one, and where to look for it.

Branches follow `feature/PROJ-123-short-name`, so a key is almost always there; the hard part is
finding it after the branch has been deleted. Each commit takes its keys from the FIRST source that
has any, most reliable first:

    1  reflog        the checkout that put you on the branch where the commit was made (90 days)
    2  branch        the commit is in `git log main..feature/PROJ-123-retry`
    3  pull_request  GitHub's head branch for the PR containing the commit (survives deletion)
    4  message       the commit message itself

A key matches `[A-Z][A-Z0-9]+-[1-9][0-9]*` AND its project is in `project_keys`. The project filter is
what stops `UTF-8`, `SHA-256` and `ISO-8601` from being read as tickets, and it is why an empty
`project_keys` is refused rather than read as "anything".
"""
from __future__ import annotations

import re
from typing import Iterable, List, Optional, Sequence, Tuple

from .errors import SetupError

SOURCES = ("reflog", "branch", "pull_request", "message")

# The leading guard stops a key glued to a longer word (vABC-1); the trailing guard stops a key
# followed by a letter or digit (ABC-1X). `-` and `_` may follow: `PROJ-123-add-filter`.
_KEY = re.compile(r"(?<![A-Za-z0-9])([A-Z][A-Z0-9]+)-([1-9][0-9]*)(?![0-9A-Za-z])")


class KeyError_(SetupError):
    """Unusable project_keys. Named so it cannot shadow the builtin KeyError."""


class KeyMatcher:
    def __init__(self, project_keys: Iterable[str]):
        projects = [str(p).strip().upper() for p in project_keys if str(p).strip()]
        if not projects:
            raise KeyError_(
                "project_keys is empty. List the Jira projects to recognise, e.g. "
                "[\"PROJ\", \"OPS\"]; otherwise UTF-8 and SHA-256 would be read as tickets.")
        for project in projects:
            if not re.fullmatch(r"[A-Z][A-Z0-9]+", project):
                raise KeyError_("{!r} is not a Jira project key such as PROJ.".format(project))
        self.projects = frozenset(projects)

    def find(self, text: Optional[str]) -> List[str]:
        """Every recognised key in text, in order of appearance, without repeats."""
        found: List[str] = []
        for match in _KEY.finditer(text or ""):
            if match.group(1) in self.projects:
                key = "{}-{}".format(match.group(1), match.group(2))
                if key not in found:
                    found.append(key)
        return found

    def resolve(self, reflog_branch: Optional[str] = None, branches: Sequence[str] = (),
                pr_head_branch: Optional[str] = None,
                message: Optional[str] = None) -> Tuple[List[str], Optional[str]]:
        """(keys, source) from the first source that yields any; ([], None) if untracked."""
        candidates = [
            ("reflog", [reflog_branch] if reflog_branch else []),
            ("branch", list(branches)),
            ("pull_request", [pr_head_branch] if pr_head_branch else []),
            ("message", [message] if message else []),
        ]
        for source, texts in candidates:
            keys: List[str] = []
            for text in texts:
                for key in self.find(text):
                    if key not in keys:
                        keys.append(key)
            if keys:
                return keys, source
        return [], None


def branch_from_checkout(message: Optional[str]) -> Optional[str]:
    """The branch a reflog checkout moved TO. `checkout: moving from main to feature/PROJ-1-x`."""
    match = re.search(r"checkout: moving from \S+ to (\S+)", message or "")
    return match.group(1) if match else None
