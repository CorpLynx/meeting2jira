"""Baldur's command line. The window (build step 7) will call the same service functions.

    python -m baldur init [--email me@agency.gov]   settings file + your git identity in Muninn
    python -m baldur collect [--days 30] [--full]   git -> Muninn
    python -m baldur report [--days 6]              estimate and show the day reports; writes nothing
    python -m baldur estimate [--days 6]            estimate and record proposals in Muninn
    python -m baldur doctor                         what is set up, and what is not

Exit codes: 0 ok, 1 finished with warnings, 2 setup or configuration problem, 130 interrupted.
Nothing here writes to Jira, ever. Approval happens in Baldur's window; Odin posts.
"""
from __future__ import annotations

import argparse
import logging
import sys
from datetime import datetime, timedelta, timezone
from typing import List, Optional

from . import __version__, collector, gitscan, service
from . import settings as settings_mod
from .errors import SetupError
from .muninn_link import MuninnUnavailable, open_baldur
from .report import DISCLAIMER, day_report_lines, hm

log = logging.getLogger("baldur")


def _parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="baldur", description="Development-time proposals from git.")
    p.add_argument("--version", action="version", version="baldur " + __version__)
    p.add_argument("-v", "--verbose", action="store_true")
    sub = p.add_subparsers(dest="command", required=True)
    init = sub.add_parser("init", help="create settings and record your git identity in Muninn")
    init.add_argument("--email", action="append", default=[], help="a git author e-mail of yours (repeatable)")
    col = sub.add_parser("collect", help="read your repositories into Muninn")
    col.add_argument("--days", type=int, help="only commits from the last N days")
    col.add_argument("--full", action="store_true", help="ignore the saved cursor and re-read everything")
    for name, text in (("report", "show day reports, write nothing"), ("estimate", "record proposals in Muninn")):
        cmd = sub.add_parser(name, help=text)
        cmd.add_argument("--days", type=int, default=6, help="days back from today (0 = today only)")
    sub.add_parser("doctor", help="check the setup")
    return p


def _setup_logging(verbose: bool) -> None:
    logging.basicConfig(level=logging.DEBUG if verbose else logging.INFO, format="%(message)s",
                        stream=sys.stdout)


def cmd_init(args: argparse.Namespace) -> int:
    settings = settings_mod.load()
    log.info("Settings: %s", settings_mod.settings_path())
    with open_baldur() as m:
        offered = [v for k, v in gitscan.git_identity() if k == "git_email"]
        emails = args.email or offered
        if not emails and not m.identity_values("git_email"):
            log.error("No e-mail given and none in `git config --global user.email`. Run:\n"
                      "  baldur init --email you@agency.gov")
            return 2
        for email in emails:
            added = m.add_identity("git_email", email)
            log.info("%s git identity %s", "Added" if added else "Already have", email)
        if args.email == [] and offered:
            log.info("(taken from your git config; re-run with --email to use a different one)")
    missing = [k for k in ("repo_roots", "project_keys") if not settings[k]]
    if missing:
        log.info("Next: set %s in %s.", " and ".join(missing), settings_mod.settings_path())
        return 1
    return 0


def cmd_collect(args: argparse.Namespace) -> int:
    settings = settings_mod.load()
    since = datetime.now(timezone.utc) - timedelta(days=args.days) if args.days else None
    with open_baldur() as m:
        result = collector.collect(m, settings, since=since, full=args.full)
    log.info("Collected %d repo(s): %d commit(s) seen, %d new, %d key link(s), %d untracked, %d reflog entries.",
             len(result.repos), result.commits_seen, result.commits_new, result.keys_linked,
             result.untracked, result.reflog_new)
    for warning in result.warnings:
        log.warning("  %s", warning)
    return 1 if result.warnings else 0


def cmd_estimate(args: argparse.Namespace, write: bool) -> int:
    settings = settings_mod.load()
    with open_baldur() as m:
        snap = service.compute(m, settings, args.days, write=write)
    params = settings.params()
    if not snap.days:
        log.info("No commits of yours between %s and %s. Run `baldur collect` first?", snap.date_from, snap.date_to)
    for day in snap.days:
        log.info("\n".join(day_report_lines(day, params, snap.tz)))
        log.info("")
    total = sum(d.dev_minutes for d in snap.days)
    log.info("%s across %d day(s).", hm(total), len(snap.days))
    if write:
        log.info("Recorded estimate run %s: %d new proposal(s), %d unchanged since the last run.",
                 snap.run_id, len(snap.proposed), len(snap.unchanged))
        log.info("Review and approve them in Baldur's window. Nothing is sent anywhere until you do.")
    for warning in snap.warnings + settings.warnings:
        log.warning("! %s", warning)
    log.info(DISCLAIMER)
    return 1 if snap.warnings else 0


def cmd_doctor(_: argparse.Namespace) -> int:
    problems: List[str] = []
    settings = settings_mod.load()
    log.info("Settings   %s", settings_mod.settings_path())
    for warning in settings.warnings:
        problems.append(warning)
    for key in ("repo_roots", "project_keys"):
        log.info("  %-13s %s", key, settings[key] or "(empty)")
        if not settings[key]:
            problems.append("{} is empty in baldur.json.".format(key))
    log.info("git        %s", "found" if gitscan.git_available() else "NOT FOUND")
    if not gitscan.git_available():
        problems.append("git is not on PATH.")
    try:
        with open_baldur() as m:
            log.info("Muninn     %s (schema v%s)", m.path, m.stats()["schema_version"])
            emails = sorted(m.identity_values("git_email"))
            log.info("Identity   %s", ", ".join(emails) or "(none)")
            if not emails:
                problems.append("No git identity: run `baldur init`.")
            calendar = m.conn.execute("SELECT count(*) FROM calendar_events").fetchone()[0]
            log.info("Calendar   %s", "{} event(s) from Odin".format(calendar) if calendar
                     else "none yet: days use the `independent` policy until Odin syncs to Muninn")
    except MuninnUnavailable as exc:
        problems.append(str(exc))
    for problem in problems:
        log.warning("! %s", problem)
    return 2 if problems else 0


def main(argv: Optional[List[str]] = None) -> int:
    args = _parser().parse_args(argv)
    _setup_logging(args.verbose)
    try:
        if args.command == "init":
            return cmd_init(args)
        if args.command == "collect":
            return cmd_collect(args)
        if args.command == "report":
            return cmd_estimate(args, write=False)
        if args.command == "estimate":
            return cmd_estimate(args, write=True)
        return cmd_doctor(args)
    except (SetupError, MuninnUnavailable) as exc:
        log.error("%s", exc)
        return 2
    except KeyboardInterrupt:
        return 130
    except Exception as exc:                        # noqa: BLE001
        name = type(exc).__name__
        if name in ("PreflightError", "MigrationError", "RuleViolation", "OwnershipError", "SyncError"):
            log.error("%s", exc)
            return 2
        raise


if __name__ == "__main__":
    sys.exit(main())
