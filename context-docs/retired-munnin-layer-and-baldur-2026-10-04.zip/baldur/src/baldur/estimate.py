"""The estimation pipeline (spec: "The estimation pipeline"). Pure: no git, no database, no clock.

An estimate is an INFERENCE. Commit times say when work was recorded, not when it started or what
else was happening. Three rules keep that honest, and every function here obeys them:

    1. Every number carries its basis: the SHAs, sessions and meeting ids behind it.
    2. Bias down, consistently. Every cap, scaling, rounding and tie-break goes down.
    3. Attribution is by commit COUNT, never by lines changed. A vendored dependency or a bulk
       reformat dwarfs an afternoon of debugging in line counts. Do not "optimise" this.

Pipeline, per estimate run (one frozen Params):
    collect  ->  one timeline of sessions  ->  span (reflog or lead-in), clamp, split at midnight
             ->  meeting policy (exactly one per day)  ->  day cap (scale sessions)
             ->  attribute by commit count  ->  sum per ticket per day  ->  round down

Exactly one meeting policy applies to each day, so meeting time is never discounted twice. The
first version of this module applied an overlap fraction AND (planned) ambient weighting, which
discounted the same meeting minutes twice.
"""
from __future__ import annotations

import hashlib
import json
import math
from dataclasses import dataclass, field
from datetime import date, datetime, time, timedelta, timezone, tzinfo
from typing import Dict, Iterable, List, Optional, Sequence, Set, Tuple

MODEL_VERSION = "baldur-1"
POLICIES = ("ambient", "overlap", "independent")
_EPS = 1e-6                      # guards floor() against 89.99999999 from float sums


class EstimateError(ValueError):
    """An estimation setting is unusable. The message says what to change."""


# ---------------------------------------------------------------------------------------------
# Inputs
# ---------------------------------------------------------------------------------------------
@dataclass(frozen=True)
class CommitIn:
    sha: str
    repo: str
    authored_at: datetime                  # author time: rebases rewrite commit time
    keys: Tuple[str, ...] = ()             # empty = untracked
    key_source: Optional[str] = None
    subject: str = ""
    patch_id: Optional[str] = None


@dataclass(frozen=True)
class Checkout:
    """A reflog checkout. Evidence of when work on a branch began."""
    repo: str
    at: datetime
    branch: Optional[str] = None


@dataclass(frozen=True)
class Meeting:
    """A busy meeting (Odin's calendar via v_busy_meetings). `id` feeds the basis hash."""
    id: str
    start: datetime
    end: datetime


@dataclass(frozen=True)
class Params:
    """Every number that influences an estimate. Frozen: these ARE the model, copied into
    estimate_runs.params so changing a default never changes a past figure."""
    idle_gap_minutes: int = 120
    lead_in_minutes: int = 30
    min_session_minutes: int = 15
    max_session_minutes: int = 240
    max_daily_dev_minutes: int = 480
    policy: str = "ambient"
    ambient_weight: float = 0.5
    concurrent_fraction: float = 0.5
    round_to_minutes: int = 15
    tour_start: str = "07:30"
    tour_end: str = "16:00"
    unpaid_minutes: int = 30
    model_version: str = MODEL_VERSION

    def check(self) -> None:
        if self.idle_gap_minutes <= 0:
            raise EstimateError("idle_gap_minutes must be greater than zero.")
        if self.lead_in_minutes < 0:
            raise EstimateError("lead_in_minutes cannot be negative.")
        if not 0 <= self.min_session_minutes <= self.max_session_minutes:
            raise EstimateError("min_session_minutes must be between 0 and max_session_minutes.")
        if self.max_daily_dev_minutes <= 0:
            raise EstimateError("max_daily_dev_minutes must be greater than zero.")
        if self.policy not in POLICIES:
            raise EstimateError("policy must be one of {}, got {!r}.".format(", ".join(POLICIES), self.policy))
        for name in ("ambient_weight", "concurrent_fraction"):
            value = getattr(self, name)
            if not 0 <= value <= 1:
                raise EstimateError("{} must be between 0 and 1, got {!r}.".format(name, value))
        if self.round_to_minutes <= 0:
            raise EstimateError("round_to_minutes must be greater than zero.")
        if tour_minutes(self) <= 0:
            raise EstimateError("tour_of_duty must end after it starts, with unpaid time shorter than the day.")

    def as_dict(self) -> Dict[str, object]:
        return {k: getattr(self, k) for k in self.__dataclass_fields__}  # type: ignore[attr-defined]

    def fingerprint(self) -> str:
        text = json.dumps(self.as_dict(), sort_keys=True, separators=(",", ":"))
        return hashlib.sha256(text.encode("utf-8")).hexdigest()[:12]

    def describe(self) -> str:
        weight = {"ambient": " {:g}".format(self.ambient_weight),
                  "overlap": " {:g}".format(self.concurrent_fraction)}.get(self.policy, "")
        return "{}, policy {}{}, gap {}m, lead-in {}m, rounded down to {}m".format(
            self.model_version, self.policy, weight, self.idle_gap_minutes, self.lead_in_minutes,
            self.round_to_minutes)


def _hhmm(text: str) -> int:
    hours, minutes = text.split(":")
    return int(hours) * 60 + int(minutes)


def tour_minutes(params: Params) -> int:
    return _hhmm(params.tour_end) - _hhmm(params.tour_start) - params.unpaid_minutes


# ---------------------------------------------------------------------------------------------
# Outputs
# ---------------------------------------------------------------------------------------------
@dataclass
class Session:
    id: str
    start: datetime
    end: datetime
    commits: List[CommitIn]
    start_from: str                         # "reflog" or "lead-in": the evidence for the start
    clamped: Optional[str] = None           # "min" / "max" when the span was clamped


@dataclass
class Part:
    """A session's slice within one local day (sessions split at midnight)."""
    session: Session
    day: date
    start: datetime
    end: datetime
    minutes: float = 0.0                    # wall-clock minutes of this slice
    in_meetings: float = 0.0                # of which, overlapped a busy meeting
    counted: float = 0.0                    # after the policy, before the day cap
    final: float = 0.0                      # after the day cap
    shares: Dict[str, float] = field(default_factory=dict)   # final minutes per ticket ("" = untracked)


@dataclass
class TicketDay:
    key: str
    raw_minutes: float = 0.0
    minutes: int = 0                        # rounded DOWN
    shas: Set[str] = field(default_factory=set)
    repos: Set[str] = field(default_factory=set)
    session_ids: List[str] = field(default_factory=list)


@dataclass
class DayEstimate:
    day: date
    policy: str
    cap: int
    meeting_minutes: int
    meeting_ids: List[str]
    parts: List[Part]
    tickets: Dict[str, TicketDay]
    untracked_raw: float
    untracked_shas: Set[str]
    capped_from: Optional[float]
    flags: List[str]

    @property
    def dev_minutes(self) -> int:
        return sum(t.minutes for t in self.tickets.values())

    @property
    def raw_dev_minutes(self) -> float:
        return sum(t.raw_minutes for t in self.tickets.values())

    @property
    def sessions(self) -> List[Session]:
        seen: List[Session] = []
        for part in self.parts:
            if part.session not in seen:
                seen.append(part.session)
        return seen


@dataclass
class Estimate:
    params: Params
    days: List[DayEstimate]
    excluded: List[Tuple[str, str]]         # (sha, reason)
    duplicates: int


# ---------------------------------------------------------------------------------------------
# Steps
# ---------------------------------------------------------------------------------------------
def round_down(minutes: float, step: int) -> int:
    """Floor to a multiple of `step`. Never raises a figure (rule 2)."""
    return int(math.floor(minutes / step + _EPS)) * step if minutes > 0 else 0


def dedupe(commits: Sequence[CommitIn]) -> Tuple[List[CommitIn], int]:
    """Each SHA once, then each patch-id once (cherry-picks). Returns (unique, dropped).

    When two copies disagree, the one carrying a key wins and then the EARLIER one, so a tracked
    change never turns untracked depending on which clone was scanned first.
    """
    by_sha: Dict[str, CommitIn] = {}
    for c in commits:
        best = by_sha.get(c.sha)
        if best is None or _prefer(c, best):
            by_sha[c.sha] = c
    by_patch: Dict[str, CommitIn] = {}
    unique: List[CommitIn] = []
    for c in sorted(by_sha.values(), key=lambda x: (x.authored_at, x.sha)):
        if c.patch_id:
            best = by_patch.get(c.patch_id)
            if best is not None:
                if _prefer(c, best):
                    unique[unique.index(best)] = c
                    by_patch[c.patch_id] = c
                continue
            by_patch[c.patch_id] = c
        unique.append(c)
    return sorted(unique, key=lambda x: (x.authored_at, x.sha)), len(commits) - len(unique)


def _prefer(a: CommitIn, b: CommitIn) -> bool:
    if bool(a.keys) != bool(b.keys):
        return bool(a.keys)
    return a.authored_at < b.authored_at


def build_sessions(commits: Sequence[CommitIn], checkouts: Sequence[Checkout],
                   params: Params) -> List[Session]:
    """One timeline across ALL repositories, so two repos worked in parallel are counted once.

    A gap longer than idle_gap starts a new session. Reflog alone never creates a session; a
    checkout only moves a session's start earlier (spec step 4).
    """
    gap = timedelta(minutes=params.idle_gap_minutes)
    groups: List[List[CommitIn]] = []
    for c in sorted(commits, key=lambda x: (x.authored_at, x.sha)):
        if groups and c.authored_at - groups[-1][-1].authored_at <= gap:
            groups[-1].append(c)
        else:
            groups.append([c])

    ordered = sorted(checkouts, key=lambda x: x.at)
    sessions: List[Session] = []
    for index, group in enumerate(groups):
        first, last = group[0].authored_at, group[-1].authored_at
        # The earliest checkout close enough before the first commit to belong to this session.
        # One after the first commit is not evidence of when the session started.
        evidence = [k.at for k in ordered if first - gap <= k.at <= first]
        if sessions:
            evidence = [t for t in evidence if t > sessions[-1].end]
        if evidence:
            start, source = min(evidence), "reflog"
        else:
            start, source = first - timedelta(minutes=params.lead_in_minutes), "lead-in"
        span = (last - start).total_seconds() / 60.0
        clamped = None
        if span > params.max_session_minutes:
            start, clamped = last - timedelta(minutes=params.max_session_minutes), "max"
        elif span < params.min_session_minutes:
            start, clamped = last - timedelta(minutes=params.min_session_minutes), "min"
        if sessions and start < sessions[-1].end:
            # Lead-in or a floor must not reach back into the previous session and count its
            # minutes twice. Trimming here only ever shortens a span.
            start = sessions[-1].end
        sessions.append(Session("s{}".format(index + 1), start, last, list(group), source, clamped))
    return sessions


def split_at_midnight(session: Session, tz: tzinfo) -> List[Part]:
    """Each part belongs to its own local day. A session across midnight is not one day's work."""
    parts: List[Part] = []
    cursor = session.start.astimezone(tz)
    end = session.end.astimezone(tz)
    if end <= cursor:
        return [Part(session, cursor.date(), session.start, session.end, 0.0)]
    while cursor < end:
        midnight = datetime.combine(cursor.date() + timedelta(days=1), time(0), tzinfo=tz)
        stop = min(end, midnight)
        parts.append(Part(session, cursor.date(), cursor.astimezone(timezone.utc),
                          stop.astimezone(timezone.utc), (stop - cursor).total_seconds() / 60.0))
        cursor = stop
    return parts


def merge_intervals(meetings: Sequence[Meeting]) -> List[Tuple[datetime, datetime]]:
    """Overlapping meetings are one busy stretch, or double-booked time would be discounted twice."""
    merged: List[List[datetime]] = []
    for m in sorted(meetings, key=lambda x: x.start):
        if m.end <= m.start:
            continue
        if merged and m.start <= merged[-1][1]:
            merged[-1][1] = max(merged[-1][1], m.end)
        else:
            merged.append([m.start, m.end])
    return [(a, b) for a, b in merged]


def overlap_minutes(start: datetime, end: datetime, busy: Sequence[Tuple[datetime, datetime]]) -> float:
    total = 0.0
    for a, b in busy:
        lo, hi = max(start, a), min(end, b)
        if hi > lo:
            total += (hi - lo).total_seconds() / 60.0
    return total


def choose_policy(preferred: str, has_times: bool, has_totals: bool) -> str:
    """Exactly one policy per day. Falls back when the calendar cannot support the preferred one:
    ambient needs meeting times; overlap needs at least meeting totals; with neither, independent."""
    if preferred == "independent":
        return "independent"
    if preferred == "ambient" and has_times:
        return "ambient"
    if has_times or has_totals:
        return "overlap"
    return "independent"


def day_cap(params: Params, policy: str, meeting_minutes: float) -> int:
    """Development ceiling for one day. The overlap deduction rounds UP, so the cap errs small."""
    if policy != "overlap" or meeting_minutes <= 0:
        return params.max_daily_dev_minutes
    deduction = int(math.ceil(meeting_minutes * (1.0 - params.concurrent_fraction) - _EPS))
    return max(0, params.max_daily_dev_minutes - deduction)


def _weights(commits: Sequence[CommitIn]) -> Dict[str, float]:
    """Commit-count weights per ticket. A commit naming two tickets splits evenly; untracked
    commits weigh under the empty key, which is reported and never logged."""
    weights: Dict[str, float] = {}
    for c in commits:
        if c.keys:
            for key in c.keys:
                weights[key] = weights.get(key, 0.0) + 1.0 / len(c.keys)
        else:
            weights[""] = weights.get("", 0.0) + 1.0
    return weights


# ---------------------------------------------------------------------------------------------
# The whole pipeline
# ---------------------------------------------------------------------------------------------
def estimate(commits: Sequence[CommitIn], params: Optional[Params] = None,
             checkouts: Sequence[Checkout] = (), meetings: Sequence[Meeting] = (),
             calendar_days: Optional[Set[date]] = None,
             meeting_totals: Optional[Dict[date, int]] = None,
             tz: Optional[tzinfo] = None, now: Optional[datetime] = None) -> Estimate:
    """Run the pipeline. `calendar_days` lists days whose calendar is known (an empty known day
    means "no meetings", which is different from "no calendar data"); `meeting_totals` covers days
    whose totals are known without times."""
    params = params or Params()
    params.check()
    tz = tz or datetime.now().astimezone().tzinfo or timezone.utc
    now = now or datetime.now(timezone.utc)
    totals = dict(meeting_totals or {})
    known = set(calendar_days or set())

    unique, duplicates = dedupe(list(commits))
    excluded = [(c.sha, "authored in the future ({}): excluded".format(c.authored_at.isoformat()))
                for c in unique if c.authored_at > now]
    usable = [c for c in unique if c.authored_at <= now]

    busy = merge_intervals(meetings)
    meetings_by_day: Dict[date, List[Meeting]] = {}
    for m in meetings:
        meetings_by_day.setdefault(m.start.astimezone(tz).date(), []).append(m)
        known.add(m.start.astimezone(tz).date())

    parts_by_day: Dict[date, List[Part]] = {}
    for session in build_sessions(usable, checkouts, params):
        for part in split_at_midnight(session, tz):
            parts_by_day.setdefault(part.day, []).append(part)

    days: List[DayEstimate] = []
    for day in sorted(parts_by_day):
        parts = parts_by_day[day]
        day_meetings = meetings_by_day.get(day, [])
        has_times = day in known
        if has_times:
            # Busy time inside this local day, overlaps merged: a meeting crossing midnight counts
            # on each side, and double-booked time counts once.
            meeting_minutes = int(round(overlap_minutes(*_day_bounds(day, tz), busy)))
        else:
            meeting_minutes = int(totals.get(day, 0))
        policy = choose_policy(params.policy, has_times, day in totals)

        for part in parts:
            part.in_meetings = overlap_minutes(part.start, part.end, busy) if has_times else 0.0
            if policy == "ambient":
                part.counted = (part.minutes - part.in_meetings) + part.in_meetings * params.ambient_weight
            else:
                part.counted = part.minutes

        cap = day_cap(params, policy, meeting_minutes)
        total = sum(p.counted for p in parts)
        capped_from = None
        factor = 1.0
        if total > cap + _EPS:
            capped_from, factor = total, (cap / total if total else 0.0)
        for part in parts:
            part.final = part.counted * factor          # every session scaled by the same factor

        tickets: Dict[str, TicketDay] = {}
        untracked_raw, untracked_shas = 0.0, set()
        for part in parts:
            inside = [c for c in part.session.commits if part.start <= c.authored_at <= part.end]
            basis = inside or part.session.commits      # a lead-in-only slice uses the session's mix
            weights = _weights(basis)
            whole = sum(weights.values())
            for key, weight in weights.items():
                share = part.final * weight / whole
                part.shares[key] = part.shares.get(key, 0.0) + share
                if not key:
                    untracked_raw += share
                    untracked_shas.update(c.sha for c in basis if not c.keys)
                    continue
                ticket = tickets.setdefault(key, TicketDay(key))
                ticket.raw_minutes += share
                for c in basis:
                    if key in c.keys:
                        ticket.shas.add(c.sha)
                        ticket.repos.add(c.repo)
                if part.session.id not in ticket.session_ids:
                    ticket.session_ids.append(part.session.id)
        for ticket in tickets.values():
            ticket.minutes = round_down(ticket.raw_minutes, params.round_to_minutes)

        days.append(DayEstimate(day, policy, cap, meeting_minutes, sorted(m.id for m in day_meetings),
                                parts, dict(sorted(tickets.items())), untracked_raw, untracked_shas,
                                capped_from, _flags(day, policy, has_times, day in totals,
                                                    meeting_minutes, tickets, parts, params, now, tz)))
    return Estimate(params, days, excluded, duplicates)


def _day_bounds(day: date, tz: tzinfo) -> Tuple[datetime, datetime]:
    """Local midnight to midnight, in UTC. A daylight-saving day is 23 or 25 hours, correctly."""
    start = datetime.combine(day, time(0), tzinfo=tz)
    end = datetime.combine(day + timedelta(days=1), time(0), tzinfo=tz)
    return start.astimezone(timezone.utc), end.astimezone(timezone.utc)


def _flags(day: date, policy: str, has_times: bool, has_totals: bool, meeting_minutes: int,
           tickets: Dict[str, TicketDay], parts: Sequence[Part], params: Params,
           now: datetime, tz: tzinfo) -> List[str]:
    flags: List[str] = []
    if not has_times and not has_totals:
        flags.append("No calendar data for this day: policy independent, meetings not considered.")
    dev = sum(round_down(t.raw_minutes, params.round_to_minutes) for t in tickets.values())
    # Spec: only `independent` is flagged for exceeding the tour. Under ambient and overlap the
    # policy has already priced in coding during calls, so a long-looking total is expected.
    if policy == "independent" and meeting_minutes + dev > tour_minutes(params):
        flags.append("Meetings {} plus development {} exceed your {} tour of duty.".format(
            _hm(meeting_minutes), _hm(dev), _hm(tour_minutes(params))))
    if day.weekday() >= 5:
        flags.append("Weekend: estimated like any day; nothing is approved automatically.")
    if (now.astimezone(tz).date() - day).days > 90 and any(p.session.start_from == "lead-in" for p in parts):
        flags.append("Older than 90 days: reflog has expired, so session starts use the {}m lead-in."
                     .format(params.lead_in_minutes))
    return flags


def _hm(minutes: float) -> str:
    m = max(0, int(minutes))
    return "{}h{:02d}m".format(m // 60, m % 60)


def basis_hash(params: Params, shas: Iterable[str], meeting_ids: Iterable[str]) -> str:
    """Covers the model version, the settings, the commit SHAs and the meeting ids (spec). A re-run
    with the same hash has nothing new to say; a different one shows evidence or settings changed."""
    text = json.dumps({"model": params.model_version, "params": params.fingerprint(),
                       "shas": sorted(set(shas)), "meetings": sorted(set(meeting_ids))},
                      sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(text.encode("utf-8")).hexdigest()[:16]


def subtractive_tickets(commits: Sequence[CommitIn], params: Params, meeting_minutes: int,
                        tz: Optional[tzinfo] = None) -> Dict[str, int]:
    """The REMOVED model (cap = limit - meetings), kept only so a test can show it reproduces the
    spec's 45 minutes and that the real pipeline never does."""
    tz = tz or timezone.utc
    parts = [p for s in build_sessions(commits, (), params) for p in split_at_midnight(s, tz)]
    total = sum(p.minutes for p in parts)
    cap = max(0, params.max_daily_dev_minutes - meeting_minutes)
    factor = min(1.0, cap / total) if total else 0.0
    raw: Dict[str, float] = {}
    for part in parts:
        weights = _weights(part.session.commits)
        whole = sum(weights.values())
        for key, weight in weights.items():
            raw[key] = raw.get(key, 0.0) + part.minutes * factor * weight / whole
    return {k: round_down(v, params.round_to_minutes) for k, v in raw.items() if k}
