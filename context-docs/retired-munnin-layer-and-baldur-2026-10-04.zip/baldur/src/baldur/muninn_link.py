"""Find `asgard.muninn`, Asgard's shared data layer, and open it as Baldur.

Spec (build step 7): `baldur.pyw` adds ASGARD_APP to its import path to reach `asgard.muninn`. Search
order: already importable; then $ASGARD_APP (the folder holding the `asgard` package); then this
repository's development layout (munnin-layer/src beside baldur/). Nothing is installed.
"""
from __future__ import annotations

import os
import sys
from pathlib import Path
from typing import Any, List, Optional


class MuninnUnavailable(ImportError):
    pass


def _candidates() -> List[Path]:
    paths: List[Path] = []
    env = os.environ.get("ASGARD_APP")
    if env:
        paths.append(Path(env))
    here = Path(__file__).resolve()
    for parent in here.parents:
        paths.append(parent / "munnin-layer" / "src")
    return paths


def load() -> Any:
    try:
        from asgard import muninn  # noqa: F401
        return muninn
    except ImportError:
        pass
    for candidate in _candidates():
        if (candidate / "asgard" / "muninn" / "__init__.py").is_file():
            sys.path.insert(0, str(candidate))
            from asgard import muninn
            return muninn
    raise MuninnUnavailable(
        "Baldur could not find asgard.muninn. Set ASGARD_APP to the folder that contains the "
        "`asgard` package (in this repository: munnin-layer/src).")


def open_baldur(path: Optional[Path] = None, **kwargs: Any) -> Any:
    return load().open("baldur", path, **kwargs)
