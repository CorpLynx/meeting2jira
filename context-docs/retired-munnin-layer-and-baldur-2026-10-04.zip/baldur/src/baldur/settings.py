"""Baldur's settings: %LOCALAPPDATA%\\Asgard\\settings\\baldur.json.

Created with the spec's defaults on first run. A file that won't parse falls back to the defaults
WITH A WARNING, as Asgard's apps.local.json does; a single bad value falls back for that key only,
also with a warning. Each estimate run copies its settings into estimate_runs.params, so changing a
default never changes a past figure.

Git identities are NOT a setting. They live in Muninn's `identities`, shared with every app, so
there is one definition of "me" across Asgard.

Four old settings are gone on purpose and are warned about if found: approval cannot be switched
off and untracked minutes cannot be logged (the database refuses both rather than trusting a
flag); `output` went because Odin posts; `calendar_source` because Odin syncs the calendar.
"""
from __future__ import annotations

import json
import logging
import os
import re
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple

from .estimate import POLICIES, Params

log = logging.getLogger(__name__)

DEFAULTS: Dict[str, Any] = {
    "repo_roots": [],
    "max_depth": 3,
    "project_keys": [],
    "idle_gap_minutes": 120,
    "lead_in_minutes": 30,
    "min_session_minutes": 15,
    "max_session_minutes": 240,
    "max_daily_dev_minutes": 480,
    "policy": "ambient",
    "ambient_weight": 0.5,
    "concurrent_fraction": 0.5,
    "round_to_minutes": 15,
    "tour_of_duty": {"start": "07:30", "end": "16:00", "unpaid_minutes": 30},
    "github_api": "",
    "poll_minutes": 5,
    "alerts": True,
    "quiet_outside_tour": True,
    "run_at_logon": False,
    "commit_hook": False,
    "review_mode": "off",
}

REMOVED = {
    "authors": "your git identities now live in Muninn `identities`; run `baldur init`",
    "require_review": "approval cannot be switched off",
    "untracked_report_only": "untracked minutes can never be logged; the database refuses it",
    "output": "Odin posts approved days to Jira",
    "calendar_source": "Odin syncs the calendar into Muninn",
    "concurrency_policy": "renamed to `policy`",
    "enabled": "Baldur is run on purpose; there is nothing to enable",
}


def settings_dir() -> Path:
    override = os.environ.get("ASGARD_HOME")
    if override:
        return Path(override) / "settings"
    local = os.environ.get("LOCALAPPDATA")
    return (Path(local) / "Asgard" / "settings") if local else (Path.home() / ".asgard" / "settings")


def settings_path() -> Path:
    return settings_dir() / "baldur.json"


def _is_int(v: Any) -> bool:
    return isinstance(v, int) and not isinstance(v, bool)


def _is_num(v: Any) -> bool:
    return isinstance(v, (int, float)) and not isinstance(v, bool)


def _str_list(v: Any) -> bool:
    # A bare string is refused: "PROJ" would otherwise iterate as four one-letter projects.
    return isinstance(v, list) and all(isinstance(i, str) for i in v)


def _hhmm(v: Any) -> bool:
    return isinstance(v, str) and re.fullmatch(r"([01]\d|2[0-3]):[0-5]\d", v) is not None


def _tour(v: Any) -> bool:
    return (isinstance(v, dict) and _hhmm(v.get("start")) and _hhmm(v.get("end"))
            and _is_int(v.get("unpaid_minutes")) and v["unpaid_minutes"] >= 0
            and v["end"] > v["start"])


def _url(v: Any) -> bool:
    return v == "" or (isinstance(v, str) and v.startswith("https://"))


CHECKS: Dict[str, Tuple[Callable[[Any], bool], str]] = {
    "repo_roots": (_str_list, "a list of folder paths"),
    "max_depth": (lambda v: _is_int(v) and 0 <= v <= 10, "a whole number from 0 to 10"),
    "project_keys": (lambda v: _str_list(v) and all(re.fullmatch(r"[A-Z][A-Z0-9]+", p) for p in v),
                     "a list of Jira project keys such as [\"PROJ\", \"OPS\"]"),
    "idle_gap_minutes": (lambda v: _is_int(v) and v > 0, "a whole number above 0"),
    "lead_in_minutes": (lambda v: _is_int(v) and v >= 0, "a whole number, 0 or more"),
    "min_session_minutes": (lambda v: _is_int(v) and v >= 0, "a whole number, 0 or more"),
    "max_session_minutes": (lambda v: _is_int(v) and v > 0, "a whole number above 0"),
    "max_daily_dev_minutes": (lambda v: _is_int(v) and 0 < v <= 1440, "a whole number from 1 to 1440"),
    "policy": (lambda v: v in POLICIES, "one of " + ", ".join(POLICIES)),
    "ambient_weight": (lambda v: _is_num(v) and 0 <= v <= 1, "a number from 0 to 1"),
    "concurrent_fraction": (lambda v: _is_num(v) and 0 <= v <= 1, "a number from 0 to 1"),
    "round_to_minutes": (lambda v: _is_int(v) and 1 <= v <= 60, "a whole number from 1 to 60"),
    "tour_of_duty": (_tour, '{"start": "07:30", "end": "16:00", "unpaid_minutes": 30}'),
    "github_api": (_url, "an https:// URL, or empty to turn pull request features off"),
    "poll_minutes": (lambda v: _is_int(v) and v >= 1, "a whole number, 1 or more"),
    "alerts": (lambda v: isinstance(v, bool), "true or false"),
    "quiet_outside_tour": (lambda v: isinstance(v, bool), "true or false"),
    "run_at_logon": (lambda v: isinstance(v, bool), "true or false"),
    "commit_hook": (lambda v: isinstance(v, bool), "true or false"),
    "review_mode": (lambda v: v in ("off", "metadata", "content"), "off, metadata or content"),
}


class Settings(dict):
    """A dict of settings plus the warnings produced while reading them."""

    def __init__(self, values: Dict[str, Any], warnings: Optional[List[str]] = None):
        super().__init__(values)
        self.warnings: List[str] = list(warnings or [])

    def params(self) -> Params:
        tour = self["tour_of_duty"]
        return Params(
            idle_gap_minutes=self["idle_gap_minutes"], lead_in_minutes=self["lead_in_minutes"],
            min_session_minutes=self["min_session_minutes"], max_session_minutes=self["max_session_minutes"],
            max_daily_dev_minutes=self["max_daily_dev_minutes"], policy=self["policy"],
            ambient_weight=float(self["ambient_weight"]), concurrent_fraction=float(self["concurrent_fraction"]),
            round_to_minutes=self["round_to_minutes"], tour_start=tour["start"], tour_end=tour["end"],
            unpaid_minutes=tour["unpaid_minutes"])


def defaults() -> Dict[str, Any]:
    return json.loads(json.dumps(DEFAULTS))


def load(path: Optional[Path] = None, create: bool = True) -> Settings:
    target = Path(path) if path else settings_path()
    values = defaults()
    warnings: List[str] = []

    if not target.is_file():
        if create:
            try:
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_text(json.dumps(values, indent=2) + "\n", encoding="utf-8")
            except OSError as exc:
                warnings.append("Could not create {} ({}); using defaults.".format(target, exc))
        return _finish(values, warnings)

    try:
        raw = json.loads(target.read_text(encoding="utf-8-sig"))
        if not isinstance(raw, dict):
            raise ValueError("the file must contain a JSON object")
    except (OSError, ValueError) as exc:
        warnings.append("{} could not be read ({}); using the defaults. Fix or delete the file."
                        .format(target, exc))
        return _finish(values, warnings)

    for key, value in raw.items():
        if key.startswith("_"):
            continue
        if key in REMOVED:
            warnings.append("Ignoring `{}`: {}.".format(key, REMOVED[key]))
            continue
        if key not in CHECKS:
            warnings.append("Ignoring unknown setting `{}`.".format(key))
            continue
        check, expected = CHECKS[key]
        if check(value):
            values[key] = value
        else:
            warnings.append("`{}` should be {}; got {!r}. Using the default, {!r}.".format(
                key, expected, value, DEFAULTS[key]))
    if values["min_session_minutes"] > values["max_session_minutes"]:
        warnings.append("min_session_minutes exceeds max_session_minutes; using both defaults.")
        values["min_session_minutes"] = DEFAULTS["min_session_minutes"]
        values["max_session_minutes"] = DEFAULTS["max_session_minutes"]
    return _finish(values, warnings)


def _finish(values: Dict[str, Any], warnings: List[str]) -> Settings:
    for warning in warnings:
        log.warning("%s", warning)
    return Settings(values, warnings)
