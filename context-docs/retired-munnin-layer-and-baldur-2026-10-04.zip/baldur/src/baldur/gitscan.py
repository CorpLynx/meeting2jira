"""Read git: repositories, commits, numstat, patch-ids, reflog and branch membership.

Metadata only (spec principle 5). Baldur reads commit times, subjects, branch names and line counts,
never diffs. The one place a diff is involved is `git patch-id`, which needs it to compute the hash:
there `git log -p` is piped straight into `git patch-id` between two git processes, so the diff
text never enters Python at all.

Every call is an argument list, never a shell string: repository paths contain spaces, branch names
contain almost anything, and a path under C:\\Program Files breaks on the space.
"""
from __future__ import annotations

import logging
import subprocess
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

log = logging.getLogger(__name__)

TRUNK_BRANCHES = ("main", "master", "develop", "dev", "trunk")
_RS, _FS = "\x1e", "\x1f"                 # ASCII record and unit separators; never in a subject


class GitScanError(Exception):
    """A git problem. The message says what to do."""


@dataclass
class RawCommit:
    sha: str
    author_name: str
    author_email: str
    authored_at: datetime
    committed_at: datetime
    subject: str
    parents: int
    files_changed: int = 0
    additions: int = 0
    deletions: int = 0

    @property
    def is_merge(self) -> bool:
        return self.parents > 1


@dataclass
class ReflogEntry:
    at: datetime
    sha: str
    action: str                           # checkout, commit, rebase, reset, merge, pull, ...
    message: str


def _run(repo: Path, *args: str, timeout: int = 60, check: bool = True) -> str:
    try:
        done = subprocess.run(["git", "-C", str(repo)] + list(args),
                              stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=timeout)
    except FileNotFoundError:
        raise GitScanError("git was not found on PATH. Install git, or start Baldur from a shell "
                           "where it is available.") from None
    except subprocess.TimeoutExpired:
        raise GitScanError("git timed out after {}s in {}.".format(timeout, repo)) from None
    if check and done.returncode != 0:
        detail = done.stderr.decode("utf-8", "replace").strip()
        raise GitScanError("git {} failed in {}: {}".format(args[0], repo, detail or "no detail"))
    return done.stdout.decode("utf-8", "replace")


def git_available() -> bool:
    try:
        subprocess.run(["git", "--version"], stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                       timeout=10, check=True)
        return True
    except (OSError, subprocess.SubprocessError):
        return False


def git_identity() -> List[Tuple[str, str]]:
    """[(kind, value)] from your global git config, offered (never applied silently) on first run."""
    found: List[Tuple[str, str]] = []
    for key, kind in (("user.email", "git_email"), ("user.name", "git_name")):
        try:
            done = subprocess.run(["git", "config", "--global", key], stdout=subprocess.PIPE,
                                  stderr=subprocess.PIPE, timeout=10)
        except (OSError, subprocess.SubprocessError):
            break
        value = done.stdout.decode("utf-8", "replace").strip()
        if done.returncode == 0 and value:
            found.append((kind, value))
    return found


def discover_repos(roots: Iterable[str], max_depth: int = 3) -> List[Path]:
    """Git working trees under each root, depth-bounded, never descending into a repository
    (a submodule's commits belong to the submodule) or into dependency folders."""
    found: List[Path] = []
    for root in roots:
        base = Path(root).expanduser()
        if not base.is_dir():
            log.warning("repo root %s does not exist; skipping.", base)
            continue
        if (base / ".git").exists():
            found.append(base)
            continue
        stack: List[Tuple[Path, int]] = [(base, 0)]
        while stack:
            current, depth = stack.pop()
            if depth > max_depth:
                continue
            try:
                children = sorted(p for p in current.iterdir() if p.is_dir())
            except OSError:
                continue
            for child in children:
                if (child / ".git").exists():
                    found.append(child)
                elif not (child.name.startswith(".") or child.name in
                          ("node_modules", "__pycache__", "venv", ".venv", "site-packages")):
                    stack.append((child, depth + 1))
    return sorted(set(found))


def parse_git_date(text: str) -> datetime:
    """Strict ISO from git. Python 3.8's fromisoformat rejects a trailing Z."""
    value = text.strip()
    if value.endswith("Z"):
        value = value[:-1] + "+00:00"
    parsed = datetime.fromisoformat(value)
    return parsed if parsed.tzinfo else parsed.replace(tzinfo=timezone.utc)


def read_commits(repo: Path, since: Optional[datetime] = None) -> List[RawCommit]:
    """Every commit reachable from any ref, with numstat totals. Ownership is decided later, from
    Muninn identities, so the author filter lives in one place for every app."""
    fmt = _RS + _FS.join(["%H", "%an", "%ae", "%aI", "%cI", "%s", "%P"])
    args = ["log", "--all", "--numstat", "--format=" + fmt]
    if since is not None:
        args.append("--since=" + since.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"))
    out: List[RawCommit] = []
    for record in _run(repo, *args).split(_RS):
        if not record.strip():
            continue
        head, _, numstat = record.partition("\n")
        fields = head.split(_FS)
        if len(fields) < 7:
            continue
        try:
            commit = RawCommit(fields[0], fields[1], fields[2], parse_git_date(fields[3]),
                               parse_git_date(fields[4]), fields[5], len(fields[6].split()))
        except ValueError:
            log.debug("Skipping %s: unparseable date", fields[0][:8])
            continue
        for line in numstat.splitlines():
            parts = line.split("\t")
            if len(parts) == 3:
                commit.files_changed += 1
                # Binary files report "-": counted as a changed file with no lines.
                commit.additions += int(parts[0]) if parts[0].isdigit() else 0
                commit.deletions += int(parts[1]) if parts[1].isdigit() else 0
        out.append(commit)
    return out


def patch_ids(repo: Path, since: Optional[datetime] = None, timeout: int = 120) -> Dict[str, str]:
    """{sha: patch-id}. A cherry-picked change has the same patch-id as its original, which is how
    it gets counted once. The diff flows git -> git through a pipe; Python only sees the ids."""
    log_args = ["git", "-C", str(repo), "log", "--all", "--no-merges", "-p", "--format=commit %H"]
    if since is not None:
        log_args.append("--since=" + since.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"))
    try:
        producer = subprocess.Popen(log_args, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
        consumer = subprocess.Popen(["git", "-C", str(repo), "patch-id", "--stable"],
                                    stdin=producer.stdout, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
    except FileNotFoundError:
        raise GitScanError("git was not found on PATH.") from None
    assert producer.stdout is not None
    producer.stdout.close()                # so the producer gets SIGPIPE if the consumer exits
    try:
        output, _ = consumer.communicate(timeout=timeout)
        producer.wait(timeout=timeout)
    except subprocess.TimeoutExpired:
        producer.kill()
        consumer.kill()
        raise GitScanError("git patch-id timed out in {}.".format(repo)) from None
    ids: Dict[str, str] = {}
    for line in output.decode("utf-8", "replace").splitlines():
        parts = line.split()
        if len(parts) == 2:
            ids[parts[1]] = parts[0]
    return ids


def read_reflog(repo: Path) -> List[ReflogEntry]:
    """HEAD's reflog, OLDEST first. (`git log -g` refuses --reverse, so it is reversed here.)"""
    raw = _run(repo, "log", "-g", "--date=iso-strict", "--format=%H" + _FS + "%gd" + _FS + "%gs",
               "HEAD", check=False)
    entries: List[ReflogEntry] = []
    for line in raw.splitlines():
        fields = line.split(_FS)
        if len(fields) != 3 or "@{" not in fields[1]:
            continue
        try:
            at = parse_git_date(fields[1][fields[1].index("@{") + 2:-1])
        except ValueError:
            continue
        message = fields[2]
        action = message.split(":", 1)[0].split(" ", 1)[0].strip().lower() or "unknown"
        entries.append(ReflogEntry(at, fields[0], action, message))
    entries.reverse()
    return entries


def reflog_branches(entries: Sequence[ReflogEntry]) -> Dict[str, str]:
    """{sha: branch} for commits made while checked out on a branch, from the reflog.

    Source 1 in the spec's order: it records where you WERE when you committed, which survives the
    branch being deleted after merge (for 90 days, until git expires the reflog).
    """
    current: Optional[str] = None
    found: Dict[str, str] = {}
    for entry in entries:
        if entry.action == "checkout":
            marker = " to "
            current = entry.message.rsplit(marker, 1)[1].strip() if marker in entry.message else None
        elif entry.action == "commit" and current:
            found.setdefault(entry.sha, current)
    return found


def branch_membership(repo: Path, limit: int = 5000) -> Dict[str, List[str]]:
    """{sha: [branches]} where each branch lists only the commits it ADDED, not everything reachable.

    `git rev-list <branch>` lists every ancestor, so every commit on main since the start would be
    credited to every feature branch cut from it. Each branch is listed with the trunks excluded.
    """
    names = [n.strip() for n in _run(repo, "for-each-ref", "--format=%(refname:short)", "refs/heads").splitlines()
             if n.strip()]
    trunks = [n for n in names if n in TRUNK_BRANCHES]
    found: Dict[str, List[str]] = {}
    for branch in names:
        if branch in TRUNK_BRANCHES:
            continue
        args = ["rev-list", "--no-merges", "-n", str(limit), branch]
        for trunk in trunks:
            args.extend(["--not", trunk])
        try:
            shas = _run(repo, *args).split()
        except GitScanError:
            continue
        for sha in shas:
            found.setdefault(sha, []).append(branch)
    return found


def remote_url(repo: Path) -> Optional[str]:
    url = _run(repo, "config", "--get", "remote.origin.url", check=False).strip()
    return url or None
