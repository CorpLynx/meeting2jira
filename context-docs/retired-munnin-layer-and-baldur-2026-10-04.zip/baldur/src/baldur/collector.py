"""Collect git into Muninn (spec build step 3).

For each repository under `repo_roots`: commits (with numstat and patch-id), HEAD's reflog, and each
commit's Jira keys in the spec's source order, all through Muninn's writer. Ownership (`is_mine`) is
decided by Muninn from your `git_email` identities, never by an author list in Baldur.

Incremental, idempotent: each repository is a stream `commits:<path>` with a cursor. A run re-reads
from the cursor minus an overlap, because commits do not arrive in time order (a pull brings in
older work, a rebase rewrites dates), and upserts make re-reading free. Run it at least weekly:
git expires reflog entries after 90 days, and the reflog is the best key source.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Dict, List, Optional

from . import gitscan
from .errors import SetupError
from .keys import KeyMatcher

log = logging.getLogger(__name__)

SOURCE = "local-git"
OVERLAP = timedelta(days=14)
CONFIDENCE = {"reflog": 1.0, "branch": 1.0, "pull_request": 0.9, "message": 0.8}


@dataclass
class CollectResult:
    repos: List[str] = field(default_factory=list)
    commits_seen: int = 0
    commits_new: int = 0
    keys_linked: int = 0
    untracked: int = 0
    reflog_new: int = 0
    warnings: List[str] = field(default_factory=list)


def require_identity(m: Any) -> None:
    if not m.identity_values("git_email"):
        raise SetupError(
            "No git identity in Muninn, so no commit can be attributed to you. Run `baldur init` "
            "(it offers the email from `git config user.email`). An empty identity is refused on "
            "purpose: it would credit the whole team's commits to one timesheet.")


def collect(m: Any, settings: Dict[str, Any], since: Optional[datetime] = None,
            full: bool = False) -> CollectResult:
    """Collect every repository under settings['repo_roots']. One bad repo never costs the rest."""
    require_identity(m)
    matcher = KeyMatcher(settings["project_keys"])
    result = CollectResult()
    roots = settings["repo_roots"]
    if not roots:
        raise SetupError("repo_roots is empty in baldur.json; list the folders holding your repositories.")
    for path in gitscan.discover_repos(roots, settings["max_depth"]):
        try:
            _collect_repo(m, path, matcher, since, full, result)
        except gitscan.GitScanError as exc:
            result.warnings.append(str(exc))
            log.warning("%s", exc)
    return result


def _collect_repo(m: Any, path: Path, matcher: KeyMatcher, since: Optional[datetime],
                  full: bool, result: CollectResult) -> None:
    repo_id = m.baldur.upsert_repo(path.name, str(path), remote_url=gitscan.remote_url(path))
    active = m.conn.execute("SELECT active FROM repos WHERE id = ?", (repo_id,)).fetchone()[0]
    if not active:
        return                                         # switched off: history kept, not rescanned
    result.repos.append(path.name)
    stream = "commits:{}".format(path)

    with m.run(source=SOURCE, stream=stream, kind="git") as run:
        start = since
        if start is None and run.cursor and not full:
            start = gitscan.parse_git_date(run.cursor) - OVERLAP
        commits = [c for c in gitscan.read_commits(path, start) if not c.is_merge]   # spec: skip merges
        patches = gitscan.patch_ids(path, start)
        reflog = gitscan.read_reflog(path)
        on_branch = gitscan.reflog_branches(reflog)
        members = gitscan.branch_membership(path)

        for entry in reflog:
            if start is not None and entry.at < start:
                continue
            if m.baldur.record_reflog(repo_id, entry.at.isoformat(), entry.action, entry.sha, entry.message):
                result.reflog_new += 1

        newest: Optional[datetime] = None
        for raw in commits:
            with run.item(raw.sha[:12]):
                branches = members.get(raw.sha, [])
                hint = on_branch.get(raw.sha) or (branches[0] if branches else None)
                stored = run.baldur.upsert_commit(repo_id, {
                    "sha": raw.sha, "author_name": raw.author_name, "author_email": raw.author_email,
                    "authored_at": raw.authored_at, "committed_at": raw.committed_at,
                    "subject": raw.subject, "files_changed": raw.files_changed,
                    "additions": raw.additions, "deletions": raw.deletions, "is_merge": raw.is_merge,
                    "branch_hint": hint, "patch_id": patches.get(raw.sha)})
                result.commits_seen += 1
                result.commits_new += stored.outcome == "created"
                # The spec's four sources, first that yields anything. The pull-request source
                # needs GitHub, which is not built yet, so it is skipped here.
                keys, source = matcher.resolve(reflog_branch=on_branch.get(raw.sha), branches=branches,
                                               message=raw.subject)
                if not keys:
                    result.untracked += 1
                for key in keys:
                    if m.baldur.link_commit(stored.id, key, source, CONFIDENCE[source]):
                        result.keys_linked += 1
                if newest is None or raw.authored_at > newest:
                    newest = raw.authored_at
        if newest is not None:
            previous = gitscan.parse_git_date(run.cursor) if run.cursor else None
            run.advance_cursor(max(newest, previous).isoformat() if previous else newest.isoformat())
        m.baldur.touch_repo(repo_id)
