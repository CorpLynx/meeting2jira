"""Baldur's one deliberate error type, for problems a person fixes (setup, settings, identity).

Kept separate from Python's own errors so the CLI can map it to exit code 2 without also catching,
and hiding, a real KeyError or IndexError bug.
"""


class SetupError(Exception):
    """Something to set up or correct. The message says what to do."""
