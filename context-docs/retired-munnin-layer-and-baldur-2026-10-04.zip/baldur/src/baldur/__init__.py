"""Baldur: estimate development time per Jira issue from local git history.

Standard library only (Tkinter included), so it runs on a locked-down machine with no pip, no admin
rights and no approved packages. Python 3.8+.

Why this exists as its own app
    Odin turns calendar meetings into Jira sub-tasks: a meeting worklog is a MEASUREMENT, because
    the calendar says it ran 13:00-13:30. Development time has no such record. Baldur infers it
    from commit history, and an inference deserves to be kept visibly apart from a measurement.

    The design premise (see .kiro/specs/gitwork-estimation.md): asking an engineer to log time
    against development work is always an estimate. A day in calls from 09:00 to 16:30 while also
    committing, reviewing and answering messages cannot be decomposed accurately from memory. So the
    goal is not measurement. It is a transparent, consistently-biased approximation that is closer
    than typing round numbers into a form on Friday afternoon.

    Three rules follow from that and hold everywhere in this package:
        1. Transparency beats precision. Every number can show its basis.
        2. Bias consistently downward. Every cap and rounding reduces, never increases.
        3. The tool proposes, the human approves. Nothing is written anywhere automatically.

Module map (spec: "Baldur spec work-time estimates from git-2.md")
    settings     baldur.json in %LOCALAPPDATA%\\Asgard\\settings; bad values fall back with a warning
    keys         Jira keys: project_keys filter and the four-source order
    gitscan      read git: commits, numstat, patch-ids, reflog, branch membership. Metadata only.
    collector    git -> Muninn, incremental (build step 3)
    estimate     the pipeline: sessions, policies, day cap, attribution, rounding. Pure.
    report       basis text and the day report
    service      Muninn -> estimate -> Muninn (build step 6)
    muninn_link  finds asgard.muninn via ASGARD_APP
    __main__     CLI: init, collect, report, estimate, doctor

All state lives in Muninn. Baldur never writes to Jira; it records approvals and Odin posts.
"""
__version__ = "0.1.0"
