"""Estimate from Muninn, into Muninn (spec build step 6). The one path the CLI and the window share.

Reads: your commits (`is_mine = 1`, merges excluded) and their key links, reflog checkouts, and
Odin's calendar through `v_busy_meetings`. Never another app's private database: the first version
read Odin's state.db directly, which the v2 spec removes.

Writes, in one transaction, so a run is all there or not there at all:
    estimate_runs          the frozen settings
    work_sessions          one row per session slice (sessions split at local midnight)
    session_commits        which commits each slice contains
    session_allocations    whole minutes per ticket per slice, rounded down
    day_proposals          one row per ticket per day, with basis text and basis_hash

Re-running is safe. A proposal whose evidence hash matches one already proposed, approved or
rejected is skipped (Muninn's writer enforces it), so a re-run with no new commits proposes nothing.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta, timezone, tzinfo
from typing import Any, Dict, List, Optional, Set, Tuple

from . import estimate as est
from .errors import SetupError
from .keys import KeyMatcher
from .report import basis_lines

_TS = "%Y-%m-%dT%H:%M:%SZ"


@dataclass
class Snapshot:
    estimate: est.Estimate
    run_id: Optional[int]
    tz: tzinfo
    date_from: date
    date_to: date
    proposed: List[int] = field(default_factory=list)
    unchanged: List[Tuple[str, str]] = field(default_factory=list)   # (day, key): same evidence as before
    calendar_known: bool = False
    warnings: List[str] = field(default_factory=list)

    @property
    def days(self) -> List[est.DayEstimate]:
        return self.estimate.days


def _ts(moment: datetime) -> str:
    return moment.astimezone(timezone.utc).strftime(_TS)


def _parse(text: str) -> datetime:
    return datetime.strptime(text, _TS).replace(tzinfo=timezone.utc)


def window(days_back: int, now: datetime, tz: tzinfo) -> Tuple[datetime, datetime, date, date]:
    """Local midnight `days_back` days ago through now. 0 = today only."""
    today = now.astimezone(tz).date()
    first = today - timedelta(days=max(0, days_back))
    start = datetime.combine(first, datetime.min.time(), tzinfo=tz)
    return start, now, first, today


def read_inputs(m: Any, matcher: KeyMatcher, lo: datetime, hi: datetime,
                tz: tzinfo) -> Tuple[List[est.CommitIn], Dict[str, int], List[est.Checkout],
                                     List[est.Meeting], Set[date]]:
    conn = m.conn
    rows = conn.execute(
        "SELECT c.id, c.sha, r.name AS repo, c.authored_at, c.subject, c.patch_id FROM commits c "
        "JOIN repos r ON r.id = c.repo_id "
        "WHERE c.is_mine = 1 AND c.authored_at >= ? AND c.authored_at < ? AND c.is_merge = 0 "
        "ORDER BY c.authored_at", (_ts(lo), _ts(hi))).fetchall()   # is_mine = 1 literal: partial index
    links: Dict[int, List[Tuple[str, str]]] = {}
    if rows:
        ids = [r["id"] for r in rows]
        for chunk in range(0, len(ids), 500):
            part = ids[chunk:chunk + 500]
            for link in conn.execute(
                    "SELECT commit_id, work_item_key, method FROM commit_work_items WHERE commit_id IN ({})"
                    .format(",".join("?" * len(part))), part):
                links.setdefault(link["commit_id"], []).append((link["work_item_key"], link["method"]))

    commits: List[est.CommitIn] = []
    sha_to_id: Dict[str, int] = {}
    for r in rows:
        found = links.get(r["id"], [])
        manual = [k for k, method in found if method == "manual"]    # a person's fix wins
        chosen = manual or [k for k, _ in found]
        keys = tuple(k for k in dict.fromkeys(chosen) if matcher.find(k) == [k])   # current project_keys only
        source = next((method for k, method in found if k in keys), None)
        commits.append(est.CommitIn(r["sha"], r["repo"], _parse(r["authored_at"]), keys, source,
                                    r["subject"], r["patch_id"]))
        sha_to_id[r["sha"]] = r["id"]

    checkouts = [est.Checkout(r["repo"], _parse(r["at"]))
                 for r in conn.execute(
                     "SELECT g.at, p.name AS repo FROM reflog_entries g JOIN repos p ON p.id = g.repo_id "
                     "WHERE g.action = 'checkout' AND g.at >= ? AND g.at < ?", (_ts(lo), _ts(hi)))]
    meetings = [est.Meeting(r["external_id"], _parse(r["starts_at"]), _parse(r["ends_at"]))
                for r in conn.execute(
                    "SELECT external_id, starts_at, ends_at FROM v_busy_meetings "
                    "WHERE starts_at < ? AND ends_at > ?", (_ts(hi), _ts(lo)))]
    # A day counts as "calendar known" when Odin synced ANY event for it, busy or not. A day with
    # nothing synced falls back to `independent`, which discounts nothing and is flagged.
    known = {_parse(r[0]).astimezone(tz).date() for r in conn.execute(
        "SELECT starts_at FROM calendar_events WHERE deleted_at IS NULL AND starts_at >= ? AND starts_at < ?",
        (_ts(lo), _ts(hi)))}
    return commits, sha_to_id, checkouts, meetings, known


def compute(m: Any, settings: Dict[str, Any], days_back: int, write: bool = True,
            now: Optional[datetime] = None, tz: Optional[tzinfo] = None) -> Snapshot:
    if not m.identity_values("git_email"):
        raise SetupError("No git identity in Muninn: run `baldur init` first. An empty identity is "
                          "refused because it would credit the whole team's commits to one timesheet.")
    matcher = KeyMatcher(settings["project_keys"])
    params = settings.params()
    params.check()
    tz = tz or datetime.now().astimezone().tzinfo or timezone.utc
    now = now or datetime.now(timezone.utc)
    start, end, first, last = window(days_back, now, tz)
    # Read one gap earlier so a session that began before the window still finds its start.
    lo = start - timedelta(minutes=params.idle_gap_minutes + params.max_session_minutes)
    commits, sha_to_id, checkouts, meetings, known = read_inputs(m, matcher, lo, end, tz)

    result = est.estimate(commits, params, checkouts=checkouts, meetings=meetings,
                          calendar_days=known, tz=tz, now=now)
    result.days = [d for d in result.days if first <= d.day <= last]
    snap = Snapshot(result, None, tz, first, last, calendar_known=bool(known))
    if not known:
        snap.warnings.append("No calendar data in Muninn yet (Odin has not synced it), so every day "
                             "uses the `independent` policy and meetings are not considered.")
    if result.excluded:
        snap.warnings.append("{} commit(s) dated in the future were excluded.".format(len(result.excluded)))
    if not write or not result.days:
        return snap

    b = m.baldur
    with m.transaction():
        run_id = b.create_estimate_run(first.isoformat(), last.isoformat(), params.model_version,
                                       params.as_dict())
        snap.run_id = run_id
        for day in result.days:
            for part in day.parts:
                inside = [c for c in part.session.commits if part.start <= c.authored_at <= part.end]
                total = int(math.floor(part.final + est._EPS))
                session_id = b.add_session(
                    run_id, _ts(part.start), _ts(part.end), total, day.day.isoformat(), day.policy,
                    focused_minutes=max(0.0, part.minutes - part.in_meetings),
                    ambient_minutes=part.in_meetings, signal_count=len(inside),
                    commit_ids=[sha_to_id[c.sha] for c in inside if c.sha in sha_to_id])
                allocations = {k: int(math.floor(v + est._EPS)) for k, v in part.shares.items() if k}
                if allocations and sum(allocations.values()) <= total:
                    b.set_allocations(session_id, {k: v for k, v in allocations.items() if v})
            rows = []
            for ticket in day.tickets.values():
                rows.append({
                    "work_item_key": ticket.key, "minutes_raw": round(ticket.raw_minutes, 4),
                    "minutes_proposed": min(ticket.minutes, int(math.floor(ticket.raw_minutes + est._EPS))),
                    "basis": "\n".join(basis_lines(ticket, day, params, tz, run_id)),
                    "basis_hash": est.basis_hash(params, ticket.shas, day.meeting_ids)})
            if day.untracked_raw > 0:
                minutes = est.round_down(day.untracked_raw, params.round_to_minutes)
                rows.append({
                    "work_item_key": None, "minutes_raw": round(day.untracked_raw, 4),
                    "minutes_proposed": minutes,
                    "basis": "Untracked: {} commit(s) with no Jira key in a project you track. Reported, "
                             "never logged.".format(len(day.untracked_shas)),
                    "basis_hash": est.basis_hash(params, day.untracked_shas, day.meeting_ids)})
            snap.proposed.extend(b.propose_day(run_id, day.day.isoformat(), rows))
            snap.unchanged.extend((day.day.isoformat(), k) for k in b.last_skipped)
    return snap
