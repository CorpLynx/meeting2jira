# Baldur spec: work estimates from git, and pull request alerts

Oct 3, 2026 · @Brandon

Baldur turns your git and GitHub activity into per-ticket time proposals that you review and approve, and tells you when a pull request is waiting for your review. Odin, Asgard's only Jira writer, posts what you approve. Every number carries the evidence behind it, and every rounding goes down.

## Principles

Logged time is always an estimate. On a day of back-to-back calls, commits, reviews and messages, nobody can split the hours accurately from memory. Baldur doesn't measure time. It produces an approximation that is open about its basis, biased the same way every time, and closer than typing round numbers into a form on Friday.

1. **Every number carries its basis.** "2h15m from 7 commits in 3 sessions, 09:12–16:40" can be audited. "2h15m" can't. The basis is stored with the estimate, not reconstructed later.
2. **Bias down, consistently.** Every cap, rounding and tie-break goes down. A slightly low estimate is defensible; one that swings unpredictably can't be calibrated.
3. **Baldur proposes, you approve.** Nothing reaches Jira or a timesheet without your approval in Baldur, and only Odin posts to Jira; Muninn's checks enforce that order (Muninn rule 8).
4. **Say what can't be seen.** Design talks, code review without commits and thinking leave no trace. The day report names that gap instead of implying the total is the whole day.
5. **Metadata only by default.** Baldur reads commit times, subjects, branch names and line counts, never diffs. Code content reaches a model only through the opt-in review mode (see Optional AI review).

## How Baldur fits into Asgard

&#91;embedded content: Baldur in Asgard · sources, Muninn, Baldur, review, Odin, outputs\]

Baldur opens from its Asgard tile and writes everything through Muninn. Collection, estimation and review are separate steps, so you can re-estimate a week with new settings without collecting again. Approved days wait in Muninn until Odin posts them, and Freya reads the same commits, pull requests and approved minutes for your review.

## Baldur and Odin

Baldur owns git, GitHub and the estimate; Odin owns Jira and the calendar. They meet in Muninn on the Jira issue key, so neither calls the other.

| Concern | Baldur | Odin |
| --- | --- | --- |
| Git and GitHub | Collects commits, reflog, pull requests and reviews | — |
| Jira keys | Finds them in branches, PRs and commit messages; stores them as text | Resolves each one in `work_item_aliases`, including moved and missing keys |
| Jira issues | Reads titles and status for the review screen | Syncs your issues, tracked parents' children, and every key Baldur mentions |
| Calendar | Reads `v_busy_meetings` to keep meeting time out | Syncs `calendar_events`; logs the meetings it's set to log |
| Time | Estimates, proposes, and records your approval | Posts the approved shortfall from `v_worklogs_to_post` |
| Writes to Jira | Never | The only app that does |
| Finished issues | Supplies commits, PRs and approved minutes | Emits `work_item.done`; Freya copies the issue into `accomplishments` |

Approval stays in Baldur because the evidence is there: the sessions, the commits and the basis of every number. Odin doesn't ask again, since approving in Baldur is the consent; it posts on its next run and shows anything that failed.

## What changed from Odin's gitwork spec

The old spec's model holds up. These changes move it into Asgard, hand Jira to Odin, fix three logic gaps, and make its defaults measurable.

| Area | Old spec | This spec | Why |
| --- | --- | --- | --- |
| Home | `meeting2jira/gitwork.py` inside Odin | Asgard app in `apps/baldur/`, porting that module and its 34 tests | Odin stays focused on Jira; Baldur gets its own tile |
| State | `git_worklogs` table in Odin's `state.db` | Muninn tables shared with Odin, Freya and Loki | One copy of the facts, joined on the Jira key |
| Writing to Jira | Baldur posts through Odin's `JiraClient` | Baldur records approvals; Odin posts the shortfall from `v_worklogs_to_post` | One Jira writer, one set of credentials, one place to fix posting |
| Calendar | Read from Odin's `state.db` | Odin syncs `calendar_events` into Muninn; Baldur reads `v_busy_meetings` | No app reads another's private database |
| Authors | `authors` list in config | Muninn `identities`, which every app uses for `is_mine`; empty is still refused | One definition of "me" across Asgard |
| Collection | Scan repos on every run | Incremental sync into Muninn, collected weekly at minimum | Git expires reflog entries after 90 days |
| Sessions | Built per repo (unstated) | One timeline across all repos | Two repos worked in parallel no longer count twice |
| Meeting overlap | Overlap fraction, plus ambient weighting as a "second pass" | Three exclusive policies; `ambient` by default, `overlap` when a day has no meeting times | Applying both discounted meeting time twice |
| Lead-in | Fixed 30m before the first commit | Reflog checkout time when present, 30m otherwise | Evidence replaces an assumption |
| Issue keys | Branch name only | Reflog, branch, PR head branch, then commit message, filtered by `project_keys`; Odin resolves moved keys | Branches are deleted after merge, but GitHub keeps the PR's branch name |
| Pull requests | Not covered | Synced from GitHub, with review-request alerts and a badge on Baldur's tile | Reviews stop waiting in email |
| Defaults | Hand-tuned guesses | Calibrated against hours you log during a trial period; you accept each change | The dials get measured, not guessed |
| AI review | Could raise the total by up to 25%, contradicting its own first rule | May only move time between issues or lower it; rules checked in code | A model's output is checked, not trusted |
| Agent files | `.kiro/agents` and `.kiro/steering` | Prompt ships with Baldur and runs through Asgard's AI tiers: API, MCP or clipboard | Works with whatever AI access is approved |

## The estimation pipeline

Each run estimates a date range with one frozen set of settings, recorded as an `estimate_runs` row. The same commits and settings always give the same numbers.

1. **Collect.** Read your commits from Muninn (`is_mine = 1`), using author time, not commit time, because rebases rewrite commit time. Skip merge commits. Count a cherry-picked change once by matching `git patch-id`.
2. **Find issue keys.** Take each commit's keys from the first source that has any: the reflog checkout, the branch, the pull request's head branch, then the commit message (next section). Keep only keys whose project is in `project_keys`. A commit with two keys splits evenly; a commit with none is untracked.
3. **Build sessions on one timeline.** Sort commits from all repos together. A gap longer than `idle_gap_minutes` starts a new session. Reflog entries inside a session extend it, but reflog alone never creates a session.
4. **Set each session's span.** The start is the first reflog checkout in the session if there is one, otherwise the first commit minus `lead_in_minutes`. The end is the last commit. Clamp to `min_session_minutes` and `max_session_minutes`. Split at local midnight.
5. **Apply the meeting policy.** Under `ambient`, minutes that overlap an event in `v_busy_meetings` count at `ambient_weight`. Under `overlap` and `independent`, they count in full and the day cap does the work (see Meetings and concurrency).
6. **Cap the day.** If the day's session minutes exceed the policy's cap, scale every session down by the same factor.
7. **Attribute.** Split each session's minutes across its issues by commit count. Minutes for untracked commits stay untracked: reported, never logged.
8. **Round down.** Sum per issue per local day, then round down to `round_to_minutes`.
9. **Write the proposal.** Store sessions and one `day_proposals` row per ticket per day, with its basis text and `basis_hash`. A new row supersedes the open one for that day and ticket, and a row whose hash matches one you rejected isn't proposed again.

Commit count, not lines changed, is the attribution weight. A vendored dependency or bulk reformat dwarfs an afternoon of debugging in line counts. Keep that reason as a comment in the code so nobody "optimises" it later.

## Jira keys from branches

Your branches follow `feature/PROJ-123-short-name`, so the key is almost always there; the work is finding it after the branch is gone. Baldur takes each commit's keys from the first source that has any, most reliable first:

| Order | Source | Still there after the branch is deleted? | Example |
| --- | --- | --- | --- |
| 1 | Reflog: the checkout that put you on the branch where you made the commit | For 90 days | `checkout: moving from main to feature/PROJ-123-retry` |
| 2 | Branch: the commit is in `git log main..feature/PROJ-123-retry` | No |  |
| 3 | Pull request: GitHub's head branch for the PR that contains the commit, from `GET /repos/{owner}/{repo}/commits/{sha}/pulls` | Yes | `feature/PROJ-123-retry` |
| 4 | Commit message | Yes | `PROJ-123 retry on 503` |

- **Matching.** A key is `[A-Z][A-Z0-9]+-[1-9][0-9]*` whose project is in `project_keys`, so `UTF-8` and `SHA-256` never match. Any prefix works: `feature/`, `bugfix/`, `hotfix/` or none.
- **Saved at collection.** Baldur stores the branch in `commits.branch_hint` and the key in `commit_work_items` with the source it came from, so a later branch delete changes nothing.
- **Resolved by Odin.** Baldur stores the key as text. Odin looks up any key it hasn't seen (`v_unknown_keys`) and records where it lives now, so a ticket moved from PROJ-123 to OPS-77 needs no rewrite here. Until a key resolves, the review screen flags it and nothing posts for it.
- **Optional commit hook.** Baldur ships a `prepare-commit-msg` hook, off by default, that adds the branch's key to each commit message. With it, source 4 alone is enough even years later.
- **Fixing a miss.** In the review screen you can assign a key to an untracked commit; it's stored with source `manual`.

## Meetings and concurrency

Meetings and coding overlap; treating them as mutually exclusive was the old module's central bug. Exactly one policy applies to each day, so meeting time is never discounted twice.

| Policy | When it applies | Rule | Dev cap |
| --- | --- | --- | --- |
| `ambient` (default) | The day has meeting start and end times | Minutes that overlap a busy meeting count at `ambient_weight` | `max_daily_dev_minutes` |
| `overlap` | Meeting totals are known but not their times | All minutes count in full | `max_daily_dev_minutes − meeting minutes × (1 − concurrent_fraction)` |
| `independent` | No calendar data, or you choose it | All minutes count in full; the day is flagged if meetings plus dev exceed your tour of duty | `max_daily_dev_minutes` |

Every calendar event counts as a meeting except declined, cancelled, all-day, free and out-of-office ones. Tentative events count, which keeps the estimate low. Odin syncs the calendar into Muninn, and the view v\_busy\_meetings applies this filter for Baldur.

### Worked example

Meetings run 09:00–12:00 and 12:30–16:30, 7 hours in all. PROJ-42 gets commits at 09:50, 10:20, 10:55, 11:40, 14:30 and 15:05; PROJ-51 at 12:10 and 12:25. With a 120m gap and 30m lead-in that makes two sessions:

- **Session 1**, 09:20–12:25: 185 minutes, 160 of them during meetings; 4 commits on PROJ-42, 2 on PROJ-51.
- **Session 2**, 14:00–15:05: 65 minutes, all during a meeting; 2 commits on PROJ-42.

| Policy | Day cap | Dev estimate | PROJ-42 | PROJ-51 |
| --- | --- | --- | --- | --- |
| Subtractive (old, removed) | 480 − 420 = 60m | 45m | 45m | 0m |
| `overlap`, fraction 0.5 | 480 − 210 = 270m | 4h00m | 3h00m | 1h00m |
| `ambient`, weight 0.5 | 480m | 2h00m | 1h30m | 30m |
| `independent` | 480m | 4h00m, flagged: 7h + 4h exceeds the day | 3h00m | 1h00m |

Under `ambient`, session 1 counts 160 × 0.5 + 25 = 105 minutes and session 2 counts 32.5, for 137.5 in total. Commit shares give PROJ-42 102.5 minutes and PROJ-51 35, which round down to 1h30m and 30m.

`ambient` is the default because it uses when the commits happened: a morning of calls and a focused afternoon aren't averaged together. Both `ambient_weight` and `concurrent_fraction` start at 0.5 as guesses, and calibration replaces them with measured values.

## Pull requests and review alerts

Baldur tells you when someone asks for your review, and when someone reviews your pull request, so neither waits in email. It only reads GitHub; it never comments, approves or merges.

- **What it syncs.** For each repo with `github_repo` set, your pull requests and their reviews. Across GitHub, every open PR that requests your review, from the search `is:pr is:open review-requested:@me`. A PR in a repo you haven't cloned adds a review-only `repos` row: alerted on, never estimated.
- **When.** Every `poll_minutes` (5) while Baldur runs, using conditional requests, so an unchanged answer doesn't count against GitHub's rate limit. With `run_at_logon`, Baldur starts quietly from your Startup folder, which needs no admin rights.
- **Alerts.** A Windows notification from Baldur's notification-area icon, raised through `Shell_NotifyIcon` from ctypes, so nothing is installed or registered. Clicking it opens the PR. Each request alerts once (`notified_at`), a re-request alerts again, drafts don't alert, and with `quiet_outside_tour` alerts wait for your tour of duty. If policy blocks notifications, the tile badge still works.
- **Reviews of your PRs.** An approval or a request for changes alerts you once per review (`pr_reviews.notified_at`).
- **The tile.** Asgard's launcher reads `v_tile_badges`, so Baldur's tile shows "2 reviews requested" even while Baldur is closed.
- **Access.** A read-only token (pull requests and metadata) in Credential Manager, for GitHub Enterprise or github.com per `github_api`. Without one, Baldur works from local git and hides these features.
- **In the day report.** Reviews you wrote show as visible work, not logged time (open decision).

## Muninn: what Baldur reads and writes

Baldur owns 13 Muninn tables, all in `muninn_schema.sql` v1; the additions this spec once proposed as a migration are folded in. The Muninn design doc has every column, and its test script checks every rule below.

| Table or view | Baldur | Notes |
| --- | --- | --- |
| `identities`, `sources`, `meta` | Reads | Your git emails and GitHub login decide `is_mine`; no identity, no run |
| `repos`, `commits`, `commit_work_items`, `reflog_entries` | Writes (owner) | Incremental, via `sync_cursors`; metadata only |
| `pull_requests`, `pr_reviews` | Writes (owner) | From GitHub; drive the alerts and the tile badge |
| `estimate_runs`, `work_sessions`, `session_commits`, `session_allocations`, `day_proposals` | Writes (owner) | Each run's frozen settings and results |
| `calibration_runs`, `time_actuals` | Writes (owner) | Trial hours and fitted settings |
| `work_item_aliases`, `work_items` | Reads | Resolve keys; titles and status in the review screen |
| `v_busy_meetings` | Reads | Odin's calendar, filtered to time you were busy |
| `v_day_status` | Reads | Per day and ticket: your approval and the development time Jira already holds |
| `worklogs` | Reads | Posted or failed, shown beside each day |
| `events` | Appends | `estimate_run.created`, `day_proposal.approved`, `calibration.accepted` |
| `event_cursors` | Its own row | Reads `worklog.posted`, `worklog.failed` and `work_item.moved` |

Four database rules carry the principles: rounding can't raise a number, an approval needs a decision time and final minutes, untracked minutes can never be approved, and a decided proposal can't be edited, only superseded by a new row in the same transaction.

## Settings

Baldur's settings live in `%LOCALAPPDATA%\Asgard\settings\baldur.json`, created with these defaults on first run. A file that won't parse falls back to the defaults with a warning, as `apps.local.json` does. Each run copies its settings into `estimate_runs.params`, so changing a default never changes past numbers.

Your git identities aren't a Baldur setting: they live in Muninn's `identities`, shared with every app. On first run Baldur offers the email from `git config user.email` and refuses to estimate with none. That prevents logging the whole team's commits to one timesheet.

| Key | Default | Meaning |
| --- | --- | --- |
| `repo_roots` | `[]` | Folders to search for repositories. Found repos go into Muninn `repos`, where each can be switched off |
| `max_depth` | `3` | How deep to search under each root; never the whole disk |
| `project_keys` | `[]` | Jira projects to recognise, such as `["PROJ", "OPS"]`. Empty is refused |
| `idle_gap_minutes` | `120` | A gap longer than this starts a new session; the most influential setting |
| `lead_in_minutes` | `30` | Time before a session's first commit, used only when there's no reflog checkout |
| `min_session_minutes` | `15` | Floor, so a lone commit isn't zero |
| `max_session_minutes` | `240` | Ceiling, so commits at 09:00 and 17:00 aren't one 8-hour session |
| `max_daily_dev_minutes` | `480` | Development ceiling per day |
| `policy` | `"ambient"` | `ambient`, `overlap` or `independent`; see Meetings and concurrency |
| `ambient_weight` | `0.5` | Share of an overlapping minute that counts, under `ambient` |
| `concurrent_fraction` | `0.5` | Share of meeting time assumed usable for coding, under `overlap` |
| `round_to_minutes` | `15` | Each ticket's daily total rounds down to this |
| `tour_of_duty` | `{"start": "07:30", "end": "16:00", "unpaid_minutes": 30}` | Flags long days in the report and sets quiet hours for alerts |
| `github_api` | `""` | `https://api.github.com`, or your Enterprise host's `/api/v3`. Empty turns pull request features off |
| `poll_minutes` | `5` | How often Baldur checks GitHub while it runs |
| `alerts` | `true` | Windows notifications for review requests and reviews of your PRs |
| `quiet_outside_tour` | `true` | Hold alerts outside your tour of duty |
| `run_at_logon` | `false` | Start Baldur in the notification area at logon, from your Startup folder |
| `commit_hook` | `false` | Install the `prepare-commit-msg` hook that adds the branch's key to commit messages |
| `review_mode` | `"off"` | AI review: `off`, `metadata` or `content` |

Four old settings are gone on purpose. Approval can't be switched off and untracked minutes can't be logged; the database refuses both rather than trusting a flag. `output` is gone because Odin posts, and `calendar_source` because Odin syncs the calendar.

## Review, approval and logging

You review in Baldur's window, opened from its Asgard tile. Each day shows a reconciliation report and one row per ticket, with what Jira already holds beside each proposal. You can edit any figure, then approve or reject the day. Odin posts approved days on its next run; Copy for timesheet puts the day on the clipboard for anything Odin doesn't reach.

### The day report

The report matters more than the per-ticket numbers. It shows what was measured, what was estimated, and what Baldur can't see. Here is the worked example day:

```text
Thu 2026-10-01                                      policy: ambient
  Meetings (calendar)                    7h00m   Odin logs these separately
  Development (estimated from git)       2h00m   PROJ-42 1h30m, PROJ-51 30m
  Already in Jira for these tickets        30m   PROJ-42, logged by hand
  Odin will post once approved           1h30m   PROJ-42 1h00m, PROJ-51 30m
  Untracked commits (no Jira key)          0m
  Pull request reviews (not logged)      1       asgard#7
  ------------------------------------------------
  Accounted                              9h00m
  Tour of duty                           8h00m   07:30-16:00, 30m unpaid
  Overlap assumed                        1h00m   coding during calls

  Not visible to Baldur: design talk, reading code, messages, planning.
  If the day felt fuller than this, that is the gap.
```

### The basis

Every approved figure stores its derivation in `day_proposals.basis`. Odin posts that text as the Jira worklog comment, ending with a marker it uses to recognise its own worklog after a crash, so the number can be defended months later without re-deriving it:

```text
Baldur estimate: 1h30m for PROJ-42 on 2026-10-01
Basis: 6 commits in 2 sessions (09:20-12:25, 14:00-15:05), repo asgard
Model: baldur-1, policy ambient 0.5, gap 120m, lead-in 30m, rounded down to 15m (run 41)
Meetings that day: 7h00m, logged separately
Already in Jira: 30m, logged by hand; this worklog adds 1h00m
Reviewed: AI review moved 15m to PROJ-51 ("retry rework is the larger change")
Approved: 2026-10-01 17:02
[asgard:p412:9f3c1a2b]
```

`basis_hash` covers the model version, settings, commit SHAs and meeting IDs. A re-run with the same hash has nothing new to say; a different hash shows whether the evidence or the settings changed.

### Logging only the difference

- **Approving** records the total you agreed for each ticket and day. Changing it later supersedes that approval with a new row; the old one stays as history.
- **Re-running** compares against what Jira already holds for that day and ticket from any origin: Odin's earlier posts, worklogs you typed into Jira, and posts in flight. New commits show up as an addition to approve, never as a second copy.
- **Posting** sends only approved minus held, from `v_worklogs_to_post`, and each approval posts at most once. Meeting time Odin logs doesn't count against it, because the estimate already leaves meetings out.
- **Never retract.** If a new figure is lower than what Jira holds, Baldur shows the gap; nothing edits or deletes time in Jira. A worklog you delete there isn't re-posted until you approve the day again.
- **Crash-safe.** Odin writes a sending row before calling Jira and looks for its marker after a crash, so the same time can't post twice.

### Calibration

The 0.5 weights and 120-minute gap are guesses until measured. Calibration measures them:

1. During a trial of 2–4 weeks, note your real hours each day in Baldur, as a day total and per ticket where you can. They go into `time_actuals`.
2. Baldur searches gap 60–180m, lead-in 0–60m and ambient weight 0.3–0.8, looking for the lowest daily error **among settings that estimate low on average**, which keeps the bias downward.
3. It shows the old and new error side by side. Accepting creates an active `calibration_runs` row and updates `baldur.json`; nothing changes automatically, and past runs keep their settings.

## Optional AI review

Commit counts can't tell five typo fixes from one hard debugging session; a model reading commit subjects can. The review only moves time between tickets or lowers it, and Baldur checks every reply in code before showing it. It is off by default and never posts anything.

### How it runs

The review uses whichever of Asgard's AI tiers you have:

- **API:** Baldur sends the day's evidence to an approved endpoint and uses its smallest model.
- **MCP:** Ysildir exposes the day's evidence and the review prompt; your AI client returns the reply.
- **Clipboard:** Baldur copies evidence and prompt; you paste the reply back into Baldur.

### Privacy gate

`review_mode` decides what leaves the machine, and setting it is a data-handling decision, not a convenience:

- **`metadata`** (recommended): commit subjects, file paths, line counts, times, ticket keys and session IDs. No code.
- **`content`:** adds diff hunks. Raise this with your ISSO before turning it on.

Commit subjects carry most of the signal: "rework retry logic" shows a commit was substantial without shipping the retry logic.

### The reply, checked in code

The model must return JSON. Baldur rejects the whole reply, shows why, and keeps the baseline if any check fails:

1. The adjustments sum to zero or less: the day's total never rises.
2. Every adjustment names a ticket already in the baseline, and none goes below zero.
3. Every adjustment cites at least one commit SHA or session ID from the evidence sent.
4. At most 10 adjustments; the result is rounded down again.

Accepted adjustments appear as suggestions you take or leave per ticket, stored in `day_proposals.review` with the prompt version.

### The prompt

It ships as `apps/baldur/prompts/review.md`, and its version is recorded with each review.

```markdown
You adjust a development-time estimate that was calculated from git history.
You don't estimate from scratch and you can't post anything.

Input: for one day, the baseline minutes per Jira ticket, the sessions (id, start,
end, commit SHAs), each commit's subject and line counts, and which session
minutes overlapped meetings.

Return only this JSON:
{"day": "YYYY-MM-DD",
 "adjustments": [{"ticket": "KEY-1", "minutes": -15, "confidence": "high|medium|low",
                  "evidence": ["<sha or session id>"], "reason": "<one sentence>"}],
 "flags": ["<anything the person should check before approving>"]}

Rules, in priority order:
1. Never raise the day's total. Move minutes between tickets, or lower them.
2. Cite evidence for every adjustment: a commit SHA or session id from the input.
3. Prefer moving time to removing it. Commit counts are a crude weight: five trivial
   commits on one ticket and one hard commit on another is the usual error.
4. When two readings are equally plausible, choose the smaller.
5. Use low confidence freely, and flag instead of guessing.
6. Never invent work. Note in flags if the day looks under-represented, but add no time.
```

## Edge cases

Each rule errs low, matching the principles.

| Case | Rule |
| --- | --- |
| Rebased or amended commits | Use author time; count each SHA once, then each `patch-id` once |
| Squash merges | Skip a squash commit when its message cites a pull request of yours whose branch commits are already collected |
| Branch deleted after merge | The PR's head branch and the saved `branch_hint` still carry the key |
| An issue moved to another project | The old key stays in Baldur's tables; Odin's alias resolves it, and the review screen shows the new key |
| A key Jira doesn't know | Flagged in review and never posted; Odin checks it again after 7 days |
| Two repos worked in parallel | One timeline across repos, so overlapping work isn't counted twice |
| A commit naming two tickets | Split its share evenly |
| Co-authored commits | Count only commits you authored; list `Co-authored-by` ones in the report |
| A session across midnight | Split at local midnight; each part belongs to its own day |
| Time zones and daylight saving | Convert with Windows' local time through the standard library; Muninn's day bounds handle a 25-hour day |
| Dates older than 90 days | Reflog is gone, so lead-in falls back to 30m; the report says so |
| Days with no calendar data | Use `independent` and flag the day |
| Meetings Odin logs | Used only to weight overlap; their worklogs don't count against development time |
| Time you logged in Jira by hand | Counted as already held, so Odin posts only the rest |
| A worklog you delete in Jira | Not re-posted until you approve that day again |
| A review requested in a repo you haven't cloned | Added as a review-only repo; alerted on, never estimated |
| Vendored or reformatted code | No effect: attribution counts commits, not lines |
| Future-dated or skewed commit times | Excluded and flagged |
| Weekends and leave days | Estimated like any day and flagged against your tour of duty; nothing is approved automatically |
| Odin and Baldur writing at once | Muninn runs in WAL mode: readers never wait, and a writer waits up to 5 seconds for the other's transaction |

## Build order

Steps 1–7 deliver review alerts and the report-only product. Posting starts once a trial shows the numbers are sound.

1. **Muninn writer module** (`asgard/muninn/`) with schema v1, which already holds Baldur's tables. Every later step writes through it.
2. **Port and fix.** Move `gitwork.py` and its 34 tests into `apps/baldur/`, then replace the subtractive cap with the three policies. The worked example becomes a named test.
3. **Git collector.** Repo discovery, commits with `patch-id`, reflog, keys in the four-source order, and first-run identity setup, synced incrementally into Muninn. It runs from the window or a weekly per-user scheduled task, because reflog expires.
4. **GitHub.** Pull requests and reviews, the review-request search, alerts and the tile badge. Without a token, this step switches itself off.
5. **Odin on Muninn.** Odin writes `work_items`, aliases, `calendar_events` and `worklogs` through `asgard.muninn` and answers `v_unknown_keys`. Until then Baldur shows keys unresolved and meeting policy falls back to `independent`.
6. **Estimator.** Writes `estimate_runs`, sessions and `day_proposals`, with basis text and `basis_hash` from the first version, so the audit trail is never retrofitted.
7. **Baldur window.** Week view, day report, edit, approve, Copy for timesheet. `apps/baldur/baldur.pyw` adds `ASGARD_APP` to its import path to reach `asgard.muninn`, and its tile in `apps.json` changes to `"status": "available"` with `"target": "{app}\\apps\\baldur\\baldur.pyw"`.
8. **Trial and calibration.** Two to four weeks of real hours, then fitted settings you accept.
9. **Odin posting.** Odin reads `v_worklogs_to_post` and posts with the sending-row safeguard; Baldur shows posted and failed beside each day.
10. **AI review**, last: an optional refinement on a baseline that already works.

## Tests

Tests check the direction of bias, not just exact values. Proving a cap or rounding never raises a number is worth more than pinning one minute count. Use real temporary git repositories, as the existing 34 tests do, rather than a mocked `subprocess`.

- **Direction:** every cap, rounding and scaling step leaves each number equal or lower, over randomised inputs.
- **Worked example:** the meetings-plus-commits day gives 2h00m under `ambient`, 4h00m under `overlap`, and never the old 45 minutes.
- **No double discount:** for any day, `ambient` minutes never fall below what a single discount would give, so the policies can't compound.
- **One timeline:** commits interleaved across two repos produce one set of sessions.
- **Keys:** a commit on a deleted branch still gets its key from the PR's head branch; `UTF-8` never matches; a key outside `project_keys` is ignored.
- **Deltas:** approve 2h with 30m already logged by hand and Odin is offered 1h30m; re-approve at 2h30m and it's offered 30m more; re-run with no new commits and nothing is offered.
- **Never retract:** a lower re-estimate reports the gap and leaves Jira alone.
- **Hash:** `basis_hash` changes when settings change and stays the same when nothing does.
- **Alerts:** one alert per review request, another after a re-request, none for drafts.
- **Schema:** Muninn's 119-check script covers the database rules, including a rounded-up proposal, an approval without a decision time, an approved untracked row and an edited decision.
- **AI review:** replies that raise the total, invent a ticket, or cite missing evidence are rejected.
- **Identity:** an empty identity list or empty `project_keys` refuses to run.

## Open decisions

- [ ] **Post, or report only?** A report you paste into your own timesheet sidesteps a tool writing inferred hours into an official system, and may be the better product. Nothing before step 9 depends on the answer.
- [ ] **Odin's move to Muninn.** Move Odin's Jira cache into Muninn (recommended), or have Odin mirror into it after each sync. Either way Odin must answer `v_unknown_keys` and read `v_worklogs_to_post`.
- [ ] **Odin's calendar fields.** Confirm Odin's meeting sync has start, end, show-as and your response, so `calendar_events` is complete.
- [ ] **GitHub access.** Is a read-only token allowed, and is it GitHub Enterprise or github.com?
- [ ] **Alerts.** Notifications from Baldur running at logon, or only the tile badge when Asgard is open? Some images block notifications by policy.
- [ ] **AI review.** Is an AI tool on the workstation approved for this use, and in `metadata` or `content` mode?
- [ ] **Pull request reviews.** Show them in the day report only, or let them become loggable time later?
- [ ] **Trial length.** Two weeks or four of real hours before the first calibration.
