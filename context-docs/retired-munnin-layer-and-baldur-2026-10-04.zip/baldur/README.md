# Baldur: development-time proposals from git

Baldur reads your own git history and proposes how much development time to log against each
Jira ticket, per day. It only proposes. You approve in Baldur's window, and Odin posts approved
days to Jira. Baldur never writes to Jira and never reads another app's private database; all
state goes through Muninn (`munnin-layer/`).

Every number is biased down and carries its basis: the commits, sessions, meetings and policy
that produced it. It is an estimate, and the report says so.

Spec: `Baldur spec work-time estimates from git-2.md` (v2).

## Running it

Standard library only, Python 3.8+, git on `PATH`. Put both source folders on `PYTHONPATH`, or set
`ASGARD_APP` to the folder holding `asgard/muninn`:

```
PYTHONPATH=src:../munnin-layer/src python3 -m baldur init --email you@agency.gov
PYTHONPATH=src:../munnin-layer/src python3 -m baldur collect --days 30
PYTHONPATH=src:../munnin-layer/src python3 -m baldur report          # shows days, writes nothing
PYTHONPATH=src:../munnin-layer/src python3 -m baldur estimate        # records proposals in Muninn
PYTHONPATH=src:../munnin-layer/src python3 -m baldur doctor
```

| Command | What it does |
|---|---|
| `init [--email E]...` | Creates the settings file and records your git author e-mails as Muninn identities. Without `--email` it offers `git config --global user.email`. |
| `collect [--days N] [--full]` | Reads repos under `repo_roots` into Muninn: commits (numstat, no diff text), patch-ids, key links, reflog checkouts. Re-reads a 14-day overlap each run. |
| `report [--days 6]` | Estimates and prints day reports. Writes nothing. |
| `estimate [--days 6]` | Same, and records an estimate run plus `day_proposals`. A proposal whose basis hasn't changed is skipped. |
| `doctor` | Settings, git, Muninn schema, identities, calendar data. |

Exit codes: `0` ok, `1` finished with warnings, `2` setup or configuration problem, `130` interrupted.

## Settings

`%LOCALAPPDATA%\Asgard\settings\baldur.json` (or `$ASGARD_HOME/settings/baldur.json`). A bad value
falls back to its default with a warning; it doesn't stop the run. Removed v1 keys are named in a
warning that says what replaced them.

| Key | Default | Meaning |
|---|---|---|
| `repo_roots` | `[]` | Folders to search for repositories |
| `max_depth` | `3` | How deep to search under each root (0–10) |
| `project_keys` | `[]` | Jira project keys to recognise, e.g. `["PROJ"]` |
| `idle_gap_minutes` | `120` | A gap longer than this starts a new session |
| `lead_in_minutes` | `30` | Time credited before a session's first commit when no reflog checkout explains it |
| `min_session_minutes` / `max_session_minutes` | `15` / `240` | Session length clamp |
| `max_daily_dev_minutes` | `480` | Daily cap (1–1440) |
| `policy` | `ambient` | `ambient`, `overlap` or `independent`; see below |
| `ambient_weight` | `0.5` | Share of meeting time deducted under `ambient` |
| `concurrent_fraction` | `0.5` | Used by `overlap` |
| `round_to_minutes` | `15` | Per-ticket day totals round **down** to this |
| `tour_of_duty` | `07:30`–`16:00`, 30 unpaid | Used for the cap and the exceeded flag |
| `github_api`, `poll_minutes`, `alerts`, `quiet_outside_tour`, `run_at_logon`, `commit_hook`, `review_mode` | | Validated and stored; the features behind them aren't built yet |

## How a day is estimated

1. Commits are deduplicated by patch-id (rebases and cherry-picks count once). Merges are skipped.
2. Sessions: commits closer than `idle_gap` join a session. It starts at the earliest reflog
   checkout within `idle_gap` before the first commit, otherwise at the lead-in. Sessions are
   clamped, never overlap the previous one, and split at local midnight.
3. Ticket keys come from the reflog branch, then branch membership, then the commit message,
   filtered by `project_keys`. A commit with two keys splits evenly. Commits with no key go to
   an untracked bucket that can be shown but never logged.
4. One policy per day:
   - `ambient` needs meeting times. Meeting time inside a session is deducted at `ambient_weight`.
   - `overlap` needs meeting totals. The deduction rounds up.
   - `independent` when there's no calendar data for the day. The day is flagged if it exceeds the tour of duty.
5. Minutes stay fractional until the per-ticket day total, which rounds down and is capped.

`basis_hash` (model version, params, commit SHAs, meeting IDs) identifies a proposal's basis.
Re-running with no change proposes nothing new. Changing an approved day supersedes it in one
transaction (`change_approval`).

## Status against the spec's build steps

Built:
- Step 2: key finding.
- Step 3: the estimator, including the worked example. Tests reproduce it exactly: overlap 180/60, ambient 90/30, independent 180/60 flagged.
- Step 6: proposals and the approval bookkeeping in Muninn.
- The CLI.

Partly built: step 1, Muninn. Migration `0004_baldur_v2.sql`:
- adds the `reflog` and `pull_request` link methods;
- freezes decided proposals;
- makes the day-proposal uniqueness index ignore superseded rows.

Not built:
- **Pieces that depend on the newer Muninn schema.** The spec assumes one the repo doesn't have:
  `work_item_aliases`, `v_unknown_keys`, `v_worklogs_to_post`, `event_cursors`, `v_tile_badges`,
  `accomplishments`, `pr_reviews.notified_at` and `repos.github_repo` aren't defined anywhere.
  Key aliases, the posting view, badges and accomplishments wait on that schema.
- **GitHub (step 4).** Pull requests, review alerts and the PR key source need a token and those columns.
- **Odin on Muninn (step 5).** Until Odin writes `calendar_events`, every day is `independent`.
  Muninn's `ownership.py` still lists Baldur as that table's owner; per the spec it should be Odin.
- **The window (step 7).** `src/baldur/ui/` is a placeholder.
- **Calibration and AI review.**

Nothing has been run on the Windows workstation yet. In particular, its Python's SQLite still
needs checking (3.37+ with FTS5, which Muninn requires).

## Tests

```
KIRO_ALLOW_RAW_TESTS=1 python3 -W error::ResourceWarning -m unittest discover -s tests
```

70 tests, no network. Git cases build throwaway repos in a temp folder.
