"""Shared test helpers: fixed times, in-memory commits, and REAL temporary git repositories.

Git-backed tests use actual `git init` repositories, not a mocked subprocess: a mock only proves the
parser accepts what we assumed git prints, which is the assumption most likely to be wrong. Identity
and signing are passed per command with `-c`, so a developer's global `commit.gpgsign=true` cannot
make a test block on a passphrase, and their real git config is never touched.
"""
from __future__ import annotations

import os
import shutil
import subprocess
import sys
import tempfile
import unittest
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT.parent / "munnin-layer" / "src"))

from baldur.estimate import CommitIn, Meeting  # noqa: E402

UTC = timezone.utc
HAVE_GIT = shutil.which("git") is not None
EMAIL = "me@agency.gov"


def at(hour: int, minute: int = 0, day: int = 1) -> datetime:
    return datetime(2026, 10, day, hour, minute, tzinfo=UTC)


def commit(hour: int, minute: int = 0, *keys: str, day: int = 1, repo: str = "asgard",
           patch: Optional[str] = None) -> CommitIn:
    return CommitIn(sha="{}-{:02d}{:02d}{:02d}".format(repo, day, hour, minute), repo=repo,
                    authored_at=at(hour, minute, day), keys=tuple(keys), patch_id=patch)


def worked_example():
    """The spec's worked example: calls 09:00-12:00 and 12:30-16:30; PROJ-42 at 09:50, 10:20,
    10:55, 11:40, 14:30, 15:05; PROJ-51 at 12:10 and 12:25."""
    commits = [commit(9, 50, "PROJ-42"), commit(10, 20, "PROJ-42"), commit(10, 55, "PROJ-42"),
               commit(11, 40, "PROJ-42"), commit(14, 30, "PROJ-42"), commit(15, 5, "PROJ-42"),
               commit(12, 10, "PROJ-51"), commit(12, 25, "PROJ-51")]
    meetings = [Meeting("m1", at(9), at(12)), Meeting("m2", at(12, 30), at(16, 30))]
    return commits, meetings


NOW = datetime(2026, 10, 2, 12, 0, tzinfo=UTC)


class TempHome(unittest.TestCase):
    """Isolated ASGARD_HOME: settings and Muninn live in a temp folder, never the real profile."""

    def setUp(self):
        self.home = Path(tempfile.mkdtemp(prefix="baldur-home-"))
        self.addCleanup(shutil.rmtree, self.home, True)
        self._old = os.environ.get("ASGARD_HOME")
        os.environ["ASGARD_HOME"] = str(self.home)
        self.addCleanup(self._restore)

    def _restore(self):
        if self._old is None:
            os.environ.pop("ASGARD_HOME", None)
        else:
            os.environ["ASGARD_HOME"] = self._old


class GitCase(TempHome):
    def setUp(self):
        super().setUp()
        if not HAVE_GIT:
            self.skipTest("git is not installed")
        self.work = Path(tempfile.mkdtemp(prefix="baldur-repos-"))
        self.addCleanup(shutil.rmtree, self.work, True)

    def git(self, repo: Path, *args: str, when: Optional[datetime] = None, email: str = EMAIL) -> str:
        env = dict(os.environ)
        if when is not None:
            stamp = when.strftime("%Y-%m-%dT%H:%M:%S+00:00")
            env["GIT_AUTHOR_DATE"] = env["GIT_COMMITTER_DATE"] = stamp
        done = subprocess.run(["git", "-c", "commit.gpgsign=false", "-c", "user.name=Me",
                               "-c", "user.email=" + email, "-C", str(repo)] + list(args),
                              stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=env)
        if done.returncode != 0:
            self.fail("git {} failed: {}".format(args[0], done.stderr.decode()))
        return done.stdout.decode()

    def repo(self, name: str = "asgard") -> Path:
        path = self.work / name
        path.mkdir(parents=True)
        self.git(path, "init", "-q")
        self.git(path, "symbolic-ref", "HEAD", "refs/heads/main")   # portable: no `init -b`
        return path

    def commit_file(self, repo: Path, message: str, when: datetime, name: str = "f.txt",
                    email: str = EMAIL) -> str:
        with open(str(repo / name), "a", encoding="utf-8") as fh:
            fh.write(message + "\n")
        self.git(repo, "add", name)
        self.git(repo, "commit", "-q", "-m", message, when=when, email=email)
        return self.git(repo, "rev-parse", "HEAD").strip()
