"""Jira keys, settings and the report text."""
import json
import unittest

from helpers import NOW, TempHome, worked_example

from baldur import estimate as est
from baldur import report, settings
from baldur.errors import SetupError
from baldur.keys import KeyMatcher, branch_from_checkout

UTC = est.timezone.utc


class Keys(unittest.TestCase):

    def setUp(self):
        self.m = KeyMatcher(["PROJ", "OPS"])

    def test_branch_shapes_and_prefixes(self):
        for text, expected in [("feature/PROJ-123-retry", ["PROJ-123"]), ("bugfix/OPS-7", ["OPS-7"]),
                               ("hotfix/PROJ-1_x", ["PROJ-1"]), ("PROJ-9", ["PROJ-9"]),
                               ("PROJ-1 and OPS-2", ["PROJ-1", "OPS-2"]), ("PROJ-1 PROJ-1", ["PROJ-1"])]:
            with self.subTest(text=text):
                self.assertEqual(self.m.find(text), expected)

    def test_UTF_8_SHA_256_and_other_projects_never_match(self):
        for text in ("fix UTF-8 handling", "use SHA-256", "ISO-8601 dates", "OTHER-12", "proj-12",
                     "XPROJ-1", "PROJ-1X", "PROJ-0", ""):
            with self.subTest(text=text):
                self.assertEqual(self.m.find(text), [])

    def test_empty_or_malformed_project_keys_are_refused(self):
        for bad in ([], ["", " "], ["P"], ["PROJ-1"], ["1PROJ"]):
            with self.subTest(bad=bad), self.assertRaises(SetupError):
                KeyMatcher(bad)

    def test_project_keys_are_case_normalised(self):
        """Jira project keys are upper case; "proj" in a hand-edited setting means PROJ."""
        self.assertEqual(KeyMatcher(["proj"]).find("feature/PROJ-1"), ["PROJ-1"])

    def test_the_first_source_with_any_key_wins(self):
        self.assertEqual(self.m.resolve("feature/PROJ-1-a", ["feature/PROJ-2-b"], "feature/PROJ-3", "PROJ-4"),
                         (["PROJ-1"], "reflog"))
        self.assertEqual(self.m.resolve(None, ["feature/PROJ-2-b"], None, "PROJ-4"), (["PROJ-2"], "branch"))
        self.assertEqual(self.m.resolve(None, [], "feature/PROJ-3", "PROJ-4"), (["PROJ-3"], "pull_request"))
        self.assertEqual(self.m.resolve(None, [], None, "PROJ-4 retry"), (["PROJ-4"], "message"))
        self.assertEqual(self.m.resolve(None, ["chore/tidy"], None, "tidy"), ([], None))

    def test_a_source_with_no_recognised_key_falls_through(self):
        """A branch named after another team's project is not a key source for you."""
        self.assertEqual(self.m.resolve("feature/OTHER-1", [], None, "PROJ-5"), (["PROJ-5"], "message"))

    def test_checkout_messages(self):
        self.assertEqual(branch_from_checkout("checkout: moving from main to feature/PROJ-1-x"), "feature/PROJ-1-x")
        self.assertIsNone(branch_from_checkout("commit: something"))


class Settings(TempHome):

    def test_first_run_creates_the_file_with_the_spec_defaults(self):
        loaded = settings.load()
        self.assertTrue(settings.settings_path().is_file())
        self.assertEqual(loaded["policy"], "ambient")
        self.assertEqual(loaded["tour_of_duty"], {"start": "07:30", "end": "16:00", "unpaid_minutes": 30})
        self.assertEqual(loaded.warnings, [])

    def test_an_unreadable_file_falls_back_to_defaults_with_a_warning(self):
        settings.settings_path().parent.mkdir(parents=True, exist_ok=True)
        settings.settings_path().write_text("{ broken", encoding="utf-8")
        loaded = settings.load()
        self.assertEqual(loaded["idle_gap_minutes"], 120)
        self.assertTrue(any("could not be read" in w for w in loaded.warnings))

    def write(self, **values):
        settings.settings_path().parent.mkdir(parents=True, exist_ok=True)
        settings.settings_path().write_text(json.dumps(values), encoding="utf-8")
        return settings.load()

    def test_a_bad_value_falls_back_for_that_key_only(self):
        loaded = self.write(idle_gap_minutes=90, ambient_weight=7, project_keys="PROJ")
        self.assertEqual(loaded["idle_gap_minutes"], 90)
        self.assertEqual(loaded["ambient_weight"], 0.5)
        self.assertEqual(loaded["project_keys"], [], "a bare string is refused, not read as letters")
        self.assertEqual(len(loaded.warnings), 2)

    def test_removed_settings_are_warned_about_with_the_reason(self):
        loaded = self.write(authors=["me@x.gov"], require_review=False, output="jira")
        self.assertEqual(len(loaded.warnings), 3)
        self.assertTrue(any("cannot be switched off" in w for w in loaded.warnings))
        self.assertTrue(any("Odin posts" in w for w in loaded.warnings))

    def test_github_api_must_be_https(self):
        self.assertEqual(self.write(github_api="http://github.example.gov/api/v3")["github_api"], "")

    def test_settings_become_params(self):
        params = self.write(policy="overlap", tour_of_duty={"start": "08:00", "end": "17:00", "unpaid_minutes": 60}).params()
        self.assertEqual((params.policy, params.tour_start, est.tour_minutes(params)), ("overlap", "08:00", 480))


class Report(unittest.TestCase):

    def setUp(self):
        commits, meetings = worked_example()
        self.params = est.Params()
        self.day = est.estimate(commits, self.params, meetings=meetings, tz=UTC, now=NOW).days[0]

    def test_hm_never_rounds_up(self):
        self.assertEqual([report.hm(x) for x in (0, 29.99, 45, 60, 90, 102.5)],
                         ["0m", "29m", "45m", "1h00m", "1h30m", "1h42m"])

    def test_the_basis_matches_the_spec_example(self):
        text = "\n".join(report.basis_lines(self.day.tickets["PROJ-42"], self.day, self.params, UTC, run_id=41))
        self.assertIn("Baldur estimate: 1h30m for PROJ-42 on 2026-10-01", text)
        self.assertIn("Basis: 6 commits in 2 sessions (09:20-12:25, 14:00-15:05), repo asgard", text)
        self.assertIn("Model: baldur-1, policy ambient 0.5, gap 120m, lead-in 30m, rounded down to 15m (run 41)", text)
        self.assertIn("Meetings that day: 7h00m, logged separately", text)

    def test_the_day_report_separates_measured_from_estimated_and_names_the_gap(self):
        text = "\n".join(report.day_report_lines(self.day, self.params, UTC, already_in_jira={"PROJ-42": 30}))
        for expected in ("policy: ambient", "Meetings (calendar)                    7h00m",
                         "Development (estimated from git)       2h00m   PROJ-42 1h30m, PROJ-51 30m",
                         "Odin will post once approved           1h30m   PROJ-42 1h00m, PROJ-51 30m",
                         "Accounted                              9h00m", "Overlap assumed                        1h00m",
                         "Not visible to Baldur"):
            self.assertIn(expected, text)


if __name__ == "__main__":
    unittest.main()
