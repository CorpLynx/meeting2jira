"""git -> Muninn -> estimate -> Muninn, on real repositories and a real Muninn database."""
import json
import unittest
from datetime import datetime, timedelta, timezone

from helpers import EMAIL, GitCase, at

from baldur import collector, gitscan, service, settings
from baldur.__main__ import main
from baldur.errors import SetupError
from baldur.muninn_link import open_baldur

UTC = timezone.utc
NOW = datetime(2026, 10, 2, 12, 0, tzinfo=UTC)


class Base(GitCase):

    def setUp(self):
        super().setUp()
        self.r = self.repo("asgard")
        settings.settings_path().parent.mkdir(parents=True, exist_ok=True)
        settings.settings_path().write_text(json.dumps({
            "repo_roots": [str(self.work)], "project_keys": ["PROJ"]}), encoding="utf-8")
        self.settings = settings.load()
        self.m = open_baldur()
        self.addCleanup(self.m.close)
        self.m.add_identity("git_email", EMAIL)

    def collect(self):
        return collector.collect(self.m, self.settings)

    def links(self):
        return {r[0]: (r[1], r[2]) for r in self.m.conn.execute(
            "SELECT c.subject, l.work_item_key, l.method FROM commits c JOIN commit_work_items l "
            "ON l.commit_id = c.id")}


class KeySources(Base):

    def test_the_reflog_supplies_the_key_after_the_branch_is_deleted(self):
        self.commit_file(self.r, "init", at(8))
        self.git(self.r, "checkout", "-q", "-b", "feature/PROJ-42-retry")
        self.commit_file(self.r, "no key in this subject", at(9))
        self.git(self.r, "checkout", "-q", "main")
        self.git(self.r, "merge", "-q", "--ff-only", "feature/PROJ-42-retry")
        self.git(self.r, "branch", "-q", "-d", "feature/PROJ-42-retry")
        self.collect()
        self.assertEqual(self.links()["no key in this subject"], ("PROJ-42", "reflog"))

    def test_branch_membership_when_the_reflog_has_no_record(self):
        self.commit_file(self.r, "init", at(8))
        self.git(self.r, "checkout", "-q", "-b", "feature/PROJ-7-x")
        self.commit_file(self.r, "work", at(9))
        self.git(self.r, "reflog", "expire", "--expire=all", "--all")       # as if 90 days passed
        self.collect()
        self.assertEqual(self.links()["work"], ("PROJ-7", "branch"))

    def test_the_message_is_the_last_resort(self):
        self.commit_file(self.r, "PROJ-9 retry on 503", at(9))
        self.collect()
        self.assertEqual(self.links()["PROJ-9 retry on 503"], ("PROJ-9", "message"))

    def test_trunk_history_is_not_credited_to_a_feature_branch(self):
        for i in range(3):
            self.commit_file(self.r, "trunk {}".format(i), at(8, i))
        self.git(self.r, "checkout", "-q", "-b", "feature/PROJ-42-x")
        self.commit_file(self.r, "branch work", at(9))
        self.git(self.r, "reflog", "expire", "--expire=all", "--all")
        self.collect()
        self.assertEqual(set(self.links()), {"branch work"})

    def test_keys_outside_project_keys_and_UTF_8_are_untracked(self):
        self.commit_file(self.r, "fix UTF-8 and OTHER-1", at(9))
        result = self.collect()
        self.assertEqual((self.links(), result.untracked), ({}, 1))


class Collection(Base):

    def test_only_your_commits_are_mine_and_merges_are_skipped(self):
        self.commit_file(self.r, "mine", at(9))
        self.commit_file(self.r, "theirs", at(10), email="someone@agency.gov")
        self.collect()
        rows = dict(self.m.conn.execute("SELECT subject, is_mine FROM commits"))
        self.assertEqual(rows, {"mine": 1, "theirs": 0})

    def test_merge_commits_are_not_collected(self):
        """Spec step 1: skip merge commits. A merge is bookkeeping, not an hour of work."""
        self.commit_file(self.r, "init", at(8))
        self.git(self.r, "checkout", "-q", "-b", "feature/PROJ-1-x")
        self.commit_file(self.r, "PROJ-1 work", at(9), name="g.txt")
        self.git(self.r, "checkout", "-q", "main")
        self.commit_file(self.r, "trunk moves on", at(9, 30))
        self.git(self.r, "merge", "-q", "--no-ff", "-m", "Merge PROJ-1", "feature/PROJ-1-x", when=at(10))
        self.collect()
        subjects = {r[0] for r in self.m.conn.execute("SELECT subject FROM commits")}
        self.assertNotIn("Merge PROJ-1", subjects)
        self.assertIn("PROJ-1 work", subjects)

    def test_a_re_collect_changes_nothing(self):
        self.commit_file(self.r, "PROJ-1 a", at(9))
        first = self.collect()
        second = self.collect()
        self.assertEqual((first.commits_new, second.commits_new), (1, 0))
        self.assertEqual(self.m.conn.execute("SELECT count(*) FROM commits").fetchone()[0], 1)

    def test_patch_ids_are_recorded_and_line_counts_kept(self):
        self.commit_file(self.r, "PROJ-1 a", at(9))
        self.collect()
        row = self.m.conn.execute("SELECT patch_id, files_changed, additions FROM commits").fetchone()
        self.assertTrue(row[0])
        self.assertEqual((row[1], row[2]), (1, 1))

    def test_a_cherry_pick_shares_its_patch_id(self):
        self.commit_file(self.r, "init", at(8))
        self.git(self.r, "checkout", "-q", "-b", "feature/PROJ-1-x")
        self.commit_file(self.r, "PROJ-1 change", at(9), name="g.txt")
        self.git(self.r, "checkout", "-q", "main")
        self.git(self.r, "cherry-pick", "feature/PROJ-1-x", when=at(10))
        self.collect()
        ids = [r[0] for r in self.m.conn.execute("SELECT patch_id FROM commits WHERE subject = 'PROJ-1 change'")]
        self.assertEqual((len(ids), len(set(ids))), (2, 1))

    def test_no_identity_is_refused(self):
        fresh = self.home / "other.db"
        from baldur.muninn_link import load
        handle = load().open("baldur", fresh)
        self.addCleanup(handle.close)
        with self.assertRaises(SetupError):
            collector.collect(handle, self.settings)

    def test_a_repo_switched_off_is_not_rescanned(self):
        self.commit_file(self.r, "PROJ-1 a", at(9))
        self.collect()
        repo_id = self.m.conn.execute("SELECT id FROM repos").fetchone()[0]
        self.m.baldur.set_repo_active(repo_id, False)
        self.commit_file(self.r, "PROJ-1 b", at(10))
        self.collect()
        self.assertEqual(self.m.conn.execute("SELECT count(*) FROM commits").fetchone()[0], 1)


class Estimation(Base):

    def make_day(self):
        self.commit_file(self.r, "init", at(7))
        self.git(self.r, "checkout", "-q", "-b", "feature/PROJ-42-retry")
        for minute in (0, 20, 40):
            self.commit_file(self.r, "work", at(9, minute))
        self.git(self.r, "checkout", "-q", "main")
        self.git(self.r, "checkout", "-q", "-b", "chore/tidy")
        self.commit_file(self.r, "tidy", at(15))
        self.collect()

    def compute(self, write=True):
        return service.compute(self.m, self.settings, 2, write=write, now=NOW, tz=UTC)

    def test_writes_a_run_sessions_and_proposals_with_basis(self):
        self.make_day()
        snap = self.compute()
        self.assertIsNotNone(snap.run_id)
        rows = self.m.conn.execute("SELECT work_item_key, minutes_raw, minutes_proposed, basis, basis_hash "
                                   "FROM day_proposals ORDER BY work_item_key").fetchall()
        keyed = [r for r in rows if r[0]]
        self.assertEqual([r[0] for r in keyed], ["PROJ-42"])
        self.assertLessEqual(keyed[0][2], keyed[0][1])
        self.assertIn("Basis: ", keyed[0][3])
        self.assertTrue(any(r[0] is None for r in rows), "the untracked commit is reported")
        self.assertGreater(self.m.conn.execute("SELECT count(*) FROM work_sessions").fetchone()[0], 0)
        self.assertGreater(self.m.conn.execute("SELECT count(*) FROM session_commits").fetchone()[0], 0)

    def test_a_rerun_with_no_new_commits_proposes_nothing(self):
        self.make_day()
        first = self.compute()
        second = self.compute()
        self.assertTrue(first.proposed)
        self.assertEqual(second.proposed, [])
        self.assertEqual(len(second.unchanged), len(first.proposed))

    def test_a_new_commit_proposes_again_and_supersedes_the_open_row(self):
        self.make_day()
        self.compute()
        self.git(self.r, "checkout", "-q", "feature/PROJ-42-retry")
        self.commit_file(self.r, "more", at(10, 10))
        self.collect()
        second = self.compute()
        statuses = [r[0] for r in self.m.conn.execute(
            "SELECT status FROM day_proposals WHERE work_item_key = 'PROJ-42' ORDER BY id")]
        self.assertEqual(statuses, ["superseded", "proposed"])
        self.assertTrue(second.proposed)

    def test_a_rejected_estimate_is_not_proposed_again(self):
        self.make_day()
        self.compute()
        pid = self.m.conn.execute("SELECT id FROM day_proposals WHERE work_item_key = 'PROJ-42'").fetchone()[0]
        self.m.baldur.decide_day_proposal(pid, False, confirmed_by="Brandon")
        again = self.compute()
        self.assertIn(("2026-10-01", "PROJ-42"), again.unchanged, "same evidence: not asked again")
        open_rows = [r[0] for r in self.m.conn.execute(
            "SELECT work_item_key FROM day_proposals WHERE status = 'proposed'")]
        self.assertNotIn("PROJ-42", open_rows)

    def test_dry_run_writes_nothing(self):
        self.make_day()
        snap = self.compute(write=False)
        self.assertTrue(snap.days)
        self.assertEqual(self.m.conn.execute("SELECT count(*) FROM estimate_runs").fetchone()[0], 0)

    def test_without_calendar_data_every_day_is_independent_and_it_says_so(self):
        self.make_day()
        snap = self.compute(write=False)
        self.assertEqual({d.policy for d in snap.days}, {"independent"})
        self.assertTrue(any("No calendar data" in w for w in snap.warnings))

    def test_calendar_events_from_odin_switch_the_day_to_ambient(self):
        self.make_day()
        # The v2 spec has Odin sync calendar_events, but in this repo's schema Baldur owns the table
        # (ownership.py), so the test writes it the way the current writer allows.
        with self.m.run(source="odin-calendar", stream="meetings", kind="manual") as run:
            run.baldur.upsert_calendar_event(dict(external_id="m1", title="Standup",
                                                  starts_at=at(9).isoformat(), ends_at=at(10).isoformat()))
        snap = self.compute(write=False)
        day = [d for d in snap.days if d.day == at(9).date()][0]
        self.assertEqual((day.policy, day.meeting_minutes), ("ambient", 60))


class Cli(Base):

    def test_doctor_report_estimate_and_their_exit_codes(self):
        self.commit_file(self.r, "PROJ-1 a", datetime.now(UTC) - timedelta(hours=2))
        self.m.close()
        self.assertEqual(main(["collect"]), 0)
        self.assertEqual(main(["report", "--days", "1"]), 1)        # 1: no calendar data warning
        self.assertEqual(main(["estimate", "--days", "1"]), 1)
        self.assertEqual(main(["doctor"]), 0)

    def test_setup_problems_exit_2(self):
        settings.settings_path().write_text(json.dumps({"repo_roots": [str(self.work)]}), encoding="utf-8")
        self.m.close()
        self.assertEqual(main(["collect"]), 2)                      # empty project_keys

    def test_git_identity_is_offered_from_git_config(self):
        self.assertIsInstance(gitscan.git_identity(), list)


if __name__ == "__main__":
    unittest.main()
