"""The estimation pipeline, against the spec's worked example and its bias rules.

Most tests check the DIRECTION of bias rather than pinning a minute count: proving a cap or a
rounding never raises a number survives a tuning change, and fails the moment someone adds a
heuristic that can inflate a total.
"""
import random
import unittest
from datetime import timedelta, timezone

from helpers import NOW, at, commit, worked_example

from baldur import estimate as est
from baldur.estimate import Checkout, CommitIn, Meeting, Params

UTC = timezone.utc


def run(commits, policy="ambient", meetings=(), **kw):
    params = kw.pop("params", Params(policy=policy))
    return est.estimate(commits, params, meetings=meetings, tz=UTC, now=NOW, **kw)


def minutes(day):
    return {k: t.minutes for k, t in day.tickets.items()}


class WorkedExample(unittest.TestCase):
    """The spec's table, verbatim. The old subtractive model gave 45 minutes for this day."""

    def setUp(self):
        self.commits, self.meetings = worked_example()

    def test_the_two_sessions(self):
        day = run(self.commits, meetings=self.meetings).days[0]
        spans = [(s.start.strftime("%H:%M"), s.end.strftime("%H:%M"), len(s.commits)) for s in day.sessions]
        self.assertEqual(spans, [("09:20", "12:25", 6), ("14:00", "15:05", 2)])
        self.assertEqual(round(sum(p.in_meetings for p in day.parts if p.session.id == "s1")), 160)

    def test_ambient_gives_2h00(self):
        day = run(self.commits, "ambient", self.meetings).days[0]
        self.assertEqual(minutes(day), {"PROJ-42": 90, "PROJ-51": 30})
        self.assertAlmostEqual(day.tickets["PROJ-42"].raw_minutes, 102.5)
        self.assertAlmostEqual(day.tickets["PROJ-51"].raw_minutes, 35.0)
        self.assertEqual((day.policy, day.cap), ("ambient", 480))

    def test_overlap_gives_4h00(self):
        day = run(self.commits, "overlap", self.meetings).days[0]
        self.assertEqual(minutes(day), {"PROJ-42": 180, "PROJ-51": 60})
        self.assertEqual(day.cap, 270)

    def test_independent_gives_4h00_and_flags_the_long_day(self):
        day = run(self.commits, "independent", self.meetings).days[0]
        self.assertEqual(minutes(day), {"PROJ-42": 180, "PROJ-51": 60})
        self.assertTrue(any("exceed your 8h00m tour" in f for f in day.flags), day.flags)

    def test_the_removed_model_really_gave_45_minutes_and_the_new_one_never_does(self):
        old = est.subtractive_tickets(self.commits, Params(), 420, UTC)
        self.assertEqual(old, {"PROJ-42": 45, "PROJ-51": 0})
        for policy in est.POLICIES:
            with self.subTest(policy=policy):
                self.assertNotEqual(run(self.commits, policy, self.meetings).days[0].dev_minutes, 45)


class PolicySelection(unittest.TestCase):

    def test_exactly_one_policy_per_day_with_fallbacks(self):
        self.assertEqual(est.choose_policy("ambient", True, False), "ambient")
        self.assertEqual(est.choose_policy("ambient", False, True), "overlap")    # totals, no times
        self.assertEqual(est.choose_policy("ambient", False, False), "independent")
        self.assertEqual(est.choose_policy("overlap", True, False), "overlap")
        self.assertEqual(est.choose_policy("overlap", False, False), "independent")
        self.assertEqual(est.choose_policy("independent", True, True), "independent")

    def test_a_day_with_no_calendar_data_is_independent_and_flagged(self):
        day = run([commit(10, 0, "PROJ-1")]).days[0]
        self.assertEqual(day.policy, "independent")
        self.assertTrue(any("No calendar data" in f for f in day.flags))

    def test_a_known_day_with_no_meetings_is_ambient_not_independent(self):
        """"No meetings" and "no calendar data" are different facts."""
        day = run([commit(10, 0, "PROJ-1")], calendar_days={at(10).date()}).days[0]
        self.assertEqual((day.policy, day.meeting_minutes), ("ambient", 0))

    def test_meeting_totals_without_times_use_overlap(self):
        day = run([commit(10, 0, "PROJ-1")], meeting_totals={at(10).date(): 300}).days[0]
        self.assertEqual((day.policy, day.meeting_minutes, day.cap), ("overlap", 300, 330))

    def test_NO_DOUBLE_DISCOUNT_ambient_discounts_meetings_once_and_its_cap_ignores_them(self):
        """The bug the v2 spec fixes: overlap fraction AND ambient weighting compounded."""
        commits, meetings = worked_example()
        day = run(commits, "ambient", meetings).days[0]
        self.assertEqual(day.cap, Params().max_daily_dev_minutes, "ambient's cap must not discount meetings again")
        full = sum(p.minutes for p in day.parts)
        inside = sum(p.in_meetings for p in day.parts)
        single = full - inside * (1 - Params().ambient_weight)
        self.assertAlmostEqual(sum(p.final for p in day.parts), single)


class Sessions(unittest.TestCase):

    def test_one_timeline_across_repos(self):
        """Two repos worked in parallel are one stretch of time, not two."""
        commits = [commit(9, 0, "PROJ-1", repo="a"), commit(9, 20, "PROJ-2", repo="b"),
                   commit(9, 40, "PROJ-1", repo="a"), commit(10, 0, "PROJ-2", repo="b")]
        day = run(commits).days[0]
        self.assertEqual(len(day.sessions), 1)
        self.assertAlmostEqual(sum(p.minutes for p in day.parts), 90)       # 08:30-10:00, once
        self.assertEqual(est.build_sessions(commits, (), Params())[0].commits, sorted(commits, key=lambda c: c.authored_at))

    def test_a_reflog_checkout_replaces_the_lead_in(self):
        checkout = Checkout("asgard", at(9, 5))
        day = run([commit(9, 50, "PROJ-1"), commit(10, 30, "PROJ-1")], checkouts=[checkout]).days[0]
        self.assertEqual(day.sessions[0].start, at(9, 5))
        self.assertEqual(day.sessions[0].start_from, "reflog")

    def test_reflog_alone_never_creates_a_session(self):
        self.assertEqual(run([], checkouts=[Checkout("asgard", at(9))]).days, [])

    def test_a_checkout_after_the_first_commit_is_not_start_evidence(self):
        day = run([commit(9, 0, "PROJ-1"), commit(9, 40, "PROJ-1")], checkouts=[Checkout("asgard", at(9, 20))]).days[0]
        self.assertEqual(day.sessions[0].start_from, "lead-in")

    def test_spans_are_clamped(self):
        lone = run([commit(9, 0, "PROJ-1")], params=Params(lead_in_minutes=0)).days[0]
        self.assertAlmostEqual(lone.parts[0].minutes, 15)                    # floor
        long_ = est.build_sessions([commit(h, 0, "PROJ-1") for h in range(8, 17)], (), Params())[0]
        self.assertEqual((long_.end - long_.start), timedelta(minutes=240))  # ceiling
        self.assertEqual(long_.clamped, "max")

    def test_a_lead_in_cannot_reach_back_into_the_previous_session(self):
        sessions = est.build_sessions([commit(9, 0, "PROJ-1"), commit(11, 30, "PROJ-1")], (),
                                      Params(idle_gap_minutes=60, lead_in_minutes=180))
        self.assertGreaterEqual(sessions[1].start, sessions[0].end)

    def test_a_session_across_midnight_is_split_into_its_days(self):
        commits = [commit(23, 10, "PROJ-1", day=1), commit(0, 40, "PROJ-1", day=2)]
        result = run(commits)
        self.assertEqual([d.day.day for d in result.days], [1, 2])
        self.assertAlmostEqual(result.days[0].parts[0].minutes, 80)          # 22:40 (lead-in) to 00:00
        self.assertAlmostEqual(result.days[1].parts[0].minutes, 40)          # 00:00-00:40

    def test_midnight_is_local_time(self):
        est_tz = timezone(timedelta(hours=-4))
        commits = [commit(3, 30, "PROJ-1", day=2), commit(4, 30, "PROJ-1", day=2)]  # 23:30 and 00:30 local
        days = est.estimate(commits, Params(lead_in_minutes=0), tz=est_tz, now=NOW).days
        self.assertEqual([d.day.isoformat() for d in days], ["2026-10-01", "2026-10-02"])


class Attribution(unittest.TestCase):

    def test_by_commit_count_not_lines(self):
        day = run([commit(9, 0, "PROJ-1"), commit(9, 30, "PROJ-1"), commit(10, 0, "PROJ-2")],
                  params=Params(lead_in_minutes=30, round_to_minutes=1)).days[0]
        self.assertAlmostEqual(day.tickets["PROJ-1"].raw_minutes, 60)
        self.assertAlmostEqual(day.tickets["PROJ-2"].raw_minutes, 30)

    def test_a_commit_naming_two_tickets_splits_evenly(self):
        day = run([commit(9, 0, "PROJ-1", "PROJ-2")], params=Params(lead_in_minutes=30, round_to_minutes=1)).days[0]
        self.assertAlmostEqual(day.tickets["PROJ-1"].raw_minutes, 15)
        self.assertAlmostEqual(day.tickets["PROJ-2"].raw_minutes, 15)

    def test_a_two_key_commit_counts_half_to_each_alongside_other_commits(self):
        """With only one commit, normalisation hides a wrong split (mutation testing showed it).
        One commit on (PROJ-1, PROJ-2) plus one on PROJ-1: weights 1.5 and 0.5, so 75% and 25%."""
        day = run([commit(9, 0, "PROJ-1", "PROJ-2"), commit(9, 30, "PROJ-1")],
                  params=Params(lead_in_minutes=30, round_to_minutes=1)).days[0]
        self.assertAlmostEqual(day.tickets["PROJ-1"].raw_minutes, 45)
        self.assertAlmostEqual(day.tickets["PROJ-2"].raw_minutes, 15)

    def test_untracked_minutes_are_reported_and_never_become_a_ticket(self):
        day = run([commit(9, 0), commit(9, 30)]).days[0]
        self.assertEqual(day.tickets, {})
        self.assertGreater(day.untracked_raw, 0)

    def test_a_cherry_pick_counts_once(self):
        unique, dropped = est.dedupe([commit(9, 0, "PROJ-1", patch="p"), commit(11, 0, "PROJ-1", repo="b", patch="p")])
        self.assertEqual((len(unique), dropped), (1, 1))

    def test_the_copy_with_a_key_wins_a_dedupe(self):
        keyless = CommitIn("x", "a", at(9))
        keyed = CommitIn("x", "b", at(9), ("PROJ-1",))
        for order in ([keyless, keyed], [keyed, keyless]):
            self.assertEqual(est.dedupe(order)[0][0].keys, ("PROJ-1",))

    def test_future_dated_commits_are_excluded_and_reported(self):
        result = run([commit(9, 0, "PROJ-1"), commit(9, 0, "PROJ-1", day=9)])
        self.assertEqual(len(result.excluded), 1)
        self.assertEqual([d.day.day for d in result.days], [1])


class DirectionOfBias(unittest.TestCase):
    """Randomised: every cap, scaling and rounding leaves each number equal or lower."""

    def setUp(self):
        self.rng = random.Random(20261003)

    def random_day(self):
        n = self.rng.randint(1, 25)
        commits = [CommitIn("c{}".format(i), self.rng.choice(["a", "b"]),
                            at(7) + timedelta(minutes=self.rng.randint(0, 14 * 60)),
                            tuple(self.rng.sample(["PROJ-1", "PROJ-2", "PROJ-3"], self.rng.randint(0, 2))))
                   for i in range(n)]
        meetings = [Meeting("m{}".format(i), s, s + timedelta(minutes=self.rng.randint(15, 120)))
                    for i, s in enumerate(at(8) + timedelta(minutes=self.rng.randint(0, 600)) for _ in range(self.rng.randint(0, 6)))]
        params = Params(policy=self.rng.choice(est.POLICIES), ambient_weight=self.rng.random(),
                        concurrent_fraction=self.rng.random(), round_to_minutes=self.rng.choice([1, 5, 15, 30]),
                        max_daily_dev_minutes=self.rng.choice([120, 240, 480]))
        return commits, meetings, params

    def test_every_step_only_lowers(self):
        for trial in range(300):
            commits, meetings, params = self.random_day()
            for day in est.estimate(commits, params, meetings=meetings, tz=UTC, now=NOW).days:
                with self.subTest(trial=trial, policy=day.policy):
                    for part in day.parts:
                        self.assertLessEqual(part.counted, part.minutes + 1e-9, "policy raised a part")
                        self.assertLessEqual(part.final, part.counted + 1e-9, "cap raised a part")
                    self.assertLessEqual(sum(p.final for p in day.parts), day.cap + 1e-6, "day above its cap")
                    for t in day.tickets.values():
                        self.assertLessEqual(t.minutes, t.raw_minutes + 1e-9, "rounding raised a ticket")
                        self.assertEqual(t.minutes % params.round_to_minutes, 0)
                    total = sum(t.raw_minutes for t in day.tickets.values()) + day.untracked_raw
                    self.assertAlmostEqual(total, sum(p.final for p in day.parts), places=6,
                                           msg="attribution must neither lose nor invent minutes")

    def test_more_meeting_weight_never_lowers_an_ambient_estimate(self):
        commits, meetings = worked_example()
        totals = [run(commits, meetings=meetings, params=Params(ambient_weight=w / 10)).days[0].raw_dev_minutes
                  for w in range(11)]
        self.assertEqual(totals, sorted(totals))

    def test_more_meetings_never_raise_an_overlap_cap(self):
        caps = [est.day_cap(Params(), "overlap", m) for m in range(0, 1000, 7)]
        self.assertEqual(caps, sorted(caps, reverse=True))

    def test_the_overlap_deduction_rounds_up(self):
        self.assertEqual(est.day_cap(Params(), "overlap", 451), 480 - 226)


class BasisHash(unittest.TestCase):

    def test_same_evidence_same_hash(self):
        self.assertEqual(est.basis_hash(Params(), ["b", "a"], ["m"]), est.basis_hash(Params(), ["a", "b"], ["m"]))

    def test_settings_commits_or_meetings_change_it(self):
        base = est.basis_hash(Params(), ["a"], ["m"])
        for other in (est.basis_hash(Params(idle_gap_minutes=90), ["a"], ["m"]),
                      est.basis_hash(Params(), ["a", "b"], ["m"]),
                      est.basis_hash(Params(), ["a"], ["m", "n"]),
                      est.basis_hash(Params(model_version="baldur-2"), ["a"], ["m"])):
            self.assertNotEqual(base, other)


class ParamsChecks(unittest.TestCase):

    def test_bad_settings_are_refused(self):
        for bad in (dict(idle_gap_minutes=0), dict(policy="subtractive"), dict(ambient_weight=1.5),
                    dict(min_session_minutes=300), dict(round_to_minutes=0), dict(tour_end="07:00")):
            with self.subTest(bad=bad), self.assertRaises(est.EstimateError):
                Params(**bad).check()


if __name__ == "__main__":
    unittest.main()
