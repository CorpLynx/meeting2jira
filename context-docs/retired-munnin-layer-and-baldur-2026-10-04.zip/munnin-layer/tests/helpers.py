"""Shared fixtures. Every test gets its own database file in its own temp directory.

Nothing here touches the real %LOCALAPPDATA%\\Asgard: paths are always passed explicitly, and
ASGARD_HOME is never relied on.
"""
from __future__ import annotations

import shutil
import sys
import tempfile
import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Dict

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "src"))

from asgard import muninn  # noqa: E402

UTC = timezone.utc


class FakeClock:
    """A controllable clock. Timestamps are whole seconds, so the subtle bugs (two writes in the
    same second) only show up if a test can hold time still, and the sweep only works if it can move."""

    def __init__(self, start: str = "2026-10-02T12:00:00Z"):
        self.now = datetime.strptime(start, "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=UTC)

    def __call__(self) -> datetime:
        return self.now

    def advance(self, seconds: int = 60) -> None:
        self.now += timedelta(seconds=seconds)


def issue(**overrides: Any) -> Dict[str, Any]:
    """A valid Jira issue as a sync would hand it over, in Jira's own timestamp format."""
    base = dict(
        jira_id=10001, key="ABC-123", project_key="ABC", issue_type="Task", summary="Fix retry logic",
        status="To Do", status_category="new", url="https://jira.example.gov/browse/ABC-123",
        assignee="bjones", reporter="asmith", labels=["backend"],
        created_at="2026-10-01T09:00:00.000+0000", updated_at="2026-10-02T10:00:00.000+0000")
    base.update(overrides)
    return base


def commit(sha_char: str = "a", **overrides: Any) -> Dict[str, Any]:
    base = dict(sha=sha_char * 40, author_name="Me", author_email="me@agency.gov",
                authored_at="2026-10-02T09:10:00Z", committed_at="2026-10-02T09:10:00Z",
                subject="ABC-123 fix the thing", branch_hint="feature/ABC-123-x")
    base.update(overrides)
    return base


class MuninnCase(unittest.TestCase):
    """Base class: a temp directory, a fake clock, and a helper to open the database as any app."""

    def setUp(self) -> None:
        self.tmp = Path(tempfile.mkdtemp(prefix="muninn-test-"))
        self.addCleanup(shutil.rmtree, self.tmp, True)
        self.path = self.tmp / "muninn.db"
        self.clock = FakeClock()
        self._handles = []

    def open(self, app: str = "odin", **kwargs: Any):
        kwargs.setdefault("clock", self.clock)
        handle = muninn.open(app, self.path, **kwargs)
        self._handles.append(handle)
        self.addCleanup(self._close, handle)
        return handle

    @staticmethod
    def _close(handle: Any) -> None:
        try:
            handle.close()
        except Exception:        # noqa: BLE001 - cleanup must never mask the test's own failure
            pass

    def jira_run(self, m: Any, stream: str = "issues", **kwargs: Any):
        return m.run(source="jira-dc", stream=stream, kind="jira", base_url="https://jira.example.gov", **kwargs)
