"""The eight rules, one class each, plus the three bugs found in the design.

Each test states the rule it protects. The rules are the contract, so a test here failing means a
promise the design makes to every app is no longer kept.
"""
import sqlite3
import unittest

from helpers import MuninnCase, commit, issue

from asgard import muninn
from asgard.muninn import common, redact
from asgard.muninn.errors import OwnershipError, RuleViolation


class Rule1_OneWriterModule(MuninnCase):

    def test_apps_are_known_by_name(self):
        with self.assertRaises(RuleViolation):
            muninn.open("not-an-app", self.path)

    def test_a_read_only_handle_cannot_write_anything(self):
        self.open("odin").close()
        ro = self.open("freya", read_only=True)
        with self.assertRaises(RuleViolation):
            ro.ensure_source("x", "manual")
        with self.assertRaises(RuleViolation):
            ro.emit("a.b", "sources")

    def test_a_read_only_handle_reads_everything(self):
        with self.open("odin") as m:
            m.ensure_source("jira-dc", "jira")
        ro = self.open("freya", read_only=True)
        self.assertEqual(ro.conn.execute("SELECT name FROM sources").fetchone()[0], "jira-dc")

    def test_connections_carry_the_design_pragmas(self):
        m = self.open()
        self.assertEqual(m.conn.execute("PRAGMA foreign_keys").fetchone()[0], 1)
        self.assertEqual(m.conn.execute("PRAGMA busy_timeout").fetchone()[0], 5000)
        self.assertEqual(m.conn.execute("PRAGMA journal_mode").fetchone()[0], "wal")


class Rule2_Provenance(MuninnCase):

    def test_synced_facts_record_source_run_and_first_last_seen(self):
        m = self.open()
        with self.jira_run(m) as run:
            result = run.upsert_work_item(issue())
        row = m.conn.execute("SELECT source_id, run_id, first_seen_at, last_seen_at FROM work_items "
                             "WHERE id = ?", (result.id,)).fetchone()
        self.assertEqual(row["run_id"], run.id)
        self.assertEqual(row["source_id"], run.source_id)
        self.assertEqual(row["first_seen_at"], "2026-10-02T12:00:00Z")

    def test_a_synced_fact_cannot_be_written_without_a_run(self):
        m = self.open()
        with self.assertRaises(RuleViolation) as caught:
            m.odin.upsert_work_item(issue())
        self.assertIn("sync run", str(caught.exception))

    def test_a_run_records_what_it_saw_and_changed(self):
        m = self.open()
        with self.jira_run(m) as run:
            run.upsert_work_item(issue())
            run.upsert_work_item(issue(jira_id=10002, key="ABC-124"))
        row = m.conn.execute("SELECT status, items_seen, items_changed FROM sync_runs").fetchone()
        self.assertEqual((row["status"], row["items_seen"], row["items_changed"]), ("ok", 2, 2))

    def test_repeating_a_run_changes_nothing(self):
        m = self.open()
        with self.jira_run(m) as first:
            first.upsert_work_item(issue())
        self.clock.advance(30)
        with self.jira_run(m) as second:
            second.upsert_work_item(issue())
        row = m.conn.execute("SELECT status, items_seen, items_changed FROM sync_runs ORDER BY id DESC").fetchone()
        self.assertEqual((row["items_seen"], row["items_changed"]), (1, 0))


class Rule3_IdempotentUpserts_AndTheBugsFoundInTheDesign(MuninnCase):

    def test_outcomes_are_created_updated_unchanged(self):
        m = self.open()
        with self.jira_run(m) as run:
            a = run.upsert_work_item(issue())
            b = run.upsert_work_item(issue(status="In Progress", status_category="indeterminate",
                                           updated_at="2026-10-02T11:00:00Z"))
            c = run.upsert_work_item(issue(status="In Progress", status_category="indeterminate",
                                           updated_at="2026-10-02T11:00:00Z"))
        self.assertEqual([a.outcome, b.outcome, c.outcome],
                         [common.CREATED, common.UPDATED, common.UNCHANGED])

    def test_BUG_an_update_in_the_same_second_as_the_insert_is_not_reported_as_a_create(self):
        """The design derives `inserted` from `first_seen_at = :now`. Timestamps are whole seconds, so
        an update landing in the same second as the insert is indistinguishable and is reported as a
        CREATE. Events are append-only, so the wrong event could never be corrected."""
        m = self.open()
        with self.jira_run(m) as run:
            created = run.upsert_work_item(issue())
            updated = run.upsert_work_item(issue(summary="renamed", updated_at="2026-10-02T11:00:00Z"))
        self.assertEqual(self.clock(), self.clock())          # the clock never moved: same second
        self.assertTrue(created.inserted)
        self.assertFalse(updated.inserted, "an update was reported as a create")
        self.assertEqual(updated.outcome, common.UPDATED)
        kinds = [e["kind"] for e in m.events_since("2000-01-01T00:00:00Z") if e["kind"].startswith("work_item")]
        self.assertEqual(kinds, ["work_item.created", "work_item.updated"])

    def test_BUG_a_soft_deleted_issue_that_reappears_unchanged_is_restored(self):
        """In the design's single statement the `WHERE excluded.updated_at > work_items.updated_at`
        gate blocks the same UPDATE that clears `deleted_at`, so an unchanged issue that comes back
        stays deleted for good."""
        m = self.open()
        with self.jira_run(m) as run:
            run.upsert_work_item(issue())
        m.conn.execute("UPDATE work_items SET deleted_at = '2026-10-02T12:00:30Z'")
        self.clock.advance(60)
        with self.jira_run(m) as run:
            again = run.upsert_work_item(issue())
        self.assertEqual(again.outcome, common.RESTORED)
        self.assertIsNone(m.conn.execute("SELECT deleted_at FROM work_items").fetchone()[0])
        self.assertIn("work_item.restored", [e["kind"] for e in m.events_since("2000-01-01T00:00:00Z")])

    def test_BUG_the_design_sql_really_does_misreport_this(self):
        """Pins the design's own statement so the bug stays demonstrable. If this ever stops
        failing, the design changed and the comment above is stale."""
        from asgard.muninn import db as dbmod
        conn = sqlite3.connect(":memory:", isolation_level=None)
        conn.row_factory = sqlite3.Row
        for migration in dbmod.migration_files()[:1]:
            conn.executescript(migration.path.read_text(encoding="utf-8"))
        conn.execute("INSERT INTO sources (kind, name) VALUES ('jira', 'j')")
        sql = ("INSERT INTO work_items (source_id, jira_id, key, project_key, issue_type, summary, status, "
               "status_category, is_mine, labels, url, created_at, updated_at, resolved_at, first_seen_at, "
               "last_seen_at, run_id) VALUES (1,'2','B-2','B','Task',:s,'x','todo',0,'[]','u',"
               "'2026-10-02T10:00:00Z',:u,NULL,:now,:now,NULL) ON CONFLICT (source_id, jira_id) DO UPDATE SET "
               "summary = excluded.summary, updated_at = excluded.updated_at, deleted_at = NULL "
               "WHERE excluded.updated_at > work_items.updated_at "
               "RETURNING id, first_seen_at = :now AS inserted")
        self.addCleanup(conn.close)
        now = "2026-10-02T12:00:00Z"
        first = conn.execute(sql, dict(s="v1", u="2026-10-02T10:00:00Z", now=now)).fetchone()
        second = conn.execute(sql, dict(s="v2", u="2026-10-02T11:00:00Z", now=now)).fetchone()
        self.assertEqual((first["inserted"], second["inserted"]), (1, 1), "design reports the UPDATE as inserted")

    def test_older_data_never_overwrites_newer(self):
        m = self.open()
        with self.jira_run(m) as run:
            run.upsert_work_item(issue(summary="new", updated_at="2026-10-02T11:00:00Z"))
            stale = run.upsert_work_item(issue(summary="OLD", updated_at="2026-10-02T09:00:00Z"))
        self.assertEqual(stale.outcome, common.UNCHANGED)
        self.assertEqual(m.conn.execute("SELECT summary FROM work_items").fetchone()[0], "new")

    def test_an_equal_time_edit_is_applied(self):
        """Two edits inside one second are indistinguishable by time. A sync fetches current state,
        so dropping the second would lose a real change."""
        m = self.open()
        with self.jira_run(m) as run:
            run.upsert_work_item(issue())
            same = run.upsert_work_item(issue(summary="edited in the same second"))
        self.assertEqual(same.outcome, common.UPDATED)

    def test_is_mine_never_flips_back(self):
        m = self.open()
        m.add_identity("jira_user", "bjones")
        with self.jira_run(m) as run:
            run.upsert_work_item(issue())
            run.upsert_work_item(issue(assignee="someone-else", updated_at="2026-10-02T11:00:00Z"))
        self.assertEqual(m.conn.execute("SELECT is_mine, assignee FROM work_items").fetchone()[:], (1, "someone-else"))

    def test_an_issue_that_moves_project_keeps_its_row(self):
        m = self.open()
        with self.jira_run(m) as run:
            first = run.upsert_work_item(issue())
            moved = run.upsert_work_item(issue(key="XYZ-45", project_key="XYZ", updated_at="2026-10-02T11:00:00Z"))
        self.assertEqual(first.id, moved.id)
        self.assertEqual(m.conn.execute("SELECT key FROM work_items").fetchone()[0], "XYZ-45")


class Rule4_TimesAreUtcText(MuninnCase):

    def test_jira_offsets_are_normalised_on_the_way_in(self):
        m = self.open()
        with self.jira_run(m) as run:
            run.upsert_work_item(issue(created_at="2026-10-01T09:00:00.000+0200",
                                       updated_at="2026-10-02T14:05:00.000+0000"))
        row = m.conn.execute("SELECT created_at, updated_at FROM work_items").fetchone()
        self.assertEqual((row["created_at"], row["updated_at"]), ("2026-10-01T07:00:00Z", "2026-10-02T14:05:00Z"))

    def test_a_timestamp_without_an_offset_is_refused_not_guessed(self):
        m = self.open()
        with self.jira_run(m) as run, self.assertRaises(RuleViolation):
            run.upsert_work_item(issue(updated_at="2026-10-02T14:05:00"))

    def test_the_database_itself_rejects_a_badly_shaped_timestamp(self):
        """Belt and braces: even raw SQL cannot store a space, a missing Z or fractional seconds."""
        m = self.open()
        for bad in ("2026-10-02 14:05:00Z", "2026-10-02T14:05:00", "2026-10-02T14:05:00.5Z", "2026-13-02T14:05:00Z"):
            with self.subTest(bad=bad), self.assertRaises(sqlite3.IntegrityError):
                m.conn.execute("INSERT INTO sources (kind, name, created_at) VALUES ('jira', ?, ?)", (bad, bad))


class Rule5_AppsOwnTheirTables(MuninnCase):

    def test_each_cross_app_write_is_refused_with_a_message_naming_the_owner(self):
        odin, baldur = self.open("odin"), None
        with self.assertRaises(OwnershipError) as caught:
            odin.baldur.upsert_repo("x")
        self.assertIn("baldur", str(caught.exception))
        baldur = self.open("baldur")
        with self.jira_run(baldur) as run, self.assertRaises(OwnershipError) as caught:
            run.upsert_work_item(issue())
        self.assertIn("odin", str(caught.exception))

    def test_worklogs_are_split_by_origin(self):
        """Odin records what Jira holds; Baldur drafts its own. Baldur cannot overwrite a Jira row."""
        odin = self.open("odin")
        with self.jira_run(odin) as run:
            item = run.upsert_work_item(issue())
            run.odin.upsert_jira_worklog(item.id, dict(jira_worklog_id="77", started_at="2026-10-02T10:00:00Z", seconds=1800))
        baldur = self.open("baldur")
        row_id = baldur.conn.execute("SELECT id FROM worklogs").fetchone()[0]
        with self.assertRaises(RuleViolation) as caught:
            baldur.baldur.approve_worklog(row_id, "Brandon")
        self.assertIn("came from Jira", str(caught.exception))

    def test_meta_is_writable_only_by_muninn_and_valkyrie(self):
        with self.assertRaises(OwnershipError):
            self.open("baldur").meta_set("timezone", "UTC")
        self.open("valkyrie").meta_set("timezone", "America/New_York")

    def test_retention_is_only_for_the_muninn_app(self):
        with self.assertRaises(OwnershipError):
            self.open("odin").prune()


class Rule6_EventsAreAppendOnly(MuninnCase):

    def test_events_cannot_be_updated_or_deleted_even_with_raw_sql(self):
        m = self.open()
        m.ensure_source("jira-dc", "jira")
        with self.assertRaises(sqlite3.IntegrityError):
            m.conn.execute("UPDATE events SET kind = 'x.y'")
        with self.assertRaises(sqlite3.IntegrityError):
            m.conn.execute("DELETE FROM events")

    def test_every_change_emits_exactly_one_event_and_a_repeat_emits_none(self):
        m = self.open()
        with self.jira_run(m) as run:
            run.upsert_work_item(issue())
        before = m.conn.execute("SELECT count(*) FROM events").fetchone()[0]
        self.clock.advance(30)
        with self.jira_run(m) as run:
            run.upsert_work_item(issue())
        work_item_events = [e for e in m.events_since("2000-01-01T00:00:00Z") if e["kind"].startswith("work_item.")]
        self.assertEqual(len(work_item_events), 1, "an unchanged repeat must not emit")
        self.assertEqual(m.conn.execute("SELECT count(*) FROM events").fetchone()[0], before + 1,
                         "the only new event is the run's own sync_run.finished")

    def test_an_event_is_committed_with_its_change_or_not_at_all(self):
        m = self.open()
        with self.assertRaises(RuntimeError):
            with self.jira_run(m) as run:
                run.upsert_work_item(issue())
                raise RuntimeError("boom")
        self.assertEqual(m.conn.execute("SELECT count(*) FROM work_items").fetchone()[0], 0)
        kinds = [e["kind"] for e in m.events_since("2000-01-01T00:00:00Z")]
        self.assertNotIn("work_item.created", kinds)
        self.assertIn("sync_run.failed", kinds)

    def test_event_kinds_must_be_noun_dot_verb(self):
        m = self.open()
        for bad in ("updated", "Work_Item.Updated", "work item.updated", "a.b.c", ""):
            with self.subTest(bad=bad), self.assertRaises(RuleViolation):
                m.emit(bad, "sources")

    def test_events_outlive_the_runs_that_made_them(self):
        odin = self.open("odin")
        with self.jira_run(odin) as run:
            run.upsert_work_item(issue())
        self.clock.advance(200 * 86400)
        m = self.open("muninn")              # retention belongs to the muninn app, not to Odin
        self.assertGreaterEqual(m.prune()["sync_runs"], 1)
        self.assertEqual(m.conn.execute("SELECT count(*) FROM sync_runs").fetchone()[0], 0)
        self.assertGreater(m.conn.execute("SELECT count(*) FROM events WHERE kind LIKE 'work_item.%'").fetchone()[0], 0)


class Rule8_NoSecrets(MuninnCase):

    def test_an_event_payload_with_a_credential_shaped_key_is_refused(self):
        m = self.open()
        for key in ("token", "apiKey", "api_key", "Authorization", "password", "client_secret", "cookie"):
            with self.subTest(key=key), self.assertRaises(RuleViolation):
                m.emit("thing.happened", "sources", payload={key: "x"})

    def test_an_event_payload_with_a_credential_shaped_value_is_refused(self):
        m = self.open()
        for value in ("Bearer abcdefghijklmnopqrstuvwxyz", "ghp_" + "a" * 36, "AKIA" + "A" * 16,
                      "eyJ" + "a" * 12 + "." + "b" * 12 + "." + "c" * 12, "https://me:hunter2@host/x",
                      "-----BEGIN RSA PRIVATE KEY-----"):
            with self.subTest(value=value[:12]), self.assertRaises(RuleViolation):
                m.emit("thing.happened", "sources", payload={"note": value})

    def test_the_refusal_never_echoes_the_secret(self):
        m = self.open()
        secret = "ghp_" + "Z9" * 20
        with self.assertRaises(RuleViolation) as caught:
            m.emit("thing.happened", "sources", payload={"note": secret})
        self.assertNotIn(secret, str(caught.exception))

    def test_secrets_nested_deep_in_a_payload_are_still_found(self):
        m = self.open()
        with self.assertRaises(RuleViolation):
            m.emit("thing.happened", "sources", payload={"a": [{"b": {"token": "x"}}]})

    def test_a_pasted_token_in_a_commit_subject_is_scrubbed_before_it_is_stored(self):
        m = self.open("baldur")
        m.add_identity("git_email", "me@agency.gov")
        repo = m.baldur.upsert_repo("odin", str(self.tmp / "odin"))
        token = "ghp_" + "q" * 36
        with m.run(source="local-git", stream="commits:odin", kind="git") as run:
            run.baldur.upsert_commit(repo, commit(subject="ABC-123 oops " + token))
        stored = m.conn.execute("SELECT subject FROM commits").fetchone()[0]
        self.assertNotIn(token, stored)
        self.assertIn(redact.REDACTED, stored)

    def test_only_the_subject_line_of_a_commit_is_kept(self):
        m = self.open("baldur")
        m.add_identity("git_email", "me@agency.gov")
        repo = m.baldur.upsert_repo("odin", str(self.tmp / "odin"))
        with m.run(source="local-git", stream="commits:odin", kind="git") as run:
            run.baldur.upsert_commit(repo, commit(subject="ABC-123 subject\n\nthe body with everything in it"))
        self.assertEqual(m.conn.execute("SELECT subject FROM commits").fetchone()[0], "ABC-123 subject")

    def test_oversized_payloads_are_refused(self):
        m = self.open()
        with self.assertRaises(RuleViolation):
            m.emit("thing.happened", "sources", payload={"blob": "x" * (redact.MAX_PAYLOAD_CHARS + 1)})

    def test_a_failed_runs_error_text_is_scrubbed(self):
        m = self.open()
        token = "ghp_" + "k" * 36
        with self.assertRaises(RuntimeError):
            with self.jira_run(m):
                raise RuntimeError("request failed, header was Authorization: Bearer " + "x" * 30 + " " + token)
        stored = m.conn.execute("SELECT error FROM sync_runs").fetchone()[0]
        self.assertNotIn(token, stored)
        self.assertNotIn("x" * 30, stored)


if __name__ == "__main__":
    unittest.main()
