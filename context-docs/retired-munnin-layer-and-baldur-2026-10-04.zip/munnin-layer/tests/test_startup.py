"""Opening, migrating and backing up: the parts that run every time any app starts.

Three of these tests exist because stress-testing found real failures that no single-process test
could have: several apps starting together (the normal start of a working day) broke migration and
silently broke the once-a-day backup. They are kept as regression tests with the numbers that
exposed them.
"""
import logging
import os
import sqlite3
import threading
import time
import unittest
from pathlib import Path

from helpers import FakeClock, MuninnCase

from asgard import muninn
from asgard.muninn import db as dbmod
from asgard.muninn.errors import MigrationError, MuninnError, PreflightError

ROOT = Path(__file__).resolve().parent.parent
MIGRATIONS = ROOT / "src" / "asgard" / "muninn" / "migrations"


class WarningCollector(logging.Handler):
    def __init__(self):
        super().__init__(logging.WARNING)
        self.messages = []

    def emit(self, record):
        self.messages.append(record.getMessage())


def open_together(path, clock, count=6, app="odin"):
    """Open the database from `count` threads at the same instant. Returns the failures."""
    barrier = threading.Barrier(count)
    failures = []

    def go():
        barrier.wait()
        try:
            muninn.open(app, path, clock=clock).close()
        except Exception as exc:        # noqa: BLE001 - collected and asserted on by the caller
            failures.append("{}: {}".format(type(exc).__name__, str(exc)[:80]))

    threads = [threading.Thread(target=go) for _ in range(count)]
    for t in threads:
        t.start()
    for t in threads:
        t.join(60)
    return failures


class SimultaneousStartup(MuninnCase):

    def setUp(self):
        super().setUp()
        self.collector = WarningCollector()
        logging.getLogger("asgard.muninn").addHandler(self.collector)
        self.addCleanup(logging.getLogger("asgard.muninn").removeHandler, self.collector)

    def test_REGRESSION_concurrent_first_opens_all_succeed(self):
        """Was: 75 of 90 opens failed with "table meta already exists". Odin and Baldur launching
        together on a fresh machine would have one of them crash on first run."""
        for trial in range(8):
            path = self.tmp / "trial{}".format(trial) / "m.db"
            self.assertEqual(open_together(path, self.clock), [], "trial {}".format(trial))
            conn = sqlite3.connect(str(path))
            try:
                self.assertEqual(conn.execute("PRAGMA user_version").fetchone()[0], dbmod.latest_version())
                self.assertEqual(conn.execute("SELECT count(*) FROM sqlite_master WHERE type = 'table'").fetchone()[0], 37)
            finally:
                conn.close()

    def test_REGRESSION_concurrent_opens_on_a_new_day_all_take_the_daily_backup_cleanly(self):
        """Was: 150 of 180 opens logged a failed backup ("No such file", "disk I/O error", "table
        meta already exists"), because every process wrote the same .partial file. The daily backup is
        the design's only recovery path and it was failing exactly when apps start together."""
        for trial in range(8):
            path = self.tmp / "day{}".format(trial) / "m.db"
            clock = FakeClock()
            muninn.open("odin", path, clock=clock).close()
            clock.advance(86400)
            self.assertEqual(open_together(path, clock), [])
            backups = sorted((path.parent / "backups").glob("*"))
            self.assertIn("muninn-20261003.db", [b.name for b in backups], "trial {}".format(trial))
            self.assertEqual([b for b in backups if b.name.endswith(".partial")], [])
        self.assertEqual([m for m in self.collector.messages if "backup" in m.lower()], [])

    def test_migration_runs_exactly_once_however_many_apps_start(self):
        applied = []
        handler = logging.Handler()
        handler.emit = lambda record: applied.append(record.getMessage()) if record.getMessage().startswith("Applied") else None
        logging.getLogger("asgard.muninn.db").addHandler(handler)
        logging.getLogger("asgard.muninn.db").setLevel(logging.INFO)
        self.addCleanup(logging.getLogger("asgard.muninn.db").removeHandler, handler)
        self.assertEqual(open_together(self.path, self.clock, count=8), [])
        expected = ["Applied " + m.name for m in dbmod.migration_files()]
        self.assertEqual(sorted(applied), expected, "each migration exactly once")

    def test_no_warnings_from_a_normal_simultaneous_start(self):
        self.assertEqual(open_together(self.path, self.clock), [])
        self.assertEqual(self.collector.messages, [])


class AtomicUpgrade(MuninnCase):

    def test_a_failing_migration_rolls_back_the_earlier_ones_too(self):
        """Was all-or-nothing per FILE. Now a failure in 0003 also undoes 0001 and 0002, so the
        database is never left at an in-between version that no released code expects."""
        folder = self.tmp / "migs"
        folder.mkdir()
        for name in ("0001_initial.sql", "0002_baldur.sql"):
            (folder / name).write_text((MIGRATIONS / name).read_text(encoding="utf-8"), encoding="utf-8")
        (folder / "0003_broken.sql").write_text(
            "BEGIN;\nCREATE TABLE fine (a INTEGER) STRICT;\nTHIS IS NOT SQL;\nPRAGMA user_version = 3;\nCOMMIT;\n",
            encoding="utf-8")
        conn = dbmod.connect(self.path)
        self.addCleanup(conn.close)
        with self.assertRaises(MigrationError) as caught:
            dbmod.migrate(conn, directory=folder)
        self.assertIn("whole upgrade was rolled back", str(caught.exception))
        self.assertEqual(dbmod.schema_version(conn), 0)
        self.assertEqual(conn.execute("SELECT count(*) FROM sqlite_master WHERE type = 'table'").fetchone()[0], 0)

    def test_a_trigger_with_semicolons_in_its_body_survives_statement_splitting(self):
        """Splitting a script on ';' cuts a CREATE TRIGGER in half. complete_statement does not."""
        statements = dbmod._statements(
            "CREATE TABLE a (x);\nCREATE TRIGGER t AFTER INSERT ON a BEGIN\n  UPDATE a SET x = 1;\n  "
            "DELETE FROM a WHERE x = 2;\nEND;\nINSERT INTO a VALUES (1);\n")
        self.assertEqual(len(statements), 3)
        self.assertIn("DELETE FROM a", statements[1])

    def test_begin_and_commit_in_a_file_are_skipped_not_executed(self):
        self.assertTrue(dbmod._is_transaction_control("BEGIN;"))
        self.assertTrue(dbmod._is_transaction_control("  commit ;  "))
        self.assertTrue(dbmod._is_transaction_control("-- note\nBEGIN TRANSACTION;"))
        self.assertFalse(dbmod._is_transaction_control("CREATE TABLE begin_things (a);"))

    def test_a_migration_must_be_self_transactional_and_set_its_version(self):
        for name, text, needle in (
                ("0004_a.sql", "CREATE TABLE x (a);\nPRAGMA user_version = 4;\n", "BEGIN"),
                ("0004_b.sql", "BEGIN;\nCREATE TABLE x (a);\nCOMMIT;\n", "user_version"),
                ("0004_c.sql", "BEGIN;\nPRAGMA user_version = 9;\nCOMMIT;\n", "user_version")):
            with self.subTest(name=name), self.assertRaises(MigrationError) as caught:
                dbmod._validate_migration(dbmod.Migration(4, name, Path(name)), text)
            self.assertIn(needle, str(caught.exception))

    def test_migration_files_must_be_numbered_without_gaps(self):
        folder = self.tmp / "gappy"
        folder.mkdir()
        (folder / "0001_a.sql").write_text("BEGIN; PRAGMA user_version = 1; COMMIT;", encoding="utf-8")
        (folder / "0003_c.sql").write_text("BEGIN; PRAGMA user_version = 3; COMMIT;", encoding="utf-8")
        with self.assertRaises(MigrationError) as caught:
            dbmod.migration_files(folder)
        self.assertIn("gaps", str(caught.exception))

    def test_a_badly_named_migration_is_rejected(self):
        folder = self.tmp / "named"
        folder.mkdir()
        (folder / "add_things.sql").write_text("x", encoding="utf-8")
        with self.assertRaises(MigrationError):
            dbmod.migration_files(folder)

    def test_a_database_from_a_newer_asgard_is_refused_and_untouched(self):
        self.open().close()
        conn = sqlite3.connect(str(self.path))
        conn.execute("PRAGMA user_version = 99")
        conn.close()
        with self.assertRaises(MigrationError) as caught:
            muninn.open("odin", self.path, clock=self.clock)
        self.assertIn("newer Asgard", str(caught.exception))
        check = sqlite3.connect(str(self.path))
        try:
            self.assertEqual(check.execute("PRAGMA user_version").fetchone()[0], 99)
        finally:
            check.close()

    def test_an_existing_database_is_backed_up_before_it_is_migrated(self):
        conn = dbmod.connect(self.path)
        for name in ("0001_initial.sql",):
            for statement in dbmod._statements((MIGRATIONS / name).read_text(encoding="utf-8")):
                if not dbmod._is_transaction_control(statement):
                    conn.execute(statement)
        conn.execute("INSERT INTO sources (kind, name) VALUES ('jira', 'keep-me')")
        conn.close()
        self.open().close()
        made = sorted((self.tmp / "backups").glob("muninn-*-before-v0002.db"))
        self.assertEqual(len(made), 1)
        backup = sqlite3.connect(str(made[0]))
        try:
            self.assertEqual(backup.execute("PRAGMA user_version").fetchone()[0], 1)
            self.assertEqual(backup.execute("SELECT name FROM sources").fetchone()[0], "keep-me")
        finally:
            backup.close()

    def test_a_brand_new_database_is_not_backed_up(self):
        self.open().close()
        self.assertEqual(list((self.tmp / "backups").glob("*before*")) if (self.tmp / "backups").exists() else [], [])


class Backups(MuninnCase):

    def test_one_backup_per_day_not_one_per_open(self):
        self.open().close()
        for _ in range(3):
            self.open().close()
        daily = [p for p in (self.tmp / "backups").glob("muninn-20*.db") if "before" not in p.name]
        self.assertLessEqual(len(daily), 1)

    def test_a_new_day_takes_a_new_backup(self):
        self.open().close()
        self.clock.advance(86400)
        self.open().close()
        names = {p.name for p in (self.tmp / "backups").glob("muninn-*.db")}
        self.assertIn("muninn-20261003.db", names)

    def test_only_the_newest_seven_daily_backups_are_kept(self):
        self.open().close()
        for _ in range(12):
            self.clock.advance(86400)
            self.open().close()
        daily = sorted(p.name for p in (self.tmp / "backups").glob("muninn-20??????.db"))
        self.assertEqual(len(daily), dbmod.KEEP_DAILY_BACKUPS)
        self.assertEqual(daily, sorted(daily), "the survivors are the newest, not arbitrary ones")
        self.assertGreater(daily[0], "muninn-20261003.db")

    def test_migration_backups_are_capped_separately(self):
        folder = self.tmp / "backups"
        folder.mkdir()
        for day in range(1, 10):
            (folder / "muninn-202610{:02d}-before-v0002.db".format(day)).write_bytes(b"x")
        dbmod.prune_backups(folder)
        self.assertEqual(len(list(folder.glob("*before*"))), dbmod.KEEP_MIGRATION_BACKUPS)

    def test_a_backup_is_a_complete_consistent_copy(self):
        m = self.open("muninn")
        m.ensure_source("jira-dc", "jira")
        copy = m.backup_now("check")
        conn = sqlite3.connect(str(copy))
        try:
            self.assertEqual(conn.execute("PRAGMA integrity_check").fetchone()[0], "ok")
            self.assertEqual(conn.execute("SELECT name FROM sources").fetchone()[0], "jira-dc")
            self.assertEqual(conn.execute("PRAGMA user_version").fetchone()[0], dbmod.latest_version())
        finally:
            conn.close()

    def test_a_backup_cannot_be_taken_inside_a_transaction(self):
        m = self.open()
        with m.transaction():
            with self.assertRaises(MuninnError):
                m.backup_now()

    def test_a_fresh_stray_partial_is_left_alone_but_a_stale_one_is_removed(self):
        """Deleting every .partial would remove another process's backup that is being written now."""
        folder = self.tmp / "backups"
        folder.mkdir()
        fresh, stale = folder / "x.db.1-2-3.partial", folder / "x.db.4-5-6.partial"
        fresh.write_bytes(b"in flight")
        stale.write_bytes(b"abandoned")
        old = time.time() - dbmod.STALE_PARTIAL_SECONDS - 60
        os.utime(str(stale), (old, old))
        dbmod.prune_backups(folder)
        self.assertTrue(fresh.exists(), "a live backup must not be deleted")
        self.assertFalse(stale.exists())

    def test_a_backup_failure_does_not_stop_the_app_opening(self):
        self.open().close()                       # a brand-new database takes no backup...
        self.clock.advance(86400)
        self.open().close()                       # ...so this second-day open is what creates the folder
        self.clock.advance(86400)
        blocker = self.tmp / "backups"
        blocker.rename(self.tmp / "backups-moved")
        blocker.write_text("a file where the folder should be", encoding="utf-8")
        collector = WarningCollector()
        logging.getLogger("asgard.muninn").addHandler(collector)
        self.addCleanup(logging.getLogger("asgard.muninn").removeHandler, collector)
        self.open().close()
        self.assertTrue(any("Daily backup skipped" in m for m in collector.messages))


class Preflight(unittest.TestCase):

    def test_this_machine_passes(self):
        result = dbmod.preflight()
        self.assertTrue(result.ok, result.lines())

    def test_a_missing_capability_is_reported_by_name_with_instructions(self):
        real = dbmod._probe
        dbmod._probe = lambda sql: "no such module: fts5" if "fts5" in sql else real(sql)
        self.addCleanup(setattr, dbmod, "_probe", real)
        result = dbmod.preflight()
        self.assertFalse(result.ok)
        self.assertTrue(any("FTS5" in item for item in result.missing))
        with self.assertRaises(PreflightError) as caught:
            dbmod.require_preflight()
        message = str(caught.exception)
        self.assertIn("FTS5", message)
        self.assertIn("sqlite3.sqlite_version", message)

    def test_an_old_sqlite_is_rejected_before_any_file_is_created(self):
        folder = Path(__import__("tempfile").mkdtemp())
        self.addCleanup(__import__("shutil").rmtree, str(folder), True)
        real = dbmod._probe
        dbmod._probe = lambda sql: "near STRICT: syntax error" if "STRICT" in sql else real(sql)
        self.addCleanup(setattr, dbmod, "_probe", real)
        target = folder / "sub" / "muninn.db"
        with self.assertRaises(PreflightError):
            muninn.open("odin", target)
        self.assertFalse(target.exists(), "preflight must fail before anything is created")
        self.assertFalse(target.parent.exists())


if __name__ == "__main__":
    unittest.main()
