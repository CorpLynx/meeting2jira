"""Rule 7: people approve anything that leaves Asgard.

Two independent layers, tested separately because either alone is not enough:

  the database   CHECK constraints and migration 0003's triggers refuse an out-of-order state even
                 from raw SQL. This is the backstop for a bug or a careless INSERT.
  the writer     refuses an app approving its own work, and offers only the still-unposted part of
                 what a person agreed.

The chain:  estimate -> proposed -> APPROVED by a person -> worklog drafted -> worklog approved ->
            posted.   Nothing in Muninn posts to Jira; "posted" records that a poster module did.
"""
import sqlite3
import unittest

from helpers import MuninnCase, issue

from asgard.muninn import db as dbmod
from asgard.muninn.baldur_estimates import _person
from asgard.muninn.errors import OwnershipError, RuleViolation


def raw_db_at(version):
    conn = sqlite3.connect(":memory:", isolation_level=None)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    for migration in dbmod.migration_files()[:version]:
        conn.executescript(migration.path.read_text(encoding="utf-8"))
    conn.execute("INSERT INTO sources (kind, name) VALUES ('jira', 'j')")
    conn.execute("INSERT INTO work_items (source_id, jira_id, key, project_key, issue_type, summary, status, "
                 "status_category, url, created_at, updated_at, first_seen_at, last_seen_at) VALUES "
                 "(1,'1','A-1','A','Task','s','To Do','todo','u','2026-10-02T10:00:00Z',"
                 "'2026-10-02T10:00:00Z','2026-10-02T10:00:00Z','2026-10-02T10:00:00Z')")
    return conn


UNAPPROVED_POSTED_WORKLOG = ("INSERT INTO worklogs (work_item_id, jira_worklog_id, origin, state, started_at, "
                             "seconds) VALUES (1, '9', 'baldur', 'posted', '2026-10-02T10:00:00Z', 600)")
UNAPPROVED_POSTED_BLUF = ("INSERT INTO blufs (subject_type, subject_ref, bottom_line, body_md, tier, "
                          "prompt_version, state, posted_at, sent_via) VALUES ('adhoc','x','b','b','manual','v',"
                          "'posted','2026-10-02T10:00:00Z','clipboard')")


class DatabaseLevel(unittest.TestCase):
    """Migration 0003. The design claimed CHECKs enforce the order; for these two tables they did not."""

    def test_the_hole_exists_without_migration_0003(self):
        """Proof the migration is doing real work: on v2 both unapproved rows go straight in."""
        conn = raw_db_at(2)
        self.addCleanup(conn.close)
        conn.execute(UNAPPROVED_POSTED_WORKLOG)
        conn.execute(UNAPPROVED_POSTED_BLUF)

    def test_migration_0003_closes_it_for_worklogs_and_blufs(self):
        conn = raw_db_at(3)
        self.addCleanup(conn.close)
        for sql in (UNAPPROVED_POSTED_WORKLOG, UNAPPROVED_POSTED_BLUF):
            with self.subTest(sql=sql[:28]), self.assertRaises(sqlite3.IntegrityError) as caught:
                conn.execute(sql)
            self.assertIn("rule 7", str(caught.exception))

    def test_an_update_cannot_skip_approval_either(self):
        conn = raw_db_at(3)
        self.addCleanup(conn.close)
        conn.execute("INSERT INTO worklogs (work_item_id, origin, state, started_at, seconds) "
                     "VALUES (1, 'baldur', 'draft', '2026-10-02T10:00:00Z', 600)")
        with self.assertRaises(sqlite3.IntegrityError):
            conn.execute("UPDATE worklogs SET state = 'posted', jira_worklog_id = '5', "
                         "posted_at = '2026-10-02T11:00:00Z'")

    def test_posting_cannot_be_backdated_before_approval(self):
        conn = raw_db_at(3)
        self.addCleanup(conn.close)
        conn.execute("INSERT INTO worklogs (work_item_id, origin, state, started_at, seconds, approved_at) "
                     "VALUES (1, 'baldur', 'approved', '2026-10-02T10:00:00Z', 600, '2026-10-02T11:00:00Z')")
        with self.assertRaises(sqlite3.IntegrityError) as caught:
            conn.execute("UPDATE worklogs SET state = 'posted', jira_worklog_id = '5', "
                         "posted_at = '2026-10-02T10:59:59Z'")
        self.assertIn("before it was approved", str(caught.exception))

    def test_a_worklog_inserted_already_posted_cannot_be_backdated_before_approval(self):
        conn = raw_db_at(3)
        self.addCleanup(conn.close)
        with self.assertRaises(sqlite3.IntegrityError) as caught:
            conn.execute("INSERT INTO worklogs (work_item_id, jira_worklog_id, origin, state, started_at, "
                         "seconds, approved_at, posted_at) VALUES (1, '9', 'baldur', 'posted', "
                         "'2026-10-02T10:00:00Z', 600, '2026-10-02T11:00:00Z', '2026-10-02T10:30:00Z')")
        self.assertIn("before it was approved", str(caught.exception))

    def test_every_bluf_path_is_covered_insert_and_update(self):
        """One test per trigger. Mutation testing showed the first version of this file exercised
        only one of the four BLUF triggers, so the other three could have been deleted unnoticed."""
        conn = raw_db_at(3)
        self.addCleanup(conn.close)
        cols = ("INSERT INTO blufs (subject_type, subject_ref, bottom_line, body_md, tier, prompt_version, "
                "state, approved_at, posted_at, sent_via) VALUES ('adhoc','x','b','b','manual','v',{})")
        draft = cols.format("'draft', NULL, NULL, NULL")
        conn.execute(draft)
        with self.subTest("update draft -> posted without approval"), \
                self.assertRaises(sqlite3.IntegrityError) as caught:
            conn.execute("UPDATE blufs SET state = 'posted', posted_at = '2026-10-02T11:00:00Z', "
                         "sent_via = 'clipboard' WHERE id = 1")
        self.assertIn("without being approved", str(caught.exception))

        with self.subTest("insert posted, backdated"), self.assertRaises(sqlite3.IntegrityError) as caught:
            conn.execute(cols.format("'posted', '2026-10-02T11:00:00Z', '2026-10-02T10:00:00Z', 'clipboard'"))
        self.assertIn("before it was approved", str(caught.exception))

        conn.execute("UPDATE blufs SET state = 'approved', approved_at = '2026-10-02T11:00:00Z' WHERE id = 1")
        with self.subTest("update approved -> posted, backdated"), \
                self.assertRaises(sqlite3.IntegrityError) as caught:
            conn.execute("UPDATE blufs SET state = 'posted', posted_at = '2026-10-02T10:00:00Z', "
                         "sent_via = 'clipboard' WHERE id = 1")
        self.assertIn("before it was approved", str(caught.exception))

        conn.execute("UPDATE blufs SET state = 'posted', posted_at = '2026-10-02T11:00:05Z', "
                     "sent_via = 'clipboard' WHERE id = 1")       # the legitimate order still works

    def test_rows_that_came_from_jira_are_exempt(self):
        """Jira already holds them; there was nothing to approve."""
        conn = raw_db_at(3)
        self.addCleanup(conn.close)
        conn.execute("INSERT INTO worklogs (work_item_id, jira_worklog_id, origin, state, started_at, seconds) "
                     "VALUES (1, '7', 'jira', 'posted', '2026-10-02T10:00:00Z', 600)")

    def test_the_legitimate_order_still_works(self):
        conn = raw_db_at(3)
        self.addCleanup(conn.close)
        conn.execute("INSERT INTO worklogs (work_item_id, origin, state, started_at, seconds) "
                     "VALUES (1, 'baldur', 'draft', '2026-10-02T10:00:00Z', 600)")
        conn.execute("UPDATE worklogs SET state = 'approved', approved_at = '2026-10-02T11:00:00Z'")
        conn.execute("UPDATE worklogs SET state = 'posted', jira_worklog_id = '5', posted_at = '2026-10-02T11:00:05Z'")

    def test_rounding_cannot_raise_a_proposal_and_untracked_time_cannot_be_approved(self):
        """The Baldur spec's three day_proposals checks, from raw SQL."""
        conn = raw_db_at(3)
        self.addCleanup(conn.close)
        conn.execute("INSERT INTO estimate_runs (date_from, date_to, model_version, params, params_hash) "
                     "VALUES ('2026-10-02','2026-10-02','baldur-1','{}','h')")
        base = ("INSERT INTO day_proposals (estimate_run_id, local_date, work_item_key, minutes_raw, "
                "minutes_proposed, basis, basis_hash, status, decided_at, minutes_final) VALUES "
                "(1,'2026-10-02',{key},{raw},{prop},'b','h',{status},{dec},{fin})")
        with self.assertRaises(sqlite3.IntegrityError):      # proposed > raw
            conn.execute(base.format(key="'A-1'", raw=60, prop=75, status="'proposed'", dec="NULL", fin="NULL"))
        with self.assertRaises(sqlite3.IntegrityError):      # approved without decided_at
            conn.execute(base.format(key="'A-1'", raw=60, prop=60, status="'approved'", dec="NULL", fin=60))
        with self.assertRaises(sqlite3.IntegrityError):      # approved untracked
            conn.execute(base.format(key="NULL", raw=60, prop=60, status="'approved'",
                                     dec="'2026-10-02T12:00:00Z'", fin=60))


class ApprovalBase(MuninnCase):
    """Odin syncs the ticket; Baldur estimates, proposes, and (with a person) approves and drafts."""

    def setUp(self):
        super().setUp()
        self.odin = self.open("odin")
        with self.jira_run(self.odin) as run:
            run.upsert_work_item(issue())                     # ABC-123 now exists in work_items
        self.baldur = self.open("baldur")
        self.run_id = self.baldur.baldur.create_estimate_run(
            "2026-10-02", "2026-10-02", "baldur-1", {"policy": "ambient", "gap": 120})

    def propose(self, raw=150, proposed=120, key="ABC-123", run_id=None, evidence=None):
        """Each estimate run sees its own evidence, so its basis_hash differs by default. Pass the
        same `evidence` twice to model a re-run that found nothing new."""
        run = run_id or self.run_id
        ids = self.baldur.baldur.propose_day(
            run, "2026-10-02",
            [{"work_item_key": key, "minutes_raw": raw, "minutes_proposed": proposed,
              "basis": "6 commits in 2 sessions (09:20-12:25, 14:00-15:05)",
              "basis_hash": evidence or "evidence-run-{}".format(run)}])
        return ids[0] if ids else None

    def status(self, proposal_id):
        return self.baldur.conn.execute("SELECT status FROM day_proposals WHERE id = ?", (proposal_id,)).fetchone()[0]


class WhoMayApprove(ApprovalBase):

    def test_an_app_or_nobody_is_not_a_person(self):
        for who in ("", "   ", None, "baldur", "ODIN", "Loki", "freya", "muninn"):
            with self.subTest(who=who), self.assertRaises(RuleViolation):
                _person(who)

    def test_a_named_person_is_accepted(self):
        self.assertEqual(_person("  Brandon  "), "Brandon")

    def test_approval_requires_confirmed_by(self):
        pid = self.propose()
        with self.assertRaises(RuleViolation):
            self.baldur.baldur.decide_day_proposal(pid, True, confirmed_by="")
        self.assertEqual(self.status(pid), "proposed")

    def test_baldur_cannot_approve_as_itself(self):
        pid = self.propose()
        with self.assertRaises(RuleViolation):
            self.baldur.baldur.decide_day_proposal(pid, True, confirmed_by="baldur")

    def test_the_approver_is_recorded_in_the_event(self):
        pid = self.propose()
        self.baldur.baldur.decide_day_proposal(pid, True, confirmed_by="Brandon")
        event = [e for e in self.baldur.events_since("2000-01-01T00:00:00Z") if e["kind"] == "day_proposal.approved"][0]
        self.assertEqual(event["payload"]["by"], "Brandon")
        self.assertEqual(event["payload"]["final"], 120)


class ProposalRules(ApprovalBase):

    def test_rounding_up_is_refused_with_a_message_that_says_why(self):
        with self.assertRaises(RuleViolation) as caught:
            self.propose(raw=100, proposed=105)
        self.assertIn("only reduce", str(caught.exception))

    def test_a_proposal_must_carry_its_basis(self):
        with self.assertRaises(RuleViolation) as caught:
            self.baldur.baldur.propose_day(self.run_id, "2026-10-02", [
                {"work_item_key": "ABC-123", "minutes_raw": 60, "minutes_proposed": 60, "basis": "  "}])
        self.assertIn("basis", str(caught.exception))

    def test_untracked_time_can_be_recorded_but_never_approved(self):
        ids = self.baldur.baldur.propose_day(self.run_id, "2026-10-02", [
            {"work_item_key": None, "minutes_raw": 30, "minutes_proposed": 30, "basis": "no Jira key"}])
        with self.assertRaises(RuleViolation) as caught:
            self.baldur.baldur.decide_day_proposal(ids[0], True, confirmed_by="Brandon")
        self.assertIn("can never be approved", str(caught.exception))

    def test_a_person_may_raise_the_figure_baldur_may_not(self):
        pid = self.propose(raw=150, proposed=120)
        self.baldur.baldur.decide_day_proposal(pid, True, confirmed_by="Brandon", minutes_final=180)
        self.assertEqual(self.baldur.conn.execute("SELECT minutes_final FROM day_proposals").fetchone()[0], 180)

    def test_only_a_proposed_row_can_be_decided(self):
        pid = self.propose()
        self.baldur.baldur.decide_day_proposal(pid, True, confirmed_by="Brandon")
        with self.assertRaises(RuleViolation) as caught:
            self.baldur.baldur.decide_day_proposal(pid, False, confirmed_by="Brandon")
        self.assertIn("already approved", str(caught.exception))

    def test_a_new_run_supersedes_a_proposed_row_but_never_an_approved_one(self):
        approved, pending = self.propose(), None
        self.baldur.baldur.decide_day_proposal(approved, True, confirmed_by="Brandon")
        second = self.baldur.baldur.create_estimate_run("2026-10-02", "2026-10-02", "baldur-1", {"gap": 90})
        pending = self.propose(run_id=second)
        third = self.baldur.baldur.create_estimate_run("2026-10-02", "2026-10-02", "baldur-1", {"gap": 60})
        self.propose(run_id=third)
        self.assertEqual(self.status(approved), "approved", "a person's decision is not Baldur's to retire")
        self.assertEqual(self.status(pending), "superseded")

    def test_proposing_twice_in_one_run_is_refused(self):
        self.propose()
        with self.assertRaises(RuleViolation):
            self.propose()

    def test_estimate_params_are_frozen_with_a_hash(self):
        row = self.baldur.conn.execute("SELECT params, params_hash FROM estimate_runs").fetchone()
        self.assertIn('"policy":"ambient"', row["params"])
        self.assertEqual(len(row["params_hash"]), 16)
        other = self.baldur.baldur.create_estimate_run("2026-10-02", "2026-10-02", "baldur-1", {"policy": "overlap"})
        hashes = [r[0] for r in self.baldur.conn.execute("SELECT params_hash FROM estimate_runs ORDER BY id")]
        self.assertNotEqual(hashes[0], hashes[1])
        del other


class DeltaLogging(ApprovalBase):
    """Baldur spec: approve 2h, re-estimate 2h30m, and only 30m is offered."""

    def approve(self, final, run_id=None, raw=None):
        pid = self.propose(raw=raw or final, proposed=final, run_id=run_id)
        self.baldur.baldur.decide_day_proposal(pid, True, confirmed_by="Brandon")
        return pid

    def post(self, worklog_id, jira_id):
        self.baldur.baldur.approve_worklog(worklog_id, "Brandon")
        self.baldur.baldur.mark_worklog_posted(worklog_id, jira_id)

    def test_the_full_chain_in_order(self):
        pid = self.approve(120)
        wl = self.baldur.baldur.draft_worklog(pid, "2026-10-02T09:00:00Z")
        self.post(wl, "501")
        row = self.baldur.conn.execute("SELECT state, seconds, origin, jira_worklog_id FROM worklogs").fetchone()
        self.assertEqual(tuple(row), ("posted", 7200, "baldur", "501"))
        kinds = [e["kind"] for e in self.baldur.events_since("2000-01-01T00:00:00Z") if e["kind"].startswith("worklog.")]
        self.assertEqual(kinds, ["worklog.drafted", "worklog.approved", "worklog.posted"])

    def test_a_worklog_needs_an_approved_proposal(self):
        pid = self.propose()
        with self.assertRaises(RuleViolation) as caught:
            self.baldur.baldur.draft_worklog(pid, "2026-10-02T09:00:00Z")
        self.assertIn("approved", str(caught.exception))

    def test_states_cannot_be_skipped(self):
        wl = self.baldur.baldur.draft_worklog(self.approve(60), "2026-10-02T09:00:00Z")
        with self.assertRaises(RuleViolation) as caught:          # draft -> posted directly
            self.baldur.baldur.mark_worklog_posted(wl, "501")
        self.assertIn("draft -> approved -> posted", str(caught.exception))

    def test_only_the_still_unposted_part_is_offered(self):
        first = self.approve(120)
        self.post(self.baldur.baldur.draft_worklog(first, "2026-10-02T09:00:00Z"), "501")
        second_run = self.baldur.baldur.create_estimate_run("2026-10-02", "2026-10-02", "baldur-1", {"gap": 90})
        again = self.approve(150, run_id=second_run)
        wl = self.baldur.baldur.draft_worklog(again, "2026-10-02T09:00:00Z")
        seconds = self.baldur.conn.execute("SELECT seconds FROM worklogs WHERE id = ?", (wl,)).fetchone()[0]
        self.assertEqual(seconds, 30 * 60, "approved 150, posted 120: offer the 30")

    def test_rerunning_with_nothing_new_offers_nothing(self):
        pid = self.approve(120)
        self.post(self.baldur.baldur.draft_worklog(pid, "2026-10-02T09:00:00Z"), "501")
        self.assertIsNone(self.baldur.baldur.draft_worklog(pid, "2026-10-02T09:00:00Z"))

    def test_a_pending_draft_is_not_offered_twice(self):
        pid = self.approve(120)
        self.baldur.baldur.draft_worklog(pid, "2026-10-02T09:00:00Z")
        self.assertIsNone(self.baldur.baldur.draft_worklog(pid, "2026-10-02T09:00:00Z"),
                          "a second draft would double-log once both were approved")

    def test_a_lower_reestimate_reports_the_gap_and_retracts_nothing(self):
        first = self.approve(120)
        self.post(self.baldur.baldur.draft_worklog(first, "2026-10-02T09:00:00Z"), "501")
        second_run = self.baldur.baldur.create_estimate_run("2026-10-02", "2026-10-02", "baldur-1", {"gap": 90})
        self.approve(90, run_id=second_run, raw=90)
        self.assertIsNone(self.baldur.baldur.draft_worklog(
            self.baldur.conn.execute("SELECT id FROM day_proposals WHERE minutes_final = 90").fetchone()[0],
            "2026-10-02T09:00:00Z"))
        delta = self.baldur.baldur.day_delta("2026-10-02", "ABC-123")
        self.assertEqual((delta["posted"], delta["approved"], delta["offer"], delta["gap"]), (120, 90, 0, 30))
        state = self.baldur.conn.execute("SELECT state FROM worklogs").fetchone()[0]
        self.assertEqual(state, "posted", "posted time is never retracted automatically")

    def test_posting_needs_the_ticket_in_muninn_and_says_what_to_do(self):
        pid = self.baldur.baldur.propose_day(
            self.run_id, "2026-10-02", [{"work_item_key": "ZZZ-999", "minutes_raw": 60,
                                         "minutes_proposed": 60, "basis": "x"}])[0]
        self.baldur.baldur.decide_day_proposal(pid, True, confirmed_by="Brandon")
        with self.assertRaises(RuleViolation) as caught:
            self.baldur.baldur.draft_worklog(pid, "2026-10-02T09:00:00Z")
        self.assertIn("Odin", str(caught.exception))
        self.assertIn("report-only", str(caught.exception))

    def test_a_worklog_cannot_be_approved_by_an_app(self):
        wl = self.baldur.baldur.draft_worklog(self.approve(60), "2026-10-02T09:00:00Z")
        with self.assertRaises(RuleViolation):
            self.baldur.baldur.approve_worklog(wl, "baldur")

    def test_only_baldur_posts_baldurs_worklogs(self):
        wl = self.baldur.baldur.draft_worklog(self.approve(60), "2026-10-02T09:00:00Z")
        with self.assertRaises(OwnershipError):
            self.open("loki").baldur.approve_worklog(wl, "Brandon")

    def test_a_posted_jira_id_is_required(self):
        wl = self.baldur.baldur.draft_worklog(self.approve(60), "2026-10-02T09:00:00Z")
        self.baldur.baldur.approve_worklog(wl, "Brandon")
        with self.assertRaises(RuleViolation):
            self.baldur.baldur.mark_worklog_posted(wl, "  ")

    def test_v_day_status_agrees_with_day_delta(self):
        pid = self.approve(120)
        self.post(self.baldur.baldur.draft_worklog(pid, "2026-10-02T09:00:00Z"), "501")
        row = self.baldur.baldur.day_status("2026-10-02")[0]
        self.assertEqual((row["approved_minutes"], row["posted_minutes"]), (120, 120))


if __name__ == "__main__":
    unittest.main()


class BaldurV2Rules(ApprovalBase):
    """Migration 0004 and the v2 spec's proposal rules."""

    def test_the_same_evidence_is_not_proposed_twice(self):
        first = self.propose(evidence="same")
        second_run = self.baldur.baldur.create_estimate_run("2026-10-02", "2026-10-02", "baldur-1", {"g": 1})
        self.assertIsNone(self.propose(run_id=second_run, evidence="same"))
        self.assertEqual(self.status(first), "proposed")

    def test_a_rejected_proposal_is_not_asked_again(self):
        pid = self.propose(evidence="rejected-evidence")
        self.baldur.baldur.decide_day_proposal(pid, False, confirmed_by="Brandon")
        again = self.baldur.baldur.create_estimate_run("2026-10-02", "2026-10-02", "baldur-1", {"g": 2})
        self.assertIsNone(self.propose(run_id=again, evidence="rejected-evidence"))
        self.assertIsNotNone(self.propose(run_id=again, evidence="new-commits-arrived"))

    def test_changing_an_approval_supersedes_it_and_keeps_history(self):
        pid = self.propose()
        self.baldur.baldur.decide_day_proposal(pid, True, confirmed_by="Brandon")
        new = self.baldur.baldur.change_approval(pid, "Brandon", 150)
        rows = self.baldur.conn.execute("SELECT id, status, minutes_final FROM day_proposals ORDER BY id").fetchall()
        self.assertEqual([tuple(r) for r in rows], [(pid, "superseded", 120), (new, "approved", 150)])
        self.assertEqual(self.baldur.baldur.day_delta("2026-10-02", "ABC-123")["approved"], 150)

    def test_a_decided_proposal_cannot_be_edited_even_with_raw_sql(self):
        pid = self.propose()
        self.baldur.baldur.decide_day_proposal(pid, True, confirmed_by="Brandon")
        for sql in ("UPDATE day_proposals SET minutes_final = 999",
                    "UPDATE day_proposals SET status = 'rejected'",
                    "UPDATE day_proposals SET basis = 'rewritten'"):
            with self.subTest(sql=sql), self.assertRaises(sqlite3.IntegrityError) as caught:
                self.baldur.conn.execute(sql)
            self.assertIn("cannot be edited", str(caught.exception))

    def test_a_superseded_row_cannot_be_revived(self):
        pid = self.propose()
        self.baldur.baldur.decide_day_proposal(pid, True, confirmed_by="Brandon")
        self.baldur.baldur.change_approval(pid, "Brandon", 150)
        with self.assertRaises(sqlite3.IntegrityError):
            self.baldur.conn.execute("UPDATE day_proposals SET status = 'approved' WHERE id = ?", (pid,))

    def test_an_approval_cannot_be_changed_by_an_app(self):
        pid = self.propose()
        self.baldur.baldur.decide_day_proposal(pid, True, confirmed_by="Brandon")
        with self.assertRaises(RuleViolation):
            self.baldur.baldur.change_approval(pid, "baldur", 150)

    def test_keys_from_reflog_and_pull_requests_can_be_stored(self):
        m = self.open("baldur")
        m.add_identity("git_email", "me@agency.gov")
        repo = m.baldur.upsert_repo("r", str(self.tmp / "r"))
        with m.run(source="local-git", stream="commits:r", kind="git") as run:
            cid = run.baldur.upsert_commit(repo, dict(sha="c" * 40, author_name="Me", author_email="me@agency.gov",
                                                      authored_at="2026-10-02T09:00:00Z",
                                                      committed_at="2026-10-02T09:00:00Z", subject="s")).id
        self.assertTrue(m.baldur.link_commit(cid, "ABC-123", "reflog", 1.0))
        self.assertTrue(m.baldur.link_commit(cid, "ABC-124", "pull_request", 0.9))
