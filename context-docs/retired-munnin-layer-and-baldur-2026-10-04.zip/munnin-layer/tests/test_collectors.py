"""Baldur's collectors, Odin's transitions and Jira worklogs, search, and maintenance."""
import unittest

from helpers import MuninnCase, commit, issue

from asgard.muninn import common
from asgard.muninn.db import latest_version as dbmod_latest
from asgard.muninn.errors import OwnershipError, RuleViolation


class BaldurCase(MuninnCase):

    def setUp(self):
        super().setUp()
        self.m = self.open("baldur")
        self.m.add_identity("git_email", "Me@Agency.gov")
        self.repo = self.m.baldur.upsert_repo("odin", str(self.tmp / "Odin"))

    def git_run(self):
        return self.m.run(source="local-git", stream="commits:odin", kind="git")


class Repos(BaldurCase):

    def test_the_same_folder_typed_two_ways_is_one_repo(self):
        again = self.m.baldur.upsert_repo("odin", str(self.tmp / "sub" / ".." / "Odin"))
        self.assertEqual(again, self.repo)

    def test_deactivating_keeps_history(self):
        self.m.baldur.set_repo_active(self.repo, False)
        self.assertEqual(self.m.conn.execute("SELECT active, name FROM repos").fetchone()[:], (0, "odin"))


class Commits(BaldurCase):

    def test_is_mine_matches_email_case_insensitively(self):
        with self.git_run() as run:
            run.baldur.upsert_commit(self.repo, commit(author_email="ME@agency.GOV"))
        self.assertEqual(self.m.conn.execute("SELECT is_mine FROM commits").fetchone()[0], 1)

    def test_a_matching_display_name_does_not_make_a_commit_mine(self):
        """Names collide; a false positive credits someone else's work to your timesheet."""
        self.m.add_identity("git_name", "Me")
        with self.git_run() as run:
            run.baldur.upsert_commit(self.repo, commit(author_name="Me", author_email="other@agency.gov"))
        self.assertEqual(self.m.conn.execute("SELECT is_mine FROM commits").fetchone()[0], 0)

    def test_author_time_is_normalised_to_utc(self):
        with self.git_run() as run:
            run.baldur.upsert_commit(self.repo, commit(authored_at="2026-10-02T09:10:00+02:00"))
        self.assertEqual(self.m.conn.execute("SELECT authored_at FROM commits").fetchone()[0], "2026-10-02T07:10:00Z")

    def test_a_repeat_is_unchanged_and_fills_in_only_what_was_missing(self):
        with self.git_run() as run:
            first = run.baldur.upsert_commit(self.repo, commit(branch_hint=None))
            again = run.baldur.upsert_commit(self.repo, commit(branch_hint="feature/ABC-123"))
            third = run.baldur.upsert_commit(self.repo, commit(branch_hint="something-else"))
        self.assertEqual([first.outcome, again.outcome, third.outcome],
                         [common.CREATED, common.UPDATED, common.UNCHANGED])
        self.assertEqual(self.m.conn.execute("SELECT branch_hint FROM commits").fetchone()[0], "feature/ABC-123")

    def test_a_malformed_sha_is_refused(self):
        with self.git_run() as run:
            for bad in ("abc", "z" * 40, "a" * 41):
                with self.subTest(bad=bad), self.assertRaises(RuleViolation):
                    run.baldur.upsert_commit(self.repo, commit(sha=bad))

    def test_an_identity_added_later_is_applied_by_recompute(self):
        with self.git_run() as run:
            run.baldur.upsert_commit(self.repo, commit(author_email="second@agency.gov"))
        self.m.add_identity("git_email", "second@agency.gov")
        self.assertEqual(self.m.baldur.recompute_ownership(), 1)
        self.assertEqual(self.m.conn.execute("SELECT is_mine FROM commits").fetchone()[0], 1)

    def test_commits_need_a_run(self):
        with self.assertRaises(RuleViolation):
            self.m.baldur.upsert_commit(self.repo, commit())

    def test_my_commits_query_uses_the_partial_index(self):
        """SQLite only uses a partial index when the query repeats its filter literally."""
        plan = " ".join(r[3] for r in self.m.conn.execute(
            "EXPLAIN QUERY PLAN SELECT id FROM commits c WHERE c.is_mine = 1 AND c.authored_at >= ? "
            "AND c.authored_at < ?", ("2026-10-01T00:00:00Z", "2026-10-03T00:00:00Z")))
        self.assertIn("ix_commits_mine_authored", plan)


class Links(BaldurCase):

    def setUp(self):
        super().setUp()
        with self.git_run() as run:
            self.commit_id = run.baldur.upsert_commit(self.repo, commit()).id

    def test_a_stronger_link_replaces_a_weaker_and_never_the_reverse(self):
        self.assertTrue(self.m.baldur.link_commit(self.commit_id, "ABC-123", "fuzzy", 0.4))
        self.assertTrue(self.m.baldur.link_commit(self.commit_id, "ABC-123", "branch", 0.9))
        self.assertFalse(self.m.baldur.link_commit(self.commit_id, "ABC-123", "fuzzy", 0.5))
        row = self.m.conn.execute("SELECT method, confidence FROM commit_work_items").fetchone()
        self.assertEqual(tuple(row), ("branch", 0.9))

    def test_a_link_to_an_unsynced_ticket_is_kept_and_resolved_later(self):
        self.m.baldur.link_commit(self.commit_id, "ABC-123", "branch", 0.9)
        self.assertIsNone(self.m.conn.execute("SELECT work_item_id FROM commit_work_items").fetchone()[0])
        odin = self.open("odin")
        with self.jira_run(odin) as run:
            run.upsert_work_item(issue())
        self.assertEqual(self.m.baldur.resolve_links(), 1)
        self.assertIsNotNone(self.m.conn.execute("SELECT work_item_id FROM commit_work_items").fetchone()[0])

    def test_bad_keys_methods_and_confidences_are_refused(self):
        for args in (("abc-1", "branch", 0.5), ("ABC-123", "guess", 0.5), ("ABC-123", "branch", 1.5)):
            with self.subTest(args=args), self.assertRaises(RuleViolation):
                self.m.baldur.link_commit(self.commit_id, *args)


class Reflog(BaldurCase):

    def test_reflog_entries_are_idempotent(self):
        args = (self.repo, "2026-10-02T09:00:00Z", "checkout", "a" * 40, "moving to feature")
        self.assertTrue(self.m.baldur.record_reflog(*args))
        self.assertFalse(self.m.baldur.record_reflog(*args))


class Calendar(BaldurCase):

    def event(self, **overrides):
        base = dict(external_id="ev-1", title="Standup", starts_at="2026-10-02T13:00:00Z",
                    ends_at="2026-10-02T13:15:00Z", response="accepted")
        base.update(overrides)
        return base

    def cal_run(self, mode="incremental"):
        return self.m.run(source="odin-calendar", stream="meetings", kind="manual", mode=mode)

    def test_outcomes_come_from_comparing_fields(self):
        with self.cal_run() as run:
            a = run.baldur.upsert_calendar_event(self.event())
            b = run.baldur.upsert_calendar_event(self.event())
            c = run.baldur.upsert_calendar_event(self.event(ends_at="2026-10-02T13:30:00Z"))
        self.assertEqual([a.outcome, b.outcome, c.outcome],
                         [common.CREATED, common.UNCHANGED, common.UPDATED])

    def test_declined_cancelled_free_and_all_day_are_not_busy(self):
        with self.cal_run() as run:
            run.baldur.upsert_calendar_event(self.event(external_id="ok"))
            run.baldur.upsert_calendar_event(self.event(external_id="declined", response="declined"))
            run.baldur.upsert_calendar_event(self.event(external_id="cancelled", is_cancelled=True))
            run.baldur.upsert_calendar_event(self.event(external_id="free", show_as="free"))
            run.baldur.upsert_calendar_event(self.event(external_id="allday", is_all_day=True))
        busy = self.m.baldur.busy_meetings_between("2026-10-02T00:00:00Z", "2026-10-03T00:00:00Z")
        self.assertEqual([b["external_id"] for b in busy], ["ok"])

    def test_an_event_that_ends_before_it_starts_is_refused(self):
        with self.cal_run() as run, self.assertRaises(RuleViolation):
            run.baldur.upsert_calendar_event(self.event(ends_at="2026-10-02T12:00:00Z"))

    def test_a_full_calendar_sync_sweeps_and_restores(self):
        with self.cal_run("full") as run:
            run.baldur.upsert_calendar_event(self.event(external_id="a"))
            run.baldur.upsert_calendar_event(self.event(external_id="b"))
        self.clock.advance(60)
        with self.cal_run("full") as run:
            run.baldur.upsert_calendar_event(self.event(external_id="a"))
        self.assertIsNotNone(self.m.conn.execute(
            "SELECT deleted_at FROM calendar_events WHERE external_id = 'b'").fetchone()[0])
        self.clock.advance(60)
        with self.cal_run("full") as run:
            run.baldur.upsert_calendar_event(self.event(external_id="a"))
            back = run.baldur.upsert_calendar_event(self.event(external_id="b"))
        self.assertEqual(back.outcome, common.RESTORED)


class OdinExtras(MuninnCase):

    def setUp(self):
        super().setUp()
        self.m = self.open("odin")
        self.m.add_identity("jira_user", "bjones")
        with self.jira_run(self.m) as run:
            self.item = run.upsert_work_item(issue())

    def test_transitions_are_idempotent_and_flag_my_own(self):
        t = dict(changelog_id="5001", at="2026-10-02T10:00:00.000+0000", from_status="To Do",
                 to_status="In Progress", to_category="indeterminate", author="BJones")
        with self.jira_run(self.m) as run:
            first = run.odin.upsert_transition(self.item.id, t)
            again = run.odin.upsert_transition(self.item.id, t)
        self.assertEqual((first.outcome, again.outcome), (common.CREATED, common.UNCHANGED))
        self.assertEqual(self.m.conn.execute("SELECT by_me FROM work_item_transitions").fetchone()[0], 1)

    def test_jira_worklogs_are_idempotent_and_track_edits(self):
        w = dict(jira_worklog_id="77", started_at="2026-10-02T10:00:00.000+0000", seconds=1800)
        with self.jira_run(self.m) as run:
            a = run.odin.upsert_jira_worklog(self.item.id, w)
            b = run.odin.upsert_jira_worklog(self.item.id, w)
            c = run.odin.upsert_jira_worklog(self.item.id, dict(w, seconds=3600))
        self.assertEqual([a.outcome, b.outcome, c.outcome],
                         [common.CREATED, common.UNCHANGED, common.UPDATED])
        self.assertEqual(self.m.conn.execute("SELECT origin, state, seconds FROM worklogs").fetchone()[:],
                         ("jira", "posted", 3600))

    def test_a_worklog_of_zero_seconds_is_refused(self):
        with self.jira_run(self.m) as run, self.assertRaises(RuleViolation):
            run.odin.upsert_jira_worklog(self.item.id, dict(jira_worklog_id="1", started_at="2026-10-02T10:00:00Z", seconds=0))

    def test_validation_catches_the_mistakes_a_sync_actually_makes(self):
        bad = [dict(jira_id="ABC-123"), dict(key="abc-123"), dict(project_key="XYZ"),
               dict(url="jira/browse/ABC-123"), dict(status_category="blocked"),
               dict(labels="backend"), dict(story_points=-1), dict(summary="")]
        with self.jira_run(self.m) as run:
            for patch in bad:
                with self.subTest(patch=patch), self.assertRaises(RuleViolation):
                    run.upsert_work_item(issue(**patch))

    def test_my_open_items_uses_the_partial_index(self):
        """Pins the exact SQL my_open_items runs. `<> 'done'` would scan another index instead."""
        import inspect
        from asgard.muninn import odin as odin_module
        source = inspect.getsource(odin_module.OdinApi.my_open_items)
        sql = ("SELECT id FROM work_items WHERE is_mine = 1 AND deleted_at IS NULL "
               "AND status_category IN ('todo', 'in_progress') ORDER BY updated_at DESC")
        self.assertIn("status_category IN ('todo', 'in_progress')", source)
        plan = " ".join(r[3] for r in self.m.conn.execute("EXPLAIN QUERY PLAN " + sql))
        self.assertIn("ix_work_items_open_mine", plan)
        self.assertEqual([i["key"] for i in self.m.odin.my_open_items()], ["ABC-123"])


class Search(MuninnCase):

    def setUp(self):
        super().setUp()
        self.m = self.open("odin")
        with self.jira_run(self.m) as run:
            run.upsert_work_item(issue())

    def test_a_jira_key_is_searchable_as_typed(self):
        """Raw FTS5 parses ABC-123 as "ABC minus 123" and errors with "no such column: 123"."""
        self.assertEqual([h["title"] for h in self.m.search("ABC-123")], ["ABC-123 Fix retry logic"])

    def test_what_people_type_never_raises(self):
        for query in ('say "hi', "AND", "NEAR(", "*", "(((", "---", "", "   ", "\x00"):
            with self.subTest(query=query):
                self.assertIsInstance(self.m.search(query), list)

    def test_prefix_and_stemming(self):
        self.assertEqual(len(self.m.search("retr*")), 1)
        self.assertEqual(len(self.m.search("fixing")), 1, "porter: fixing -> fix")

    def test_the_index_follows_a_key_change(self):
        with self.jira_run(self.m) as run:
            run.upsert_work_item(issue(key="XYZ-45", project_key="XYZ", updated_at="2026-10-02T11:00:00Z"))
        self.assertEqual(self.m.search("ABC-123"), [])
        self.assertEqual(len(self.m.search("XYZ-45")), 1)

    def test_the_rowid_decodes_to_the_entity(self):
        hit = self.m.search("retry")[0]
        self.assertEqual((hit["kind"], hit["type_code"]), ("work_items", 1))
        self.assertIsNotNone(self.m.conn.execute("SELECT 1 FROM work_items WHERE id = ?", (hit["entity_id"],)).fetchone())


class Maintenance(MuninnCase):

    def test_integrity_check_is_empty_when_healthy(self):
        self.assertEqual(self.open().integrity_check(), [])

    def test_stats_report_the_schema_version_and_row_counts(self):
        stats = self.open().stats()
        self.assertEqual(stats["schema_version"], dbmod_latest())
        self.assertIn("work_items", stats["rows"])
        self.assertNotIn("search_data", stats["rows"])

    def test_old_reflog_is_pruned_and_recent_kept(self):
        b = self.open("baldur")
        repo = b.baldur.upsert_repo("r", str(self.tmp / "r"))
        b.baldur.record_reflog(repo, "2025-01-01T00:00:00Z", "checkout", "a" * 40)
        b.baldur.record_reflog(repo, "2026-10-01T00:00:00Z", "checkout", "b" * 40)
        result = self.open("muninn").prune()
        self.assertEqual(result["reflog_entries"], 1)
        self.assertEqual(b.conn.execute("SELECT count(*) FROM reflog_entries").fetchone()[0], 1)

    def test_a_running_sync_is_never_pruned(self):
        """The row is inserted AFTER the muninn handle opens: opening reaps dead 'running' rows
        (a run 'running' since 2020 is a crashed process), which would hide the guard under test."""
        janitor = self.open("muninn")
        source = janitor.ensure_source("jira-dc", "jira")
        janitor.conn.execute("INSERT INTO sync_runs (app, source_id, stream, started_at, status) "
                             "VALUES ('odin', ?, 'issues', '2020-01-01T00:00:00Z', 'running')", (source,))
        self.assertEqual(janitor.prune()["sync_runs"], 0)

    def test_a_dead_running_sync_is_reaped_on_open_and_then_pruned_normally(self):
        m = self.open()
        source = m.ensure_source("jira-dc", "jira")
        m.conn.execute("INSERT INTO sync_runs (app, source_id, stream, started_at, status) "
                       "VALUES ('odin', ?, 'issues', '2020-01-01T00:00:00Z', 'running')", (source,))
        self.assertEqual(self.open("muninn").prune()["sync_runs"], 1)

    def test_an_unknown_source_kind_or_app_is_refused(self):
        m = self.open()
        with self.assertRaises(RuleViolation):
            m.ensure_source("x", "carrier-pigeon")
        with self.assertRaises(RuleViolation):
            m.ensure_source("x", "jira", base_url="ftp://nope")

    def test_a_source_cannot_quietly_change_kind(self):
        m = self.open()
        m.ensure_source("jira-dc", "jira")
        with self.assertRaises(RuleViolation):
            m.ensure_source("jira-dc", "git")

    def test_an_identity_is_stored_once_whatever_its_case(self):
        m = self.open()
        self.assertTrue(m.add_identity("git_email", "Me@Agency.gov"))
        self.assertFalse(m.add_identity("git_email", "me@agency.gov"))
        with self.assertRaises(RuleViolation):
            m.add_identity("git_email", "   ")
        with self.assertRaises(RuleViolation):
            m.add_identity("ssn", "x")

    def test_loki_cannot_write_baldur_or_odin_tables(self):
        loki = self.open("loki")
        with self.assertRaises(OwnershipError):
            loki.baldur.upsert_repo("x")
        with self.assertRaises(OwnershipError):
            loki.odin.recompute_ownership()


if __name__ == "__main__":
    unittest.main()
