"""The sync run: atomicity, failure handling, cursors, the deletion sweep, and concurrent writers.

The lifecycle under test is the design's "Write path": open a run row, BEGIN IMMEDIATE, upsert,
sweep (full runs only), advance the cursor, commit. The three hardening decisions are tested as
named behaviours because each one prevents a specific silent loss of data.
"""
import sqlite3
import threading
import unittest

from helpers import MuninnCase, issue

from asgard import muninn
from asgard.muninn.errors import RuleViolation, SyncError


def seed(m, count, clock=None, prefix="ABC"):
    """`count` live issues, inserted by a first full run."""
    with m.run(source="jira-dc", stream="issues", kind="jira", mode="full") as run:
        for i in range(1, count + 1):
            run.upsert_work_item(issue(jira_id=10000 + i, key="{}-{}".format(prefix, i), summary="item %d" % i))
    if clock:
        clock.advance(60)


class Atomicity(MuninnCase):

    def test_an_exception_rolls_back_every_write_in_the_run(self):
        m = self.open()
        with self.assertRaises(RuntimeError):
            with self.jira_run(m) as run:
                run.upsert_work_item(issue())
                run.upsert_work_item(issue(jira_id=10002, key="ABC-124"))
                raise RuntimeError("the network dropped")
        self.assertEqual(m.conn.execute("SELECT count(*) FROM work_items").fetchone()[0], 0)
        self.assertEqual(m.conn.execute("SELECT count(*) FROM events WHERE kind LIKE 'work_item.%'").fetchone()[0], 0)

    def test_a_failure_leaves_a_visible_trace_rather_than_vanishing(self):
        m = self.open()
        with self.assertRaises(RuntimeError):
            with self.jira_run(m) as run:
                run.upsert_work_item(issue())
                raise RuntimeError("the network dropped")
        row = m.conn.execute("SELECT status, error, items_seen FROM sync_runs").fetchone()
        self.assertEqual(row["status"], "failed")
        self.assertIn("network dropped", row["error"])
        self.assertEqual(row["items_seen"], 1)

    def test_the_original_exception_is_what_propagates(self):
        m = self.open()
        with self.assertRaises(KeyError):
            with self.jira_run(m):
                raise KeyError("original")

    def test_a_keyboard_interrupt_is_recorded_and_rolled_back(self):
        m = self.open()
        with self.assertRaises(KeyboardInterrupt):
            with self.jira_run(m) as run:
                run.upsert_work_item(issue())
                raise KeyboardInterrupt()
        self.assertEqual(m.conn.execute("SELECT count(*) FROM work_items").fetchone()[0], 0)
        self.assertEqual(m.conn.execute("SELECT status FROM sync_runs").fetchone()[0], "failed")

    def test_the_handle_is_usable_after_a_failed_run(self):
        m = self.open()
        with self.assertRaises(RuntimeError):
            with self.jira_run(m):
                raise RuntimeError("x")
        with self.jira_run(m) as run:
            run.upsert_work_item(issue())
        self.assertEqual(m.conn.execute("SELECT count(*) FROM work_items").fetchone()[0], 1)

    def test_a_run_cannot_start_inside_a_transaction(self):
        m = self.open()
        with m.transaction():
            with self.assertRaises(SyncError):
                self.jira_run(m).__enter__()

    def test_savepoints_let_an_inner_failure_roll_back_alone(self):
        m = self.open()
        m.ensure_source("jira-dc", "jira")
        with m.transaction():
            m.conn.execute("INSERT INTO meta (key, value) VALUES ('outer', '1')")
            try:
                with m.transaction():
                    m.conn.execute("INSERT INTO meta (key, value) VALUES ('inner', '1')")
                    raise RuntimeError("inner fails")
            except RuntimeError:
                pass
        keys = {r[0] for r in m.conn.execute("SELECT key FROM meta")}
        self.assertIn("outer", keys)
        self.assertNotIn("inner", keys)


class BadItemsDoNotCostTheSync(MuninnCase):

    def test_a_rejected_item_is_skipped_and_the_rest_land(self):
        m = self.open()
        with self.jira_run(m) as run:
            with run.item("ABC-1"):
                run.upsert_work_item(issue(jira_id=1, key="ABC-1"))
            with run.item("BAD-2"):
                run.upsert_work_item(issue(jira_id=2, key="BAD-2", project_key="BAD", updated_at="not a date"))
            with run.item("ABC-3"):
                run.upsert_work_item(issue(jira_id=3, key="ABC-3"))
        self.assertEqual([r[0] for r in m.conn.execute("SELECT key FROM work_items ORDER BY key")], ["ABC-1", "ABC-3"])
        row = m.conn.execute("SELECT status, error FROM sync_runs").fetchone()
        self.assertEqual(row["status"], "partial")
        self.assertIn("BAD-2", row["error"])

    def test_a_skipped_items_partial_writes_are_rolled_back(self):
        """The item is a savepoint: a half-applied item must not leave half a row behind."""
        m = self.open()
        with self.jira_run(m) as run:
            with run.item("ABC-9"):
                run.upsert_work_item(issue(jira_id=9, key="ABC-9"))
                raise RuleViolation("rejected after the row was written")
        self.assertEqual(m.conn.execute("SELECT count(*) FROM work_items").fetchone()[0], 0)

    def test_a_partial_run_does_not_advance_the_cursor(self):
        """Moving the high-water mark past a skipped item means it is never fetched again."""
        m = self.open()
        with self.jira_run(m) as run:
            run.advance_cursor("2026-10-02T10:00:00Z")
            run.upsert_work_item(issue())
        self.clock.advance(60)
        with self.jira_run(m) as run:
            self.assertEqual(run.cursor, "2026-10-02T10:00:00Z")
            with run.item("ABC-2"):
                raise RuleViolation("bad")
            run.advance_cursor("2026-10-02T11:00:00Z")
        self.assertEqual(m.conn.execute("SELECT cursor FROM sync_cursors").fetchone()[0], "2026-10-02T10:00:00Z")

    def test_a_clean_run_does_advance_it(self):
        m = self.open()
        with self.jira_run(m) as run:
            run.advance_cursor("2026-10-02T11:00:00Z")
        self.clock.advance(60)
        with self.jira_run(m) as run:
            self.assertEqual(run.cursor, "2026-10-02T11:00:00Z")

    def test_advancing_on_partial_is_available_when_asked_for(self):
        m = self.open()
        with self.jira_run(m, advance_cursor_on_partial=True) as run:
            with run.item("ABC-2"):
                raise RuleViolation("bad")
            run.advance_cursor("2026-10-02T11:00:00Z")
        self.assertEqual(m.conn.execute("SELECT cursor FROM sync_cursors").fetchone()[0], "2026-10-02T11:00:00Z")

    def test_a_failed_run_never_advances_the_cursor(self):
        m = self.open()
        with self.assertRaises(RuntimeError):
            with self.jira_run(m) as run:
                run.advance_cursor("2026-10-02T11:00:00Z")
                raise RuntimeError("x")
        self.assertEqual(m.conn.execute("SELECT count(*) FROM sync_cursors").fetchone()[0], 0)

    def test_a_cursor_must_be_a_non_empty_string(self):
        m = self.open()
        with self.jira_run(m) as run:
            for bad in ("", None, 12345):
                with self.subTest(bad=bad), self.assertRaises(SyncError):
                    run.advance_cursor(bad)

    def test_many_skips_are_counted_but_only_some_are_stored(self):
        m = self.open()
        with self.jira_run(m) as run:
            for i in range(50):
                with run.item("X-%d" % i):
                    raise RuleViolation("bad")
        self.assertEqual(len(run.skipped), 50)
        self.assertLess(len(m.conn.execute("SELECT error FROM sync_runs").fetchone()[0]), 1001)


class TheDeletionSweep(MuninnCase):
    """Deletion is inferred from absence, and an empty or truncated response looks exactly like
    'everything was deleted'. These are the guards against that."""

    def test_a_full_run_soft_deletes_what_it_did_not_see(self):
        m = self.open()
        seed(m, 4, self.clock)
        with m.run(source="jira-dc", stream="issues", mode="full") as run:
            for i in (1, 2, 3):
                run.upsert_work_item(issue(jira_id=10000 + i, key="ABC-%d" % i, summary="item %d" % i))
        live = {r[0] for r in m.conn.execute("SELECT key FROM work_items WHERE deleted_at IS NULL")}
        self.assertEqual(live, {"ABC-1", "ABC-2", "ABC-3"})
        self.assertIsNotNone(m.conn.execute("SELECT deleted_at FROM work_items WHERE key = 'ABC-4'").fetchone()[0])
        self.assertIn("work_item.deleted", [e["kind"] for e in m.events_since("2000-01-01T00:00:00Z")])

    def test_rows_are_never_actually_deleted(self):
        m = self.open()
        seed(m, 4, self.clock)
        with m.run(source="jira-dc", stream="issues", mode="full") as run:
            run.upsert_work_item(issue(jira_id=10001, key="ABC-1", summary="item 1"))
        self.assertEqual(m.conn.execute("SELECT count(*) FROM work_items").fetchone()[0], 4)

    def test_an_incremental_run_never_deletes_anything(self):
        m = self.open()
        seed(m, 4, self.clock)
        with m.run(source="jira-dc", stream="issues") as run:
            run.upsert_work_item(issue(jira_id=10001, key="ABC-1", summary="item 1"))
        self.assertEqual(m.conn.execute("SELECT count(*) FROM work_items WHERE deleted_at IS NULL").fetchone()[0], 4)

    def test_an_empty_full_sync_is_refused_not_treated_as_a_mass_deletion(self):
        """An expired token, a proxy error page or a timeout all produce an empty response."""
        m = self.open()
        seed(m, 5, self.clock)
        with self.assertRaises(SyncError) as caught:
            with m.run(source="jira-dc", stream="issues", mode="full") as run:
                run.saw("work_items", "unchanged") if False else None
                run._seen_by_table["work_items"] = 0           # the stream was touched but returned nothing
        self.assertIn("nothing", str(caught.exception))
        self.assertEqual(m.conn.execute("SELECT count(*) FROM work_items WHERE deleted_at IS NULL").fetchone()[0], 5)
        self.assertEqual(m.conn.execute("SELECT status FROM sync_runs ORDER BY id DESC").fetchone()[0], "failed")

    def test_a_truncated_response_that_would_delete_most_rows_is_refused(self):
        m = self.open()
        seed(m, 20, self.clock)
        with self.assertRaises(SyncError) as caught:
            with m.run(source="jira-dc", stream="issues", mode="full") as run:
                for i in range(1, 6):                          # saw 5 of 20
                    run.upsert_work_item(issue(jira_id=10000 + i, key="ABC-%d" % i, summary="item %d" % i))
        self.assertIn("15 of 20", str(caught.exception))
        self.assertEqual(m.conn.execute("SELECT count(*) FROM work_items WHERE deleted_at IS NULL").fetchone()[0], 20)

    def test_a_failed_sweep_rolls_back_the_whole_run_including_its_upserts(self):
        m = self.open()
        seed(m, 20, self.clock)
        with self.assertRaises(SyncError):
            with m.run(source="jira-dc", stream="issues", mode="full") as run:
                run.upsert_work_item(issue(jira_id=10001, key="ABC-1", summary="CHANGED"))
        self.assertEqual(m.conn.execute("SELECT summary FROM work_items WHERE key = 'ABC-1'").fetchone()[0], "item 1")

    def test_a_small_set_may_lose_most_of_its_rows(self):
        """Below the threshold a high percentage is normal, not alarming."""
        m = self.open()
        seed(m, 4, self.clock)
        with m.run(source="jira-dc", stream="issues", mode="full") as run:
            run.upsert_work_item(issue(jira_id=10001, key="ABC-1", summary="item 1"))
        self.assertEqual(m.conn.execute("SELECT count(*) FROM work_items WHERE deleted_at IS NULL").fetchone()[0], 1)

    def test_a_sweep_only_touches_its_own_source(self):
        m = self.open()
        seed(m, 4, self.clock)
        with m.run(source="other-jira", stream="issues", kind="jira", mode="full") as run:
            run.upsert_work_item(issue(jira_id=99, key="OTH-1", project_key="OTH"))
        self.assertEqual(m.conn.execute("SELECT count(*) FROM work_items WHERE deleted_at IS NULL").fetchone()[0], 5)

    def test_a_deleted_item_that_comes_back_is_restored(self):
        m = self.open()
        seed(m, 4, self.clock)
        with m.run(source="jira-dc", stream="issues", mode="full") as run:
            for i in (1, 2, 3):
                run.upsert_work_item(issue(jira_id=10000 + i, key="ABC-%d" % i, summary="item %d" % i))
        self.clock.advance(60)
        with m.run(source="jira-dc", stream="issues", mode="full") as run:
            for i in (1, 2, 3, 4):
                result = run.upsert_work_item(issue(jira_id=10000 + i, key="ABC-%d" % i, summary="item %d" % i))
        self.assertEqual(result.outcome, "restored")


class CrashRecovery(MuninnCase):

    def test_a_run_left_running_by_a_dead_process_is_reaped_on_next_open(self):
        m = self.open()
        source = m.ensure_source("jira-dc", "jira")
        m.conn.execute("INSERT INTO sync_runs (app, source_id, stream, started_at, status) "
                       "VALUES ('odin', ?, 'issues', '2026-10-02T01:00:00Z', 'running')", (source,))
        m.close()
        reopened = self.open()
        row = reopened.conn.execute("SELECT status, error FROM sync_runs").fetchone()
        self.assertEqual(row["status"], "failed")
        self.assertIn("interrupted", row["error"])

    def test_a_recent_running_run_is_left_alone(self):
        m = self.open()
        source = m.ensure_source("jira-dc", "jira")
        m.conn.execute("INSERT INTO sync_runs (app, source_id, stream, started_at, status) "
                       "VALUES ('odin', ?, 'issues', '2026-10-02T11:30:00Z', 'running')", (source,))
        m.close()
        self.assertEqual(self.open().conn.execute("SELECT status FROM sync_runs").fetchone()[0], "running")

    def test_uncommitted_work_from_a_crash_never_appears(self):
        """Simulate the process dying mid-run: the connection is dropped without commit or rollback."""
        m = self.open()
        run = self.jira_run(m)
        run.__enter__()
        run.upsert_work_item(issue())
        m.conn.close()                     # the 'crash': no __exit__, no commit
        m.conn = None
        again = self.open()
        self.assertEqual(again.conn.execute("SELECT count(*) FROM work_items").fetchone()[0], 0)
        self.assertEqual(again.conn.execute("SELECT count(*) FROM events WHERE kind = 'work_item.created'").fetchone()[0], 0)


class ConcurrentWriters(MuninnCase):

    def test_a_second_writer_waits_and_then_fails_cleanly_rather_than_corrupting(self):
        first = self.open()
        second = self.open("baldur", busy_timeout_ms=200)
        with first.transaction():
            first.conn.execute("INSERT INTO meta (key, value) VALUES ('held', '1')") if first.app in ("muninn", "valkyrie") else None
            with self.assertRaises(sqlite3.OperationalError) as caught:
                second.conn.execute("BEGIN IMMEDIATE")
            self.assertIn("locked", str(caught.exception))

    def test_a_run_that_cannot_get_the_lock_says_so_and_changes_nothing(self):
        holder = self.open()
        waiter = self.open("baldur", busy_timeout_ms=200)
        waiter.ensure_source("local-git", "git")
        with holder.transaction():
            with self.assertRaises(SyncError) as caught:
                with waiter.run(source="local-git", stream="commits:x"):
                    pass
        self.assertIn("Another process", str(caught.exception))

    def test_readers_are_not_blocked_by_a_writer_in_wal_mode(self):
        writer = self.open()
        with self.jira_run(writer) as run:
            run.upsert_work_item(issue())
        reader = self.open("freya", read_only=True)
        with writer.transaction():
            writer.conn.execute("UPDATE work_items SET summary = 'uncommitted'")
            self.assertEqual(reader.conn.execute("SELECT summary FROM work_items").fetchone()[0], "Fix retry logic",
                             "a reader sees the last committed state, and is not blocked")

    def test_two_threads_syncing_different_streams_both_complete(self):
        self.open().close()
        errors = []

        def worker(name, base):
            try:
                handle = muninn.open("odin", self.path, clock=self.clock)
                try:
                    with handle.run(source="jira-dc", stream=name, kind="jira") as run:
                        for i in range(20):
                            run.upsert_work_item(issue(jira_id=base + i, key="T%s-%d" % (name[-1], i + 1),
                                                       project_key="T%s" % name[-1]))
                finally:
                    handle.close()
            except Exception as exc:        # noqa: BLE001 - surfaced through the assertion below
                errors.append(repr(exc))

        threads = [threading.Thread(target=worker, args=("issues-%d" % n, n * 1000)) for n in (1, 2, 3)]
        for t in threads:
            t.start()
        for t in threads:
            t.join(30)
        self.assertEqual(errors, [])
        check = self.open()
        self.assertEqual(check.conn.execute("SELECT count(*) FROM work_items").fetchone()[0], 60)
        self.assertEqual(check.conn.execute("SELECT count(*) FROM sync_runs WHERE status = 'ok'").fetchone()[0], 3)

    def test_a_handle_cannot_be_used_from_another_thread(self):
        m = self.open()
        caught = []

        def use():
            try:
                m.conn.execute("SELECT 1")
            except sqlite3.ProgrammingError as exc:
                caught.append(exc)

        t = threading.Thread(target=use)
        t.start()
        t.join()
        self.assertEqual(len(caught), 1, "sqlite3 must enforce one-connection-per-thread")


if __name__ == "__main__":
    unittest.main()
