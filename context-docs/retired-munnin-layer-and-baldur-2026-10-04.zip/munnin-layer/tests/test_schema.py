"""The schema file against the claims the design document makes about it, and against drift.

The design states numbers ("27 tables, 30 indexes, 5 views") and guarantees ("CHECK constraints
enforce the order"). The first kind is checked here as written. The second kind is checked in
test_rules.py, and that is where the gaps were found.
"""
import re
import sqlite3
import unittest
from pathlib import Path

from helpers import MuninnCase  # noqa: F401  (sets sys.path)

from asgard.muninn import db as dbmod
from asgard.muninn import ownership

ROOT = Path(__file__).resolve().parent.parent
MIGRATIONS = ROOT / "src" / "asgard" / "muninn" / "migrations"
DESIGN_SQL = ROOT / "muninn_schema.sql"


def apply_upto(version: int) -> sqlite3.Connection:
    conn = sqlite3.connect(":memory:", isolation_level=None)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    for migration in dbmod.migration_files()[:version]:
        conn.executescript(migration.path.read_text(encoding="utf-8"))
    return conn


def user_tables(conn):
    return [r["name"] for r in conn.execute(
        "SELECT name FROM sqlite_master WHERE type = 'table' AND name NOT LIKE 'sqlite_%' "
        "AND name NOT LIKE 'search%' ORDER BY name")]


class DesignClaimTests(unittest.TestCase):
    """v1 is the design's own file, so its numbers must match what the design says about it."""

    @classmethod
    def setUpClass(cls):
        cls.conn = apply_upto(1)

    @classmethod
    def tearDownClass(cls):
        cls.conn.close()

    def test_migration_0001_is_the_design_file_byte_for_byte(self):
        """If someone edits the schema in place instead of adding a migration, this fails."""
        if not DESIGN_SQL.is_file():
            self.skipTest("muninn_schema.sql is not alongside the tests")
        self.assertEqual((MIGRATIONS / "0001_initial.sql").read_bytes(), DESIGN_SQL.read_bytes())

    def test_the_design_counts(self):
        self.assertEqual(len(user_tables(self.conn)), 27, "design: 27 tables")
        indexes = self.conn.execute("SELECT count(*) FROM sqlite_master WHERE type = 'index' "
                                    "AND name LIKE 'ix\\_%' ESCAPE '\\' OR name LIKE 'ux\\_%' ESCAPE '\\'").fetchone()[0]
        self.assertEqual(indexes, 30, "design: 30 explicit indexes")
        views = self.conn.execute("SELECT count(*) FROM sqlite_master WHERE type = 'view'").fetchone()[0]
        self.assertEqual(views, 5, "design: 5 views")

    def test_version_1_sets_user_version_1(self):
        self.assertEqual(self.conn.execute("PRAGMA user_version").fetchone()[0], 1)


class EveryVersionTests(unittest.TestCase):

    def test_each_version_applies_on_top_of_the_last(self):
        for version in range(1, dbmod.latest_version() + 1):
            with self.subTest(version=version):
                conn = apply_upto(version)
                self.addCleanup(conn.close)
                self.assertEqual(conn.execute("PRAGMA user_version").fetchone()[0], version)
                self.assertEqual(conn.execute("PRAGMA foreign_key_check").fetchall(), [])

    def test_the_latest_version_is_the_number_of_migration_files(self):
        self.assertEqual(dbmod.latest_version(), len(list(MIGRATIONS.glob("*.sql"))))

    def test_every_real_table_is_strict(self):
        """`STRICT` is what makes a TEXT column reject an integer. One non-strict table would quietly
        reintroduce type coercion."""
        conn = apply_upto(dbmod.latest_version())
        self.addCleanup(conn.close)
        for row in conn.execute("PRAGMA table_list"):
            if row["schema"] != "main" or row["name"].startswith(("sqlite_", "search")):
                continue
            if row["type"] == "table":
                with self.subTest(table=row["name"]):
                    self.assertEqual(row["strict"], 1, "{} is not STRICT".format(row["name"]))

    def test_strict_rejects_what_cannot_be_converted(self):
        conn = apply_upto(1)
        self.addCleanup(conn.close)
        with self.assertRaises(sqlite3.IntegrityError):
            conn.execute("INSERT INTO sources (kind, name) VALUES ('jira', ?)", (b"bytes",))
        with self.assertRaises(sqlite3.IntegrityError):
            conn.execute("INSERT INTO sources (kind, name) VALUES ('jira', 'a')")
            conn.execute("INSERT INTO work_items (source_id, jira_id, key, project_key, issue_type, summary, "
                         "status, status_category, url, created_at, updated_at, first_seen_at, last_seen_at, "
                         "story_points) VALUES (1,'1','A-1','A','T','s','s','todo','u',"
                         "'2026-10-02T10:00:00Z','2026-10-02T10:00:00Z','2026-10-02T10:00:00Z',"
                         "'2026-10-02T10:00:00Z','not a number')")

    def test_strict_COERCES_convertible_values_contrary_to_the_design_doc(self):
        """The design's conventions table says a STRICT TEXT column "rejects integers and vice versa".
        It does not: SQLite converts anything losslessly convertible and rejects only the rest.

        Recorded as a test so nobody leans on the documented behaviour. It is the reason the writer
        validates types at the edge (a Jira id of 10234 arrives as an int and is normalised to
        '10234' deliberately, rather than relying on the schema to notice).
        """
        conn = apply_upto(1)
        self.addCleanup(conn.close)
        conn.execute("INSERT INTO sources (kind, name) VALUES ('jira', ?)", (12345,))   # int into TEXT
        self.assertEqual(conn.execute("SELECT typeof(name), name FROM sources").fetchone()[:], ("text", "12345"))


class OwnershipCoverageTests(unittest.TestCase):
    """Rule 5 is data. When a migration adds a table, this fails until someone says who owns it."""

    def test_every_table_has_an_owner_or_is_infrastructure(self):
        conn = apply_upto(dbmod.latest_version())
        self.addCleanup(conn.close)
        unowned = [t for t in user_tables(conn) if not ownership.is_known_table(t)]
        self.assertEqual(unowned, [], "add these to asgard/muninn/ownership.py: {}".format(unowned))

    def test_the_ownership_table_names_no_table_that_does_not_exist(self):
        conn = apply_upto(dbmod.latest_version())
        self.addCleanup(conn.close)
        existing = set(user_tables(conn))
        ghosts = [t for t in ownership.OWNERS if t not in existing]
        self.assertEqual(ghosts, [], "ownership lists tables the schema does not have")

    def test_every_owner_is_a_known_app(self):
        for table, owners in ownership.OWNERS.items():
            with self.subTest(table=table):
                self.assertTrue(owners.issubset(set(ownership.APPS)))

    def test_the_apps_match_the_schema_check_constraint(self):
        """The list of apps lives in two CHECK constraints; the Python list must not drift from them."""
        text = (MIGRATIONS / "0001_initial.sql").read_text(encoding="utf-8")
        in_schema = set(re.findall(r"app IN \(([^)]*)\)", text)[0].replace("'", "").replace(" ", "").split(","))
        self.assertEqual(in_schema, set(ownership.APPS))


class MigrationFileTests(unittest.TestCase):

    def test_every_migration_is_self_transactional_and_sets_its_own_version(self):
        for migration in dbmod.migration_files():
            with self.subTest(migration=migration.name):
                dbmod._validate_migration(migration, migration.path.read_text(encoding="utf-8"))

    def test_0002_is_the_baldur_spec_sql(self):
        """It was extracted from the spec, not retyped; check the parts that matter are present."""
        text = (MIGRATIONS / "0002_baldur.sql").read_text(encoding="utf-8")
        for needle in ("CREATE TABLE day_proposals", "CREATE TABLE calendar_events",
                       "CREATE TABLE estimate_runs", "CREATE VIEW v_day_status",
                       "minutes_proposed <= minutes_raw", "PRAGMA user_version = 2"):
            self.assertIn(needle, text)


if __name__ == "__main__":
    unittest.main()
