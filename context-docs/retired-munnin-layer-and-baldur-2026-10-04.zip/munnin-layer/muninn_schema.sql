-- =====================================================================
-- Muninn schema v1  (PRAGMA user_version = 1)
-- Asgard's shared data layer: one SQLite file per user at
--   %LOCALAPPDATA%\Asgard\muninn.db
--
-- Requires SQLite 3.37+ (STRICT tables), FTS5 and the JSON functions.
-- The file carries its own BEGIN/COMMIT, so it applies all or nothing.
--
-- Conventions
--   ts columns    TEXT, UTC, 'YYYY-MM-DDTHH:MM:SSZ'
--                 CHECK (strftime('%Y-%m-%dT%H:%M:%SZ', col) IS col)
--   date columns  TEXT, 'YYYY-MM-DD'   CHECK (date(col) IS col)
--   booleans      INTEGER 0/1
--   JSON          TEXT, CHECK (json_valid(col) ...)
--   keys          id INTEGER PRIMARY KEY; source-system IDs are UNIQUE
--   run_id        last sync run that touched the row; SET NULL when
--                 old sync_runs rows are pruned
--
-- Connection settings live in the writer module, not here:
--   once per file:     PRAGMA journal_mode = WAL;
--   every connection:  PRAGMA foreign_keys = ON;
--                      PRAGMA busy_timeout = 5000;
--                      PRAGMA synchronous = NORMAL;
-- =====================================================================

BEGIN;

-- =====================================================================
-- Provenance and sync
-- =====================================================================

-- Key/value settings: owner, timezone, created_at, asgard_version.
CREATE TABLE meta (
    key    TEXT PRIMARY KEY,
    value  TEXT NOT NULL
) STRICT, WITHOUT ROWID;

-- One row per external system Asgard reads from or writes to.
CREATE TABLE sources (
    id          INTEGER PRIMARY KEY,
    kind        TEXT NOT NULL CHECK (kind IN ('jira','confluence','git','github','teams','secchm','manual')),
    name        TEXT NOT NULL UNIQUE,              -- 'jira-dc', 'github', 'local-git', 'paste'
    base_url    TEXT,                              -- NULL for local git and pasted input
    created_at  TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now'))
                CHECK (strftime('%Y-%m-%dT%H:%M:%SZ', created_at) IS created_at)
) STRICT;

-- The owner's identities in each system; drives every is_mine flag.
CREATE TABLE identities (
    id         INTEGER PRIMARY KEY,
    kind       TEXT NOT NULL CHECK (kind IN ('git_email','git_name','jira_user','github_login','m365_upn','display_name')),
    value      TEXT NOT NULL COLLATE NOCASE,
    source_id  INTEGER REFERENCES sources(id),
    UNIQUE (kind, value)
) STRICT;

-- One row per collector run (Huginn schedules them; each app runs its own).
CREATE TABLE sync_runs (
    id             INTEGER PRIMARY KEY,
    app            TEXT NOT NULL CHECK (app IN ('muninn','huginn','odin','baldur','loki','freya','heimdall','bifrost','ysildir','valkyrie')),
    source_id      INTEGER REFERENCES sources(id),
    stream         TEXT NOT NULL,                  -- 'issues', 'commits:<repo>', 'meetings'
    mode           TEXT NOT NULL DEFAULT 'incremental' CHECK (mode IN ('incremental','full')),
    started_at     TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now'))
                   CHECK (strftime('%Y-%m-%dT%H:%M:%SZ', started_at) IS started_at),
    finished_at    TEXT CHECK (strftime('%Y-%m-%dT%H:%M:%SZ', finished_at) IS finished_at),
    status         TEXT NOT NULL DEFAULT 'running' CHECK (status IN ('running','ok','partial','failed')),
    items_seen     INTEGER NOT NULL DEFAULT 0 CHECK (items_seen >= 0),
    items_changed  INTEGER NOT NULL DEFAULT 0 CHECK (items_changed >= 0),
    cursor_before  TEXT,
    cursor_after   TEXT,
    error          TEXT
) STRICT;

-- High-water mark per stream; advanced only after a run commits.
CREATE TABLE sync_cursors (
    source_id   INTEGER NOT NULL REFERENCES sources(id),
    stream      TEXT NOT NULL,
    cursor      TEXT NOT NULL,                     -- Jira 'updated' time, last SHA, Graph delta link
    updated_at  TEXT NOT NULL CHECK (strftime('%Y-%m-%dT%H:%M:%SZ', updated_at) IS updated_at),
    run_id      INTEGER REFERENCES sync_runs(id) ON DELETE SET NULL,
    PRIMARY KEY (source_id, stream)
) STRICT, WITHOUT ROWID;

-- Append-only change log; the one table every app writes.
CREATE TABLE events (
    id           INTEGER PRIMARY KEY,
    at           TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now'))
                 CHECK (strftime('%Y-%m-%dT%H:%M:%SZ', at) IS at),
    app          TEXT NOT NULL CHECK (app IN ('muninn','huginn','odin','baldur','loki','freya','heimdall','bifrost','ysildir','valkyrie')),
    kind         TEXT NOT NULL CHECK (kind GLOB '[a-z]*.[a-z]*'),   -- 'work_item.updated'
    entity_type  TEXT NOT NULL,                    -- table name, e.g. 'work_items'
    entity_id    INTEGER,                          -- row id in that table
    ref          TEXT,                             -- external ID: Jira key, SHA, meeting ID
    run_id       INTEGER,                          -- deliberately no FK: events outlive pruned sync_runs
    payload      TEXT NOT NULL DEFAULT '{}' CHECK (json_valid(payload) AND json_type(payload) = 'object')
) STRICT;

CREATE TRIGGER events_no_update BEFORE UPDATE ON events
BEGIN
    SELECT RAISE(ABORT, 'events are append-only');
END;

CREATE TRIGGER events_no_delete BEFORE DELETE ON events
BEGIN
    SELECT RAISE(ABORT, 'events are append-only');
END;

-- =====================================================================
-- Work (Odin)
-- =====================================================================

-- Jira issues. jira_id is stable; key changes if an issue moves projects.
CREATE TABLE work_items (
    id               INTEGER PRIMARY KEY,
    source_id        INTEGER NOT NULL REFERENCES sources(id),
    jira_id          TEXT NOT NULL,                -- numeric issue id as text, '10234'
    key              TEXT NOT NULL,                -- 'ABC-123'
    project_key      TEXT NOT NULL,
    issue_type       TEXT NOT NULL,                -- Story, Bug, Task, Epic, Sub-task
    summary          TEXT NOT NULL,
    status           TEXT NOT NULL,                -- workflow status name as shown in Jira
    status_category  TEXT NOT NULL CHECK (status_category IN ('todo','in_progress','done')),
    priority         TEXT,
    epic_key         TEXT,
    parent_key       TEXT,
    assignee         TEXT,
    reporter         TEXT,
    is_mine          INTEGER NOT NULL DEFAULT 0 CHECK (is_mine IN (0,1)),   -- assigned to me now or ever
    labels           TEXT NOT NULL DEFAULT '[]' CHECK (json_valid(labels) AND json_type(labels) = 'array'),
    components       TEXT NOT NULL DEFAULT '[]' CHECK (json_valid(components) AND json_type(components) = 'array'),
    story_points     REAL CHECK (story_points >= 0),
    sprint           TEXT,
    url              TEXT NOT NULL,
    created_at       TEXT NOT NULL CHECK (strftime('%Y-%m-%dT%H:%M:%SZ', created_at) IS created_at),     -- in Jira
    updated_at       TEXT NOT NULL CHECK (strftime('%Y-%m-%dT%H:%M:%SZ', updated_at) IS updated_at),     -- in Jira
    resolved_at      TEXT CHECK (strftime('%Y-%m-%dT%H:%M:%SZ', resolved_at) IS resolved_at),
    due_on           TEXT CHECK (date(due_on) IS due_on),
    first_seen_at    TEXT NOT NULL CHECK (strftime('%Y-%m-%dT%H:%M:%SZ', first_seen_at) IS first_seen_at),
    last_seen_at     TEXT NOT NULL CHECK (strftime('%Y-%m-%dT%H:%M:%SZ', last_seen_at) IS last_seen_at),
    deleted_at       TEXT CHECK (strftime('%Y-%m-%dT%H:%M:%SZ', deleted_at) IS deleted_at),
    run_id           INTEGER REFERENCES sync_runs(id) ON DELETE SET NULL,
    UNIQUE (source_id, jira_id),
    UNIQUE (source_id, key)
) STRICT;

-- Status changes from the Jira changelog; feeds Baldur's activity timeline.
CREATE TABLE work_item_transitions (
    id            INTEGER PRIMARY KEY,
    work_item_id  INTEGER NOT NULL REFERENCES work_items(id) ON DELETE CASCADE,
    changelog_id  TEXT NOT NULL,                   -- Jira changelog history id
    at            TEXT NOT NULL CHECK (strftime('%Y-%m-%dT%H:%M:%SZ', at) IS at),
    from_status   TEXT,
    to_status     TEXT NOT NULL,
    to_category   TEXT NOT NULL CHECK (to_category IN ('todo','in_progress','done')),
    author        TEXT,
    by_me         INTEGER NOT NULL DEFAULT 0 CHECK (by_me IN (0,1)),
    UNIQUE (work_item_id, changelog_id)
) STRICT;

-- =====================================================================
-- Code and time (Baldur)
-- =====================================================================

CREATE TABLE repos (
    id               INTEGER PRIMARY KEY,
    source_id        INTEGER REFERENCES sources(id),   -- GitHub source when it has a remote there
    name             TEXT NOT NULL,                    -- 'owner/repo' or the folder name
    local_path       TEXT UNIQUE,                      -- NULL for remote-only repos
    remote_url       TEXT,
    default_branch   TEXT,
    active           INTEGER NOT NULL DEFAULT 1 CHECK (active IN (0,1)),
    last_scanned_at  TEXT CHECK (strftime('%Y-%m-%dT%H:%M:%SZ', last_scanned_at) IS last_scanned_at),
    created_at       TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now'))
                     CHECK (strftime('%Y-%m-%dT%H:%M:%SZ', created_at) IS created_at)
) STRICT;

-- Commit metadata only: no bodies, no diffs.
CREATE TABLE commits (
    id             INTEGER PRIMARY KEY,
    repo_id        INTEGER NOT NULL REFERENCES repos(id),
    sha            TEXT NOT NULL CHECK (length(sha) IN (40, 64)),   -- SHA-1 or SHA-256 repos
    author_name    TEXT NOT NULL,
    author_email   TEXT NOT NULL COLLATE NOCASE,
    authored_at    TEXT NOT NULL CHECK (strftime('%Y-%m-%dT%H:%M:%SZ', authored_at) IS authored_at),
    committed_at   TEXT NOT NULL CHECK (strftime('%Y-%m-%dT%H:%M:%SZ', committed_at) IS committed_at),
    subject        TEXT NOT NULL,
    files_changed  INTEGER NOT NULL DEFAULT 0 CHECK (files_changed >= 0),
    additions      INTEGER NOT NULL DEFAULT 0 CHECK (additions >= 0),
    deletions      INTEGER NOT NULL DEFAULT 0 CHECK (deletions >= 0),
    is_merge       INTEGER NOT NULL DEFAULT 0 CHECK (is_merge IN (0,1)),
    is_mine        INTEGER NOT NULL DEFAULT 0 CHECK (is_mine IN (0,1)),
    branch_hint    TEXT,
    first_seen_at  TEXT NOT NULL CHECK (strftime('%Y-%m-%dT%H:%M:%SZ', first_seen_at) IS first_seen_at),
    run_id         INTEGER REFERENCES sync_runs(id) ON DELETE SET NULL,
    UNIQUE (repo_id, sha)
) STRICT;

-- Which tickets a commit belongs to. work_item_key is kept even when the
-- issue is not synced (another team's ticket); work_item_id fills in later.
CREATE TABLE commit_work_items (
    commit_id      INTEGER NOT NULL REFERENCES commits(id) ON DELETE CASCADE,
    work_item_key  TEXT NOT NULL,
    work_item_id   INTEGER REFERENCES work_items(id),
    method         TEXT NOT NULL CHECK (method IN ('message','branch','fuzzy','llm','manual')),
    confidence     REAL NOT NULL CHECK (confidence BETWEEN 0 AND 1),
    PRIMARY KEY (commit_id, work_item_key)
) STRICT, WITHOUT ROWID;

-- Local reflog lines: activity evidence even when nothing was committed.
CREATE TABLE reflog_entries (
    id       INTEGER PRIMARY KEY,
    repo_id  INTEGER NOT NULL REFERENCES repos(id),
    at       TEXT NOT NULL CHECK (strftime('%Y-%m-%dT%H:%M:%SZ', at) IS at),
    action   TEXT NOT NULL,                        -- checkout, commit, rebase, reset, merge, pull
    sha      TEXT NOT NULL,
    message  TEXT,
    UNIQUE (repo_id, at, sha, action)
) STRICT;

CREATE TABLE pull_requests (
    id             INTEGER PRIMARY KEY,
    repo_id        INTEGER NOT NULL REFERENCES repos(id),
    number         INTEGER NOT NULL CHECK (number > 0),
    title          TEXT NOT NULL,
    author         TEXT NOT NULL,
    is_mine        INTEGER NOT NULL DEFAULT 0 CHECK (is_mine IN (0,1)),
    state          TEXT NOT NULL CHECK (state IN ('open','closed','merged')),
    created_at     TEXT NOT NULL CHECK (strftime('%Y-%m-%dT%H:%M:%SZ', created_at) IS created_at),
    updated_at     TEXT NOT NULL CHECK (strftime('%Y-%m-%dT%H:%M:%SZ', updated_at) IS updated_at),
    merged_at      TEXT CHECK (strftime('%Y-%m-%dT%H:%M:%SZ', merged_at) IS merged_at),
    closed_at      TEXT CHECK (strftime('%Y-%m-%dT%H:%M:%SZ', closed_at) IS closed_at),
    additions      INTEGER CHECK (additions >= 0),
    deletions      INTEGER CHECK (deletions >= 0),
    url            TEXT NOT NULL,
    first_seen_at  TEXT NOT NULL CHECK (strftime('%Y-%m-%dT%H:%M:%SZ', first_seen_at) IS first_seen_at),
    last_seen_at   TEXT NOT NULL CHECK (strftime('%Y-%m-%dT%H:%M:%SZ', last_seen_at) IS last_seen_at),
    run_id         INTEGER REFERENCES sync_runs(id) ON DELETE SET NULL,
    UNIQUE (repo_id, number),
    CHECK (state <> 'merged' OR merged_at IS NOT NULL)
) STRICT;

-- Reviews count as work: Baldur and Freya both read them.
CREATE TABLE pr_reviews (
    id             INTEGER PRIMARY KEY,
    pr_id          INTEGER NOT NULL REFERENCES pull_requests(id) ON DELETE CASCADE,
    github_id      TEXT NOT NULL,
    reviewer       TEXT NOT NULL,
    is_mine        INTEGER NOT NULL DEFAULT 0 CHECK (is_mine IN (0,1)),
    state          TEXT NOT NULL CHECK (state IN ('approved','changes_requested','commented','dismissed')),
    submitted_at   TEXT NOT NULL CHECK (strftime('%Y-%m-%dT%H:%M:%SZ', submitted_at) IS submitted_at),
    comment_count  INTEGER NOT NULL DEFAULT 0 CHECK (comment_count >= 0),
    UNIQUE (pr_id, github_id)
) STRICT;

-- Each calibration of the session heuristic; exactly one is active.
CREATE TABLE calibration_runs (
    id                  INTEGER PRIMARY KEY,
    created_at          TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now'))
                        CHECK (strftime('%Y-%m-%dT%H:%M:%SZ', created_at) IS created_at),
    gap_minutes         INTEGER NOT NULL CHECK (gap_minutes > 0),
    lead_in_minutes     INTEGER NOT NULL CHECK (lead_in_minutes >= 0),
    days_used           INTEGER NOT NULL CHECK (days_used > 0),
    mean_abs_error_min  REAL NOT NULL CHECK (mean_abs_error_min >= 0),   -- per day
    bias_min            REAL NOT NULL,                                   -- mean signed error per day
    is_active           INTEGER NOT NULL DEFAULT 0 CHECK (is_active IN (0,1))
) STRICT;

-- Baldur's estimated work sessions.
CREATE TABLE work_sessions (
    id                 INTEGER PRIMARY KEY,
    started_at         TEXT NOT NULL CHECK (strftime('%Y-%m-%dT%H:%M:%SZ', started_at) IS started_at),
    ended_at           TEXT NOT NULL CHECK (strftime('%Y-%m-%dT%H:%M:%SZ', ended_at) IS ended_at),
    estimated_minutes  INTEGER NOT NULL CHECK (estimated_minutes >= 0),
    confirmed_minutes  INTEGER CHECK (confirmed_minutes >= 0),
    status             TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','confirmed','edited','discarded')),
    calibration_id     INTEGER REFERENCES calibration_runs(id),
    signal_count       INTEGER NOT NULL DEFAULT 0 CHECK (signal_count >= 0),
    confidence         REAL CHECK (confidence BETWEEN 0 AND 1),
    created_at         TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now'))
                       CHECK (strftime('%Y-%m-%dT%H:%M:%SZ', created_at) IS created_at),
    CHECK (ended_at >= started_at),
    CHECK (status NOT IN ('confirmed','edited') OR confirmed_minutes IS NOT NULL)
) STRICT;

-- How a session's minutes split across tickets. Minutes left over are
-- "unlinked" (see v_session_unlinked); there is no sentinel row.
CREATE TABLE session_allocations (
    session_id     INTEGER NOT NULL REFERENCES work_sessions(id) ON DELETE CASCADE,
    work_item_key  TEXT NOT NULL,
    work_item_id   INTEGER REFERENCES work_items(id),
    minutes        INTEGER NOT NULL CHECK (minutes >= 0),
    method         TEXT NOT NULL CHECK (method IN ('commit_share','manual')),
    PRIMARY KEY (session_id, work_item_key)
) STRICT, WITHOUT ROWID;

-- Jira worklogs: pulled from Jira (origin 'jira') or drafted by Baldur.
CREATE TABLE worklogs (
    id               INTEGER PRIMARY KEY,
    work_item_id     INTEGER NOT NULL REFERENCES work_items(id),
    jira_worklog_id  TEXT,                          -- set once posted
    origin           TEXT NOT NULL CHECK (origin IN ('jira','baldur','manual')),
    state            TEXT NOT NULL CHECK (state IN ('draft','approved','posted','rejected')),
    started_at       TEXT NOT NULL CHECK (strftime('%Y-%m-%dT%H:%M:%SZ', started_at) IS started_at),
    seconds          INTEGER NOT NULL CHECK (seconds > 0),
    comment          TEXT,
    author           TEXT,
    session_id       INTEGER REFERENCES work_sessions(id) ON DELETE SET NULL,
    approved_at      TEXT CHECK (strftime('%Y-%m-%dT%H:%M:%SZ', approved_at) IS approved_at),
    posted_at        TEXT CHECK (strftime('%Y-%m-%dT%H:%M:%SZ', posted_at) IS posted_at),
    created_at       TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now'))
                     CHECK (strftime('%Y-%m-%dT%H:%M:%SZ', created_at) IS created_at),
    UNIQUE (work_item_id, jira_worklog_id),
    CHECK (state <> 'posted'   OR jira_worklog_id IS NOT NULL),
    CHECK (state <> 'approved' OR approved_at IS NOT NULL),
    CHECK (origin <> 'jira'    OR state = 'posted')
) STRICT;

-- Real hours you logged by hand; the ground truth for calibration.
CREATE TABLE time_actuals (
    id             INTEGER PRIMARY KEY,
    on_date        TEXT NOT NULL CHECK (date(on_date) IS on_date),
    minutes        INTEGER NOT NULL CHECK (minutes BETWEEN 0 AND 1440),
    work_item_key  TEXT,                            -- NULL = the whole day's total
    note           TEXT,
    created_at     TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now'))
                   CHECK (strftime('%Y-%m-%dT%H:%M:%SZ', created_at) IS created_at)
) STRICT;

-- =====================================================================
-- Meetings and BLUFs (Loki)
-- =====================================================================

-- Meeting metadata and Copilot's notes. Never full transcripts.
CREATE TABLE meetings (
    id              INTEGER PRIMARY KEY,
    source_id       INTEGER NOT NULL REFERENCES sources(id),
    external_id     TEXT NOT NULL,                  -- Graph meeting id, or a hash for pasted recaps
    title           TEXT NOT NULL,
    starts_at       TEXT NOT NULL CHECK (strftime('%Y-%m-%dT%H:%M:%SZ', starts_at) IS starts_at),
    ends_at         TEXT CHECK (strftime('%Y-%m-%dT%H:%M:%SZ', ends_at) IS ends_at),
    organizer       TEXT,
    attendee_count  INTEGER CHECK (attendee_count >= 0),
    recap_origin    TEXT NOT NULL CHECK (recap_origin IN ('graph_insights','graph_transcript','paste','file')),
    source_link     TEXT,                           -- recap or join link, for citation
    notes_summary   TEXT,                           -- Copilot notes or the pasted recap
    first_seen_at   TEXT NOT NULL CHECK (strftime('%Y-%m-%dT%H:%M:%SZ', first_seen_at) IS first_seen_at),
    run_id          INTEGER REFERENCES sync_runs(id) ON DELETE SET NULL,
    UNIQUE (source_id, external_id),
    CHECK (ends_at IS NULL OR ends_at >= starts_at)
) STRICT;

CREATE TABLE action_items (
    id             INTEGER PRIMARY KEY,
    meeting_id     INTEGER NOT NULL REFERENCES meetings(id) ON DELETE CASCADE,
    text           TEXT NOT NULL,
    owner          TEXT,
    is_mine        INTEGER NOT NULL DEFAULT 0 CHECK (is_mine IN (0,1)),
    due_on         TEXT CHECK (date(due_on) IS due_on),
    status         TEXT NOT NULL DEFAULT 'open' CHECK (status IN ('open','done','dropped')),
    work_item_key  TEXT,                            -- Jira issue created from it, if any
    created_at     TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now'))
                   CHECK (strftime('%Y-%m-%dT%H:%M:%SZ', created_at) IS created_at)
) STRICT;

CREATE TABLE blufs (
    id              INTEGER PRIMARY KEY,
    subject_type    TEXT NOT NULL CHECK (subject_type IN ('meeting','commit_range','pull_request','work_item','adhoc')),
    subject_ref     TEXT NOT NULL,                  -- meeting external_id, 'repo:sha1..sha2', PR URL, Jira key
    bottom_line     TEXT NOT NULL,                  -- the one-sentence BLUF
    body_md         TEXT NOT NULL,                  -- the full message as sent
    sections        TEXT NOT NULL DEFAULT '{}'      -- {"decisions":[],"actions":[],"risks":[],"asks":[]}
                    CHECK (json_valid(sections) AND json_type(sections) = 'object'),
    tier            TEXT NOT NULL CHECK (tier IN ('api','mcp','clipboard','manual')),
    model           TEXT,                           -- NULL for clipboard and manual
    prompt_version  TEXT NOT NULL,
    state           TEXT NOT NULL DEFAULT 'draft' CHECK (state IN ('draft','approved','posted','rejected')),
    sent_via        TEXT CHECK (sent_via IN ('clipboard','mailto','graph_mail','teams')),
    created_at      TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now'))
                    CHECK (strftime('%Y-%m-%dT%H:%M:%SZ', created_at) IS created_at),
    approved_at     TEXT CHECK (strftime('%Y-%m-%dT%H:%M:%SZ', approved_at) IS approved_at),
    posted_at       TEXT CHECK (strftime('%Y-%m-%dT%H:%M:%SZ', posted_at) IS posted_at),
    CHECK (state <> 'approved' OR approved_at IS NOT NULL),
    CHECK (state <> 'posted'   OR (posted_at IS NOT NULL AND sent_via IS NOT NULL))
) STRICT;

-- =====================================================================
-- Reviews (Freya) and citations (Freya, Loki)
-- =====================================================================

CREATE TABLE review_periods (
    id         INTEGER PRIMARY KEY,
    label      TEXT NOT NULL UNIQUE,               -- 'FY2026 annual'
    starts_on  TEXT NOT NULL CHECK (date(starts_on) IS starts_on),
    ends_on    TEXT NOT NULL CHECK (date(ends_on) IS ends_on),
    rubric     TEXT NOT NULL DEFAULT '[]'          -- [{"element":"...","standard":"..."}]
               CHECK (json_valid(rubric) AND json_type(rubric) = 'array'),
    CHECK (ends_on >= starts_on)
) STRICT;

CREATE TABLE review_drafts (
    id              INTEGER PRIMARY KEY,
    period_id       INTEGER NOT NULL REFERENCES review_periods(id),
    element         TEXT NOT NULL,                  -- performance element name from the rubric
    version         INTEGER NOT NULL DEFAULT 1 CHECK (version >= 1),
    text            TEXT NOT NULL,
    tier            TEXT NOT NULL CHECK (tier IN ('api','mcp','clipboard','manual')),
    model           TEXT,
    prompt_version  TEXT NOT NULL,
    status          TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','final','discarded')),
    created_at      TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now'))
                    CHECK (strftime('%Y-%m-%dT%H:%M:%SZ', created_at) IS created_at),
    UNIQUE (period_id, element, version)
) STRICT;

-- Every ID a generated text cites. verified = 1 only after the checker
-- resolved evidence_ref to a real row (evidence_id).
CREATE TABLE citations (
    id             INTEGER PRIMARY KEY,
    owner_type     TEXT NOT NULL CHECK (owner_type IN ('bluf','review_draft')),
    owner_id       INTEGER NOT NULL,
    evidence_type  TEXT NOT NULL CHECK (evidence_type IN ('work_item','commit','pull_request','meeting','bluf','work_session')),
    evidence_ref   TEXT NOT NULL,                   -- what the text cites: 'ABC-123', a SHA, a meeting id
    evidence_id    INTEGER,                         -- resolved row id; NULL until resolved
    verified       INTEGER NOT NULL DEFAULT 0 CHECK (verified IN (0,1)),
    UNIQUE (owner_type, owner_id, evidence_type, evidence_ref),
    CHECK (verified = 0 OR evidence_id IS NOT NULL)
) STRICT;

-- =====================================================================
-- Submissions (Heimdall, Bifrost)
-- =====================================================================

CREATE TABLE submissions (
    id                  INTEGER PRIMARY KEY,
    system              TEXT NOT NULL CHECK (system IN ('secchm','bears')),
    title               TEXT NOT NULL,
    state               TEXT NOT NULL DEFAULT 'draft'
                        CHECK (state IN ('draft','approved','submitted','in_review','accepted','returned','withdrawn')),
    external_id         TEXT,                       -- SeCcHm number, or Confluence page id for BEARs
    external_url        TEXT,
    fields              TEXT NOT NULL DEFAULT '{}'  -- the values filled in, by field name
                        CHECK (json_valid(fields) AND json_type(fields) = 'object'),
    artifact_path       TEXT,                       -- local .xlsx for BEARs
    attachment_id       TEXT,                       -- Confluence attachment id
    attachment_version  INTEGER CHECK (attachment_version >= 1),
    work_item_key       TEXT,                       -- related Jira issue, if any
    created_at          TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now'))
                        CHECK (strftime('%Y-%m-%dT%H:%M:%SZ', created_at) IS created_at),
    approved_at         TEXT CHECK (strftime('%Y-%m-%dT%H:%M:%SZ', approved_at) IS approved_at),
    submitted_at        TEXT CHECK (strftime('%Y-%m-%dT%H:%M:%SZ', submitted_at) IS submitted_at),
    last_polled_at      TEXT CHECK (strftime('%Y-%m-%dT%H:%M:%SZ', last_polled_at) IS last_polled_at),
    next_poll_at        TEXT CHECK (strftime('%Y-%m-%dT%H:%M:%SZ', next_poll_at) IS next_poll_at),
    last_status_raw     TEXT,                       -- status text exactly as the system shows it
    UNIQUE (system, external_id),
    CHECK (state = 'draft' OR approved_at IS NOT NULL),
    CHECK (state IN ('draft','approved','withdrawn') OR submitted_at IS NOT NULL)
) STRICT;

CREATE TABLE submission_status_history (
    id             INTEGER PRIMARY KEY,
    submission_id  INTEGER NOT NULL REFERENCES submissions(id) ON DELETE CASCADE,
    at             TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now'))
                   CHECK (strftime('%Y-%m-%dT%H:%M:%SZ', at) IS at),
    from_state     TEXT,
    to_state       TEXT NOT NULL,
    raw_status     TEXT
) STRICT;

-- History writes itself whenever state changes.
CREATE TRIGGER submissions_state_history AFTER UPDATE OF state ON submissions
WHEN old.state IS NOT new.state
BEGIN
    INSERT INTO submission_status_history (submission_id, from_state, to_state, raw_status)
    VALUES (new.id, old.state, new.state, new.last_status_raw);
END;

CREATE TRIGGER submissions_first_history AFTER INSERT ON submissions
BEGIN
    INSERT INTO submission_status_history (submission_id, from_state, to_state, raw_status)
    VALUES (new.id, NULL, new.state, new.last_status_raw);
END;

-- =====================================================================
-- Search: one FTS5 index across entity types
--   rowid = entity_id * 16 + type code
--   1 work_items  2 commits  3 pull_requests  4 meetings
--   5 action_items  6 blufs  7 submissions
--   entity_id = rowid >> 4, type code = rowid & 15
-- =====================================================================

CREATE VIRTUAL TABLE search USING fts5(
    title,
    body,
    kind UNINDEXED,
    tokenize = 'porter unicode61'
);

CREATE TRIGGER work_items_search_ins AFTER INSERT ON work_items BEGIN
    INSERT INTO search (rowid, title, body, kind)
    VALUES (new.id * 16 + 1, new.key || ' ' || new.summary,
            coalesce(new.epic_key, '') || ' ' || new.issue_type || ' ' || new.labels || ' ' || new.components, 'work_items');
END;
CREATE TRIGGER work_items_search_upd AFTER UPDATE OF key, summary, epic_key, issue_type, labels, components ON work_items BEGIN
    UPDATE search SET title = new.key || ' ' || new.summary,
                      body = coalesce(new.epic_key, '') || ' ' || new.issue_type || ' ' || new.labels || ' ' || new.components
    WHERE rowid = new.id * 16 + 1;
END;
CREATE TRIGGER work_items_search_del AFTER DELETE ON work_items BEGIN
    DELETE FROM search WHERE rowid = old.id * 16 + 1;
END;

CREATE TRIGGER commits_search_ins AFTER INSERT ON commits BEGIN
    INSERT INTO search (rowid, title, body, kind)
    VALUES (new.id * 16 + 2, new.subject, substr(new.sha, 1, 12) || ' ' || coalesce(new.branch_hint, ''), 'commits');
END;
CREATE TRIGGER commits_search_upd AFTER UPDATE OF subject, branch_hint ON commits BEGIN
    UPDATE search SET title = new.subject, body = substr(new.sha, 1, 12) || ' ' || coalesce(new.branch_hint, '')
    WHERE rowid = new.id * 16 + 2;
END;
CREATE TRIGGER commits_search_del AFTER DELETE ON commits BEGIN
    DELETE FROM search WHERE rowid = old.id * 16 + 2;
END;

CREATE TRIGGER pull_requests_search_ins AFTER INSERT ON pull_requests BEGIN
    INSERT INTO search (rowid, title, body, kind)
    VALUES (new.id * 16 + 3, new.title, '#' || new.number || ' ' || new.author, 'pull_requests');
END;
CREATE TRIGGER pull_requests_search_upd AFTER UPDATE OF title ON pull_requests BEGIN
    UPDATE search SET title = new.title WHERE rowid = new.id * 16 + 3;
END;
CREATE TRIGGER pull_requests_search_del AFTER DELETE ON pull_requests BEGIN
    DELETE FROM search WHERE rowid = old.id * 16 + 3;
END;

CREATE TRIGGER meetings_search_ins AFTER INSERT ON meetings BEGIN
    INSERT INTO search (rowid, title, body, kind)
    VALUES (new.id * 16 + 4, new.title, coalesce(new.notes_summary, ''), 'meetings');
END;
CREATE TRIGGER meetings_search_upd AFTER UPDATE OF title, notes_summary ON meetings BEGIN
    UPDATE search SET title = new.title, body = coalesce(new.notes_summary, '')
    WHERE rowid = new.id * 16 + 4;
END;
CREATE TRIGGER meetings_search_del AFTER DELETE ON meetings BEGIN
    DELETE FROM search WHERE rowid = old.id * 16 + 4;
END;

CREATE TRIGGER action_items_search_ins AFTER INSERT ON action_items BEGIN
    INSERT INTO search (rowid, title, body, kind)
    VALUES (new.id * 16 + 5, new.text, coalesce(new.owner, '') || ' ' || coalesce(new.work_item_key, ''), 'action_items');
END;
CREATE TRIGGER action_items_search_upd AFTER UPDATE OF text, owner, work_item_key ON action_items BEGIN
    UPDATE search SET title = new.text, body = coalesce(new.owner, '') || ' ' || coalesce(new.work_item_key, '')
    WHERE rowid = new.id * 16 + 5;
END;
CREATE TRIGGER action_items_search_del AFTER DELETE ON action_items BEGIN
    DELETE FROM search WHERE rowid = old.id * 16 + 5;
END;

CREATE TRIGGER blufs_search_ins AFTER INSERT ON blufs BEGIN
    INSERT INTO search (rowid, title, body, kind)
    VALUES (new.id * 16 + 6, new.bottom_line, new.body_md, 'blufs');
END;
CREATE TRIGGER blufs_search_upd AFTER UPDATE OF bottom_line, body_md ON blufs BEGIN
    UPDATE search SET title = new.bottom_line, body = new.body_md WHERE rowid = new.id * 16 + 6;
END;
CREATE TRIGGER blufs_search_del AFTER DELETE ON blufs BEGIN
    DELETE FROM search WHERE rowid = old.id * 16 + 6;
END;

CREATE TRIGGER submissions_search_ins AFTER INSERT ON submissions BEGIN
    INSERT INTO search (rowid, title, body, kind)
    VALUES (new.id * 16 + 7, new.title, new.system || ' ' || coalesce(new.external_id, '') || ' ' || coalesce(new.work_item_key, ''), 'submissions');
END;
CREATE TRIGGER submissions_search_upd AFTER UPDATE OF title, external_id, work_item_key ON submissions BEGIN
    UPDATE search SET title = new.title,
                      body = new.system || ' ' || coalesce(new.external_id, '') || ' ' || coalesce(new.work_item_key, '')
    WHERE rowid = new.id * 16 + 7;
END;
CREATE TRIGGER submissions_search_del AFTER DELETE ON submissions BEGIN
    DELETE FROM search WHERE rowid = old.id * 16 + 7;
END;

-- =====================================================================
-- Views
-- =====================================================================

-- Everything you did, in time order: Baldur's input for session building.
CREATE VIEW v_activity AS
    SELECT c.authored_at AS at, 'commit' AS kind, c.repo_id, c.id AS ref_id, c.subject AS label
      FROM commits c WHERE c.is_mine = 1
    UNION ALL
    SELECT r.at, 'reflog', r.repo_id, r.id, r.action
      FROM reflog_entries r
    UNION ALL
    SELECT v.submitted_at, 'pr_review', p.repo_id, v.id, p.title
      FROM pr_reviews v JOIN pull_requests p ON p.id = v.pr_id WHERE v.is_mine = 1
    UNION ALL
    SELECT t.at, 'transition', NULL, t.id, w.key || ' -> ' || t.to_status
      FROM work_item_transitions t JOIN work_items w ON w.id = t.work_item_id WHERE t.by_me = 1
    UNION ALL
    SELECT m.starts_at, 'meeting', NULL, m.id, m.title
      FROM meetings m;

-- Minutes in a session not yet tied to any ticket.
CREATE VIEW v_session_unlinked AS
    SELECT s.id AS session_id, s.started_at,
           coalesce(s.confirmed_minutes, s.estimated_minutes) - coalesce(sum(a.minutes), 0) AS unlinked_minutes
      FROM work_sessions s LEFT JOIN session_allocations a ON a.session_id = s.id
     WHERE s.status <> 'discarded'
     GROUP BY s.id;

-- Confirmed time per ticket per month: Freya's "where the hours went".
CREATE VIEW v_time_by_item_month AS
    SELECT substr(s.started_at, 1, 7) AS month, a.work_item_key, sum(a.minutes) AS minutes
      FROM session_allocations a JOIN work_sessions s ON s.id = a.session_id
     WHERE s.status IN ('confirmed','edited')
     GROUP BY 1, 2;

-- Everything Freya may cite for a review period.
CREATE VIEW v_review_evidence AS
    SELECT p.id AS period_id, 'work_item' AS evidence_type, w.key AS evidence_ref,
           w.summary AS label, w.resolved_at AS at
      FROM review_periods p
      JOIN work_items w ON w.is_mine = 1 AND w.deleted_at IS NULL
                       AND w.resolved_at BETWEEN p.starts_on AND p.ends_on || 'T23:59:59Z'
    UNION ALL
    SELECT p.id, 'pull_request', r.name || '#' || pr.number, pr.title, pr.merged_at
      FROM review_periods p
      JOIN pull_requests pr ON pr.is_mine = 1
                           AND pr.merged_at BETWEEN p.starts_on AND p.ends_on || 'T23:59:59Z'
      JOIN repos r ON r.id = pr.repo_id
    UNION ALL
    SELECT p.id, 'bluf', b.subject_ref, b.bottom_line, b.posted_at
      FROM review_periods p
      JOIN blufs b ON b.state = 'posted'
                  AND b.posted_at BETWEEN p.starts_on AND p.ends_on || 'T23:59:59Z';

-- Citations the checker could not resolve: block publishing while any exist.
CREATE VIEW v_unverified_citations AS
    SELECT * FROM citations WHERE verified = 0;

-- =====================================================================
-- Indexes (UNIQUE constraints above already index their columns)
-- =====================================================================

CREATE INDEX ix_events_at               ON events (at);
CREATE INDEX ix_events_entity           ON events (entity_type, entity_id);
CREATE INDEX ix_events_kind_at          ON events (kind, at);
CREATE INDEX ix_sync_runs_app_started   ON sync_runs (app, started_at);

CREATE INDEX ix_work_items_mine_resolved ON work_items (resolved_at) WHERE is_mine = 1;
CREATE INDEX ix_work_items_open_mine     ON work_items (status_category, updated_at) WHERE is_mine = 1 AND deleted_at IS NULL;
CREATE INDEX ix_work_items_updated       ON work_items (source_id, updated_at);
CREATE INDEX ix_work_items_epic          ON work_items (epic_key) WHERE epic_key IS NOT NULL;
CREATE INDEX ix_work_items_last_seen     ON work_items (source_id, last_seen_at) WHERE deleted_at IS NULL;
CREATE INDEX ix_transitions_mine_at      ON work_item_transitions (at) WHERE by_me = 1;

CREATE INDEX ix_commits_mine_authored    ON commits (authored_at) WHERE is_mine = 1;
CREATE INDEX ix_commits_repo_authored    ON commits (repo_id, authored_at);
CREATE INDEX ix_commit_items_key         ON commit_work_items (work_item_key);
CREATE INDEX ix_reflog_at                ON reflog_entries (at);
CREATE INDEX ix_prs_mine_merged          ON pull_requests (merged_at) WHERE is_mine = 1;
CREATE INDEX ix_pr_reviews_mine_at       ON pr_reviews (submitted_at) WHERE is_mine = 1;

CREATE UNIQUE INDEX ux_calibration_active ON calibration_runs (is_active) WHERE is_active = 1;
CREATE INDEX ix_sessions_started         ON work_sessions (started_at);
CREATE INDEX ix_allocations_key          ON session_allocations (work_item_key);
CREATE INDEX ix_worklogs_item_started    ON worklogs (work_item_id, started_at);
CREATE INDEX ix_worklogs_pending         ON worklogs (state, created_at) WHERE state IN ('draft','approved');
CREATE UNIQUE INDEX ux_time_actuals_day_item ON time_actuals (on_date, coalesce(work_item_key, ''));

CREATE INDEX ix_meetings_starts          ON meetings (starts_at);
CREATE INDEX ix_action_items_open        ON action_items (due_on) WHERE status = 'open';
CREATE INDEX ix_blufs_subject            ON blufs (subject_type, subject_ref);
CREATE INDEX ix_blufs_posted             ON blufs (posted_at) WHERE state = 'posted';

CREATE INDEX ix_citations_evidence       ON citations (evidence_type, evidence_ref);
CREATE INDEX ix_citations_unverified     ON citations (owner_type, owner_id) WHERE verified = 0;
CREATE INDEX ix_submissions_poll         ON submissions (next_poll_at) WHERE state IN ('submitted','in_review');
CREATE INDEX ix_submission_history       ON submission_status_history (submission_id, at);

PRAGMA user_version = 1;

COMMIT;
