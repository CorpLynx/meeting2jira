"""Exceptions. Every message must say what to DO, not merely what went wrong.

That is the convention the rest of this project already follows (ConfigError, JiraError,
CredentialError): a failure that only names the symptom sends someone reading logs on a locked-down
machine with nothing to act on.
"""
from __future__ import annotations


class MuninnError(Exception):
    """Base class, so a caller can catch everything Muninn raises deliberately."""


class PreflightError(MuninnError):
    """This Python's SQLite cannot run Muninn. Raised before any file is created or touched."""


class MigrationError(MuninnError):
    """A schema migration could not be applied, or the database is newer than this code."""


class OwnershipError(MuninnError):
    """An app tried to write a table it does not own (rule 5)."""


class RuleViolation(MuninnError):
    """A write would break one of the eight rules, or a database constraint that enforces one.

    Also raised for malformed input (a timestamp that is not a timestamp, a missing required field),
    because a bad value is better refused at the edge than discovered later as a wrong number.
    """


class SyncError(MuninnError):
    """A sync run cannot proceed or cannot safely finish (for example a suspicious mass deletion)."""
