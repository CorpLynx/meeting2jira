"""The Muninn connection: transactions, events, provenance, search and housekeeping.

One Muninn instance = one SQLite connection = one thread. sqlite3 enforces the thread rule for us
(a connection used from another thread raises), and the design wants `BEGIN IMMEDIATE` ownership of
the write lock, which only makes sense per connection. An app that works on several threads opens one
per thread; they coordinate through SQLite's own locking (WAL, 5 s busy timeout).

Writes go through three layers and this file is the bottom one:

    OdinApi / BaldurApi   what each app may do, with ownership checked (odin.py, baldur.py)
    Run                   a sync run: provenance, cursor, sweep (run.py)
    Muninn                transactions, events, identities (here)
"""
from __future__ import annotations

import json
import logging
import re
import sqlite3
from contextlib import contextmanager
from datetime import timedelta
from pathlib import Path
from typing import Any, Dict, Iterator, List, Optional, Sequence

from . import db as dbmod
from .errors import MuninnError, OwnershipError, RuleViolation
from .ownership import APPS, INFRASTRUCTURE, is_known_table
from .redact import assert_clean, check_size
from .timeutil import TS_FORMAT, Clock, days_before, now_text, parse_ts

log = logging.getLogger(__name__)

_EVENT_KIND = re.compile(r"^[a-z][a-z_]*\.[a-z][a-z_]*$")
_IDENTITY_KINDS = ("git_email", "git_name", "jira_user", "github_login", "m365_upn", "display_name")
_SOURCE_KINDS = ("jira", "confluence", "git", "github", "teams", "secchm", "manual")
STALE_RUN_HOURS = 6


def fts_query(text: str) -> str:
    """Turn what a person typed into a safe FTS5 query.

    Raw text is not safe to hand to MATCH. `ABC-123` is parsed as "ABC minus 123" and fails with
    "no such column: 123"; an unbalanced quote is a syntax error; `AND`, `NEAR` and `*` are
    operators. Every whitespace-separated word is therefore quoted as a phrase (which also makes
    `ABC-123` match the tokens ABC and 123 next to each other), and a trailing `*` is kept as a
    prefix match so typing `retr*` finds "retry".
    """
    terms: List[str] = []
    for raw in re.findall(r"\S+", (text or "").replace("\x00", " ")):
        prefix = raw.endswith("*")
        word = raw.strip("*").replace('"', "")
        if word:
            terms.append('"{}"{}'.format(word, "*" if prefix else ""))
    return " ".join(terms)


class Muninn:
    def __init__(self, conn: sqlite3.Connection, app: str, path: Optional[Path] = None,
                 clock: Optional[Clock] = None, read_only: bool = False):
        if app not in APPS:
            raise RuleViolation("Unknown app {!r}. Known apps: {}.".format(app, ", ".join(APPS)))
        self.conn = conn
        self.app = app
        self.path = Path(path) if path else None
        self.read_only = read_only
        self._clock = clock
        self._depth = 0
        self._savepoints = 0
        self._identity_cache: Optional[Dict[str, frozenset]] = None
        self._active_run: Any = None
        self._odin: Any = None
        self._baldur: Any = None

    # -- lifecycle ---------------------------------------------------------------------------
    def close(self) -> None:
        if self.conn is not None:
            if self.conn.in_transaction:
                self._rollback()
            self.conn.close()
            self.conn = None  # type: ignore[assignment]

    def __enter__(self) -> "Muninn":
        return self

    def __exit__(self, *exc: Any) -> None:
        self.close()

    def now(self) -> str:
        return now_text(self._clock)

    def _require_writable(self) -> None:
        if self.read_only:
            raise RuleViolation("This Muninn handle is read-only. Open it with a writing app to "
                                "make changes.")

    # -- transactions ------------------------------------------------------------------------
    def _begin(self) -> None:
        self.conn.execute("BEGIN IMMEDIATE")      # take the write lock now, not halfway through
        self._depth = 1

    def _commit(self) -> None:
        try:
            self.conn.execute("COMMIT")
        except sqlite3.Error:
            self._rollback()
            raise
        self._depth = 0

    def _rollback(self) -> None:
        try:
            if self.conn.in_transaction:
                self.conn.execute("ROLLBACK")
        finally:
            self._depth = 0
            self._savepoints = 0

    @contextmanager
    def transaction(self) -> Iterator[None]:
        """The outermost use is a real transaction; nested uses are savepoints.

        Nesting matters because one logical operation (approve a proposal) calls helpers that each
        want to be atomic. A savepoint lets the inner one fail and roll back alone, while the whole
        still commits or rolls back as a unit.
        """
        self._require_writable()
        if self._depth == 0:
            self._begin()
            try:
                yield
            except BaseException:
                self._rollback()
                raise
            self._commit()
        else:
            self._savepoints += 1
            name = "sp{}".format(self._savepoints)
            self.conn.execute("SAVEPOINT " + name)
            try:
                yield
            except BaseException:
                self.conn.execute("ROLLBACK TO " + name)
                self.conn.execute("RELEASE " + name)
                raise
            self.conn.execute("RELEASE " + name)

    def _scalar(self, sql: str, params: Sequence[Any] = ()) -> Any:
        row = self.conn.execute(sql, tuple(params)).fetchone()
        return None if row is None else row[0]

    # -- events ------------------------------------------------------------------------------
    def emit(self, kind: str, entity_type: str, entity_id: Optional[int] = None,
             ref: Optional[str] = None, payload: Optional[Dict[str, Any]] = None,
             run_id: Optional[int] = None) -> int:
        """Append one event (rule 6). Events are never updated or deleted; a trigger forbids it.

        The payload is screened for credentials (rule 8) and size-capped before it is written,
        because an event can never be corrected afterwards.
        """
        self._require_writable()
        if not _EVENT_KIND.match(kind):
            raise RuleViolation("Event kind {!r} must look like noun.verb, e.g. work_item.updated."
                                .format(kind))
        if not is_known_table(entity_type) and entity_type not in INFRASTRUCTURE:
            raise RuleViolation("Event entity_type {!r} is not a Muninn table.".format(entity_type))
        body = payload or {}
        if not isinstance(body, dict):
            raise RuleViolation("An event payload must be a JSON object.")
        assert_clean(body, "event payload")
        text = json.dumps(body, ensure_ascii=False, sort_keys=True, separators=(",", ":"),
                          default=str)
        check_size(text, "event payload")
        if run_id is None and self._active_run is not None:
            run_id = self._active_run.id
        cursor = self.conn.execute(
            "INSERT INTO events (at, app, kind, entity_type, entity_id, ref, run_id, payload) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            (self.now(), self.app, kind, entity_type, entity_id, ref, run_id, text))
        return int(cursor.lastrowid)

    def events_since(self, at: str, kinds: Optional[Sequence[str]] = None,
                     limit: int = 1000) -> List[Dict[str, Any]]:
        """What changed after `at` (exclusive), oldest first. Ysildir's question."""
        sql = "SELECT id, at, app, kind, entity_type, entity_id, ref, run_id, payload FROM events WHERE at > ?"
        params: List[Any] = [parse_ts(at).strftime(TS_FORMAT)]
        if kinds:
            sql += " AND kind IN ({})".format(",".join("?" * len(kinds)))
            params.extend(kinds)
        sql += " ORDER BY id LIMIT ?"
        params.append(int(limit))
        out = []
        for row in self.conn.execute(sql, params):
            item = dict(row)
            item["payload"] = json.loads(item["payload"])
            out.append(item)
        return out

    # -- provenance: sources, identities, meta ------------------------------------------------
    def ensure_source(self, name: str, kind: str, base_url: Optional[str] = None) -> int:
        """Register an external system once. Idempotent; a changed kind is an error, not a rewrite."""
        self._require_writable()
        if kind not in _SOURCE_KINDS:
            raise RuleViolation("Source kind {!r} must be one of: {}.".format(kind, ", ".join(_SOURCE_KINDS)))
        with self.transaction():
            row = self.conn.execute("SELECT id, kind FROM sources WHERE name = ?", (name,)).fetchone()
            if row is not None:
                if row["kind"] != kind:
                    raise RuleViolation("Source {!r} is already registered as {!r}, not {!r}.".format(
                        name, row["kind"], kind))
                return int(row["id"])
            if base_url is not None and not re.match(r"^https?://", base_url):
                raise RuleViolation("base_url {!r} must start with http:// or https://.".format(base_url))
            cursor = self.conn.execute(
                "INSERT INTO sources (kind, name, base_url, created_at) VALUES (?, ?, ?, ?)",
                (kind, name, base_url, self.now()))
            self.emit("source.added", "sources", int(cursor.lastrowid), ref=name, payload={"kind": kind})
            return int(cursor.lastrowid)

    def source_id(self, name: str) -> int:
        value = self._scalar("SELECT id FROM sources WHERE name = ?", (name,))
        if value is None:
            raise RuleViolation("No source named {!r}. Register it first with ensure_source(name, "
                                "kind).".format(name))
        return int(value)

    def add_identity(self, kind: str, value: str, source: Optional[str] = None) -> bool:
        """Record one of your accounts. Every is_mine flag is derived from these. Returns True if new.

        Only ever raises ownership flags going forward; use the owning app's recompute_ownership()
        to apply a newly added identity to rows already written.
        """
        self._require_writable()
        if kind not in _IDENTITY_KINDS:
            raise RuleViolation("Identity kind {!r} must be one of: {}.".format(kind, ", ".join(_IDENTITY_KINDS)))
        value = (value or "").strip()
        if not value:
            raise RuleViolation("An identity value cannot be empty.")
        source_id = self.source_id(source) if source else None
        with self.transaction():
            cursor = self.conn.execute(
                "INSERT OR IGNORE INTO identities (kind, value, source_id) VALUES (?, ?, ?)",
                (kind, value, source_id))
            created = cursor.rowcount == 1
            if created:
                self.emit("identity.added", "identities", int(cursor.lastrowid), payload={"kind": kind})
        self._identity_cache = None
        return created

    def identity_values(self, kind: str) -> frozenset:
        """Lower-cased values for one identity kind, cached until an identity is added."""
        if self._identity_cache is None:
            cache: Dict[str, set] = {}
            for row in self.conn.execute("SELECT kind, value FROM identities"):
                cache.setdefault(row["kind"], set()).add(row["value"].lower())
            self._identity_cache = {k: frozenset(v) for k, v in cache.items()}
        return self._identity_cache.get(kind, frozenset())

    def is_me(self, kind: str, value: Optional[str]) -> int:
        return 1 if value and value.strip().lower() in self.identity_values(kind) else 0

    def meta_get(self, key: str, default: Optional[str] = None) -> Optional[str]:
        value = self._scalar("SELECT value FROM meta WHERE key = ?", (key,))
        return default if value is None else str(value)

    def meta_set(self, key: str, value: str) -> None:
        if self.app not in ("muninn", "valkyrie"):
            raise OwnershipError("`{}` may not write `meta`: only muninn and valkyrie do.".format(self.app))
        self._require_writable()
        self.conn.execute("INSERT INTO meta (key, value) VALUES (?, ?) "
                          "ON CONFLICT (key) DO UPDATE SET value = excluded.value", (key, value))

    # -- search ------------------------------------------------------------------------------
    def search(self, query: str, kinds: Optional[Sequence[str]] = None,
               limit: int = 20) -> List[Dict[str, Any]]:
        """Full-text search across every entity type, best match first."""
        match = fts_query(query)
        if not match:
            return []
        sql = "SELECT rowid, kind, title, bm25(search) AS rank FROM search WHERE search MATCH ?"
        params: List[Any] = [match]
        if kinds:
            sql += " AND kind IN ({})".format(",".join("?" * len(kinds)))
            params.extend(kinds)
        sql += " ORDER BY rank LIMIT ?"
        params.append(int(limit))
        try:
            rows = self.conn.execute(sql, params).fetchall()
        except sqlite3.OperationalError as exc:
            # A query made only of punctuation quotes to a phrase with no tokens. That is "nothing
            # matches", not a failure worth showing a person.
            log.debug("search %r matched nothing (%s)", query, exc)
            return []
        return [{"kind": r["kind"], "entity_id": r["rowid"] >> 4, "type_code": r["rowid"] & 15,
                 "title": r["title"], "rank": r["rank"]} for r in rows]

    # -- housekeeping ------------------------------------------------------------------------
    def reap_stale_runs(self, older_than_hours: int = STALE_RUN_HOURS) -> int:
        """Close runs left 'running' by a process that died. A crash rolled their data back, so the
        only thing left wrong is the run row claiming to still be going."""
        if self.read_only:
            return 0
        cutoff = (parse_ts(self.now()) - timedelta(hours=older_than_hours)).strftime(TS_FORMAT)
        cursor = self.conn.execute(
            "UPDATE sync_runs SET status = 'failed', finished_at = ?, "
            "error = 'interrupted: the process ended before the run finished' "
            "WHERE status = 'running' AND started_at < ?", (self.now(), cutoff))
        return cursor.rowcount

    def prune(self, run_days: int = 180, reflog_days: int = 365) -> Dict[str, int]:
        """Retention (design): sync_runs 180 days, reflog 1 year. Facts and events are kept forever.

        Deleting a sync run does not delete anything it produced: every fact's run_id is a
        foreign key with ON DELETE SET NULL, and events deliberately have no foreign key at all.
        """
        if self.app != "muninn":
            raise OwnershipError("Only the `muninn` app runs retention. Open with app='muninn'.")
        now = self.now()
        with self.transaction():
            runs = self.conn.execute(
                "DELETE FROM sync_runs WHERE status <> 'running' AND started_at < ?",
                (days_before(now, run_days),)).rowcount
            reflog = self.conn.execute(
                "DELETE FROM reflog_entries WHERE at < ?", (days_before(now, reflog_days),)).rowcount
            self.emit("maintenance.pruned", "sync_runs", payload={"sync_runs": runs, "reflog_entries": reflog})
        return {"sync_runs": runs, "reflog_entries": reflog}

    def integrity_check(self) -> List[str]:
        """Empty list means healthy."""
        problems = [r[0] for r in self.conn.execute("PRAGMA integrity_check") if r[0] != "ok"]
        problems += ["foreign key violation in {} (row {})".format(r[0], r[1])
                     for r in self.conn.execute("PRAGMA foreign_key_check")]
        return problems

    def backup_now(self, label: str = "manual") -> Path:
        if self.path is None:
            raise MuninnError("This handle has no file path to back up.")
        if self._depth:
            raise MuninnError("Finish the current transaction before backing up.")
        name = "muninn-{}-{}.db".format(now_text(self._clock).replace("-", "").replace(":", "")[:15], label)
        return dbmod.backup(self.conn, dbmod.backups_dir(self.path), name)

    def stats(self) -> Dict[str, Any]:
        tables = [r[0] for r in self.conn.execute(
            "SELECT name FROM sqlite_master WHERE type = 'table' AND name NOT LIKE 'sqlite_%' "
            "AND name NOT LIKE 'search%' ORDER BY name")]
        counts = {t: self._scalar('SELECT count(*) FROM "{}"'.format(t)) for t in tables}
        size = self.path.stat().st_size if self.path and self.path.exists() else None
        return {"schema_version": dbmod.schema_version(self.conn), "sqlite": sqlite3.sqlite_version,
                "bytes": size, "rows": counts}

    # -- entry points ------------------------------------------------------------------------
    def run(self, source: str, stream: str, mode: str = "incremental", kind: Optional[str] = None,
            base_url: Optional[str] = None, advance_cursor_on_partial: bool = False) -> Any:
        from .run import Run
        source_id = self._scalar("SELECT id FROM sources WHERE name = ?", (source,))
        if source_id is None:
            if kind is None:
                raise RuleViolation("No source named {!r}. Register it with ensure_source(), or pass "
                                    "kind= to create it here.".format(source))
            source_id = self.ensure_source(source, kind, base_url)
        return Run(self, int(source_id), stream, mode, advance_cursor_on_partial)

    @property
    def odin(self) -> Any:
        from .odin import OdinApi
        if self._odin is None:
            self._odin = OdinApi(self)
        return self._odin

    @property
    def baldur(self) -> Any:
        from .baldur import BaldurApi
        if self._baldur is None:
            self._baldur = BaldurApi(self)
        return self._baldur


def open_db(app: str, path: Optional[Path] = None, clock: Optional[Clock] = None,
            read_only: bool = False, busy_timeout_ms: int = 5000) -> Muninn:
    """Open (creating and migrating if needed) the Muninn database as `app`.

    Order matters: preflight first, so an unsupported Python fails before any file exists; then
    migrate (which backs up an existing database first); then the once-a-day backup.
    """
    if app not in APPS:
        raise RuleViolation("Unknown app {!r}. Known apps: {}.".format(app, ", ".join(APPS)))
    dbmod.require_preflight()
    target = Path(path) if path else dbmod.db_path()
    conn = dbmod.connect(target, read_only=read_only, busy_timeout_ms=busy_timeout_ms)
    try:
        if read_only:
            if dbmod.schema_version(conn) < 1:
                raise MuninnError("{} is not an initialised Muninn database.".format(target))
            return Muninn(conn, app, target, clock, read_only=True)

        existed = dbmod.schema_version(conn) > 0
        stamp = now_text(clock)[:10].replace("-", "")
        dbmod.migrate(conn, target, backup_to=dbmod.backups_dir(target), stamp=stamp)
        muninn = Muninn(conn, app, target, clock)
        if not existed:
            conn.execute("INSERT OR IGNORE INTO meta (key, value) VALUES ('created_at', ?)", (muninn.now(),))
        else:
            try:
                dbmod.daily_backup(conn, dbmod.backups_dir(target), stamp)
            except (OSError, sqlite3.Error, MuninnError) as exc:
                log.warning("Daily backup skipped: %s", exc)
        muninn.reap_stale_runs()
        return muninn
    except BaseException:
        conn.close()
        raise
