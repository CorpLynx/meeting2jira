"""Baldur's estimate-and-approval workflow: runs, sessions, day proposals, actuals, worklogs.

This is where rule 7 (people approve anything that leaves Asgard) is enforced in code, on top of the
constraints the schema and migration 0003 enforce in the database:

    estimate -> proposed -> APPROVED by a person -> worklog drafted -> worklog approved -> posted

Two guards here are deliberately crude, and worth being clear-eyed about:

  `confirmed_by` must name a person, and may not be an app. It stops Baldur approving its own
  proposals by accident. It is a tripwire, NOT a security boundary: the string is supplied by the
  caller, and anything that can call this module can also write SQL. The real guarantee is that the
  UI's confirm button is the only code path that passes a person's name.

  Nothing here talks to Jira. Muninn is the data layer; "posted" means a separate poster module
  already made the call and is recording the result (`mark_worklog_posted`).

Delta logging (the Baldur spec's "approve 2h, re-estimate 2h30m, offer only 30m")
    A worklog is only ever drafted for the DIFFERENCE between what a person approved for a day and
    what has already been posted or is already pending. A lower re-estimate yields nothing: posted
    worklogs are never retracted, the gap is reported by `day_delta`, and a human decides.
"""
from __future__ import annotations

import hashlib
import json
from typing import Any, Dict, List, Mapping, Optional, Sequence

from .common import (CREATED, UNCHANGED, UPDATED, UpsertResult, choice, jira_key,
                     non_negative_int)
from .errors import RuleViolation
from .ownership import APPS
from .redact import assert_clean, check_size, scrub_text
from .timeutil import to_date, to_ts

POLICIES = ("ambient", "overlap", "independent")
_BASIS_LIMIT = 4000


def _hash(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()[:16]


def _person(confirmed_by: Any) -> str:
    """Approval must come from a person. See the module note on what this does and does not do."""
    name = str(confirmed_by or "").strip()
    if not name:
        raise RuleViolation("Approving needs `confirmed_by`: the name of the person who confirmed "
                            "it in the UI. Rule 7: only a person's confirm action approves.")
    if name.lower() in APPS:
        raise RuleViolation("`{}` is an app, not a person. Rule 7: approval comes from a person's "
                            "confirm action, never from the app itself.".format(name))
    return name


class EstimateMixin:
    """Mixed into BaldurApi, which supplies `self.m` and `self._require` (from BaseApi).

    Deliberately declares neither: a stub `_require` here would win over BaseApi's in the method
    resolution order and silently switch the ownership check off.
    """

    # -- runs and sessions -------------------------------------------------------------------
    def create_estimate_run(self, date_from: str, date_to: str, model_version: str,
                            params: Mapping[str, Any], calibration_id: Optional[int] = None) -> int:
        """Freeze the settings an estimate used. Changing a default later never changes past numbers."""
        self._require("estimate_runs")
        m = self.m
        frm, to = to_date(date_from), to_date(date_to)
        if to < frm:
            raise RuleViolation("date_to {} is before date_from {}.".format(to, frm))
        body = json.dumps(dict(params), sort_keys=True, separators=(",", ":"), default=str)
        assert_clean(dict(params), "estimate params")
        check_size(body, "estimate params")
        with m.transaction():
            cursor = m.conn.execute(
                "INSERT INTO estimate_runs (created_at, date_from, date_to, model_version, params, "
                "params_hash, calibration_id) VALUES (?, ?, ?, ?, ?, ?, ?)",
                (m.now(), frm, to, model_version, body, _hash(body), calibration_id))
            run_id = int(cursor.lastrowid)
            m.emit("estimate_run.created", "estimate_runs", run_id,
                   payload={"from": frm, "to": to, "params_hash": _hash(body)})
        return run_id

    def add_session(self, estimate_run_id: int, started_at: str, ended_at: str,
                    estimated_minutes: int, local_date: str, policy: str,
                    focused_minutes: Optional[float] = None, ambient_minutes: Optional[float] = None,
                    signal_count: int = 0, confidence: Optional[float] = None,
                    commit_ids: Sequence[int] = (), calibration_id: Optional[int] = None) -> int:
        self._require("work_sessions")
        m = self.m
        start, end = to_ts(started_at), to_ts(ended_at)
        if end < start:
            raise RuleViolation("A session cannot end ({}) before it starts ({}).".format(end, start))
        minutes = non_negative_int(estimated_minutes, "estimated_minutes")
        with m.transaction():
            cursor = m.conn.execute(
                "INSERT INTO work_sessions (started_at, ended_at, estimated_minutes, status, "
                "calibration_id, signal_count, confidence, created_at, estimate_run_id, local_date, "
                "policy, focused_minutes, ambient_minutes) VALUES (?, ?, ?, 'draft', ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (start, end, minutes, calibration_id, non_negative_int(signal_count, "signal_count", 0),
                 confidence, m.now(), estimate_run_id, to_date(local_date),
                 choice(policy, POLICIES, "policy"), focused_minutes, ambient_minutes))
            session_id = int(cursor.lastrowid)
            for commit_id in commit_ids:
                m.conn.execute("INSERT OR IGNORE INTO session_commits (session_id, commit_id) VALUES (?, ?)",
                               (session_id, int(commit_id)))
        return session_id

    def set_allocations(self, session_id: int, minutes_by_key: Mapping[str, int],
                        method: str = "commit_share") -> None:
        """Replace how a session's minutes split across tickets.

        The parts may not exceed the whole. v_session_unlinked reports the remainder as
        `session minutes - allocated`, so over-allocating would show as negative "unlinked" time.
        """
        self._require("session_allocations")
        m = self.m
        method = choice(method, ("commit_share", "manual"), "allocation method")
        session = m.conn.execute("SELECT estimated_minutes, confirmed_minutes FROM work_sessions WHERE id = ?",
                                 (session_id,)).fetchone()
        if session is None:
            raise RuleViolation("Session {} does not exist.".format(session_id))
        limit = session["confirmed_minutes"] if session["confirmed_minutes"] is not None \
            else session["estimated_minutes"]
        clean = {jira_key(k, "allocation key"): non_negative_int(v, "allocation minutes")
                 for k, v in minutes_by_key.items()}
        if sum(clean.values()) > limit:
            raise RuleViolation("Allocations total {} minutes but the session is only {}.".format(
                sum(clean.values()), limit))
        with m.transaction():
            m.conn.execute("DELETE FROM session_allocations WHERE session_id = ?", (session_id,))
            for key, minutes in clean.items():
                item = m.conn.execute("SELECT id FROM work_items WHERE key = ? AND deleted_at IS NULL",
                                      (key,)).fetchone()
                m.conn.execute(
                    "INSERT INTO session_allocations (session_id, work_item_key, work_item_id, minutes, method) "
                    "VALUES (?, ?, ?, ?, ?)", (session_id, key, item["id"] if item else None, minutes, method))

    # -- day proposals: the unit a person reviews --------------------------------------------
    def propose_day(self, estimate_run_id: int, local_date: str,
                    rows: Sequence[Mapping[str, Any]]) -> List[int]:
        """Record what Baldur proposes for a day, one row per ticket (and one for untracked time).

        Rounding can never raise a number (`minutes_proposed <= minutes_raw`), checked here for a
        friendly message and again by the schema. Older PROPOSED rows for the same day and ticket are
        superseded; APPROVED ones are left alone, because a person's decision is not Baldur's to retire.

        `basis_hash` should be the estimator's evidence hash (model, settings, commit SHAs, meeting
        ids). A row whose hash is already proposed, approved or REJECTED for that day and ticket is
        skipped: same evidence, nothing new to say, and a rejection is not re-asked (spec step 9).
        Returns the ids of rows actually created; skipped rows are listed on `self.last_skipped`.
        """
        self._require("day_proposals")
        m = self.m
        day = to_date(local_date)
        ids: List[int] = []
        self.last_skipped: List[str] = []
        with m.transaction():
            taken = m.conn.execute("SELECT 1 FROM day_proposals WHERE estimate_run_id = ? AND local_date = ?",
                                   (estimate_run_id, day)).fetchone()
            if taken:
                raise RuleViolation("Estimate run {} already has proposals for {}. Create a new estimate "
                                    "run to re-propose; past runs are kept as they were.".format(
                                        estimate_run_id, day))
            for row in rows:
                key = jira_key(row["work_item_key"]) if row.get("work_item_key") else None
                raw = row.get("minutes_raw")
                proposed = non_negative_int(row.get("minutes_proposed"), "minutes_proposed")
                if isinstance(raw, bool) or not isinstance(raw, (int, float)) or raw < 0:
                    raise RuleViolation("minutes_raw must be a number >= 0, got {!r}.".format(raw))
                if proposed > raw:
                    raise RuleViolation(
                        "{}: proposed {} minutes exceeds the raw estimate of {}. Rounding may only "
                        "reduce a figure, never raise it.".format(key or "untracked", proposed, raw))
                basis = scrub_text(str(row.get("basis") or "")).strip()
                if not basis:
                    raise RuleViolation("{}: a proposal needs its basis. An estimate that cannot "
                                        "explain itself is a guess.".format(key or "untracked"))
                basis = basis[:_BASIS_LIMIT]
                evidence = str(row.get("basis_hash") or _hash(basis))
                if m.conn.execute(
                        "SELECT 1 FROM day_proposals WHERE local_date = ? AND coalesce(work_item_key, '') = ? "
                        "AND basis_hash = ? AND status IN ('proposed', 'approved', 'rejected')",
                        (day, key or "", evidence)).fetchone():
                    self.last_skipped.append(key or "")
                    continue
                item = m.conn.execute("SELECT id FROM work_items WHERE key = ? AND deleted_at IS NULL",
                                      (key,)).fetchone() if key else None
                m.conn.execute(
                    "UPDATE day_proposals SET status = 'superseded' WHERE local_date = ? AND "
                    "coalesce(work_item_key, '') = ? AND status = 'proposed' AND estimate_run_id <> ?",
                    (day, key or "", estimate_run_id))
                cursor = m.conn.execute(
                    "INSERT INTO day_proposals (estimate_run_id, local_date, work_item_key, work_item_id, "
                    "minutes_raw, minutes_proposed, basis, basis_hash, review, status) "
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, '{}', 'proposed')",
                    (estimate_run_id, day, key, item["id"] if item else None, raw, proposed, basis,
                     evidence))
                ids.append(int(cursor.lastrowid))
        return ids

    def change_approval(self, proposal_id: int, confirmed_by: str, minutes_final: int) -> int:
        """Change an approved figure. The old approval is superseded and a new approved row written,
        in one transaction, so the history of what was agreed and when is kept (spec: "Changing it
        later supersedes that approval with a new row; the old one stays as history")."""
        self._require("day_proposals")
        m = self.m
        who = _person(confirmed_by)
        final = non_negative_int(minutes_final, "minutes_final")
        with m.transaction():
            row = m.conn.execute("SELECT * FROM day_proposals WHERE id = ?", (proposal_id,)).fetchone()
            if row is None or row["status"] != "approved":
                raise RuleViolation("Only an approved proposal can be changed; proposal {} is {}."
                                    .format(proposal_id, "missing" if row is None else row["status"]))
            m.conn.execute("UPDATE day_proposals SET status = 'superseded' WHERE id = ?", (proposal_id,))
            cursor = m.conn.execute(
                "INSERT INTO day_proposals (estimate_run_id, local_date, work_item_key, work_item_id, "
                "minutes_raw, minutes_proposed, minutes_final, basis, basis_hash, review, status, decided_at) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'approved', ?)",
                (row["estimate_run_id"], row["local_date"], row["work_item_key"], row["work_item_id"],
                 row["minutes_raw"], row["minutes_proposed"], final, row["basis"], row["basis_hash"],
                 row["review"], m.now()))
            new_id = int(cursor.lastrowid)
            m.emit("day_proposal.approved", "day_proposals", new_id, ref=row["work_item_key"],
                   payload={"by": who, "date": row["local_date"], "final": final,
                            "supersedes": proposal_id, "was": row["minutes_final"]})
        return new_id

    def decide_day_proposal(self, proposal_id: int, approve: bool, confirmed_by: str,
                            minutes_final: Optional[int] = None) -> UpsertResult:
        """Approve or reject one proposal. Only a person's confirm action should ever call this.

        A person may edit the figure in either direction; Baldur may not. Only a 'proposed' row can
        be decided. To change an approval later use change_approval(), which supersedes it, so the
        record of what was agreed at the time is never rewritten (migration 0004 enforces this).
        """
        self._require("day_proposals")
        m = self.m
        who = _person(confirmed_by)
        with m.transaction():
            row = m.conn.execute("SELECT * FROM day_proposals WHERE id = ?", (proposal_id,)).fetchone()
            if row is None:
                raise RuleViolation("Proposal {} does not exist.".format(proposal_id))
            if row["status"] != "proposed":
                raise RuleViolation("Proposal {} is already {}; only a proposed row can be decided. "
                                    "Re-estimate to propose again.".format(proposal_id, row["status"]))
            now = m.now()
            if approve:
                if row["work_item_key"] is None:
                    raise RuleViolation("Untracked time (no Jira key) can never be approved: nothing "
                                        "is logged for it. Give the work a ticket first.")
                final = non_negative_int(minutes_final, "minutes_final", default=row["minutes_proposed"])
                m.conn.execute("UPDATE day_proposals SET status = 'approved', minutes_final = ?, "
                               "decided_at = ? WHERE id = ?", (final, now, proposal_id))
                m.emit("day_proposal.approved", "day_proposals", proposal_id, ref=row["work_item_key"],
                       payload={"by": who, "date": row["local_date"], "proposed": row["minutes_proposed"],
                                "final": final})
            else:
                m.conn.execute("UPDATE day_proposals SET status = 'rejected', decided_at = ? WHERE id = ?",
                               (now, proposal_id))
                m.emit("day_proposal.rejected", "day_proposals", proposal_id, ref=row["work_item_key"],
                       payload={"by": who, "date": row["local_date"]})
        return UpsertResult(proposal_id, UPDATED, row["work_item_key"] or "")

    # -- ground truth and calibration --------------------------------------------------------
    def record_actual(self, on_date: str, minutes: int, work_item_key: Optional[str] = None,
                      note: Optional[str] = None) -> UpsertResult:
        """Hours you really logged by hand: the ground truth calibration is fitted against.
        One per day and ticket (and one whole-day figure); recording again replaces it."""
        self._require("time_actuals")
        m = self.m
        day = to_date(on_date)
        if isinstance(minutes, bool) or not isinstance(minutes, int) or not 0 <= minutes <= 1440:
            raise RuleViolation("minutes must be 0-1440, got {!r}.".format(minutes))
        key = jira_key(work_item_key) if work_item_key else None
        note = scrub_text(note or "")[:500] or None
        with m.transaction():
            row = m.conn.execute("SELECT id, minutes, note FROM time_actuals WHERE on_date = ? AND "
                                 "coalesce(work_item_key, '') = ?", (day, key or "")).fetchone()
            if row is None:
                cursor = m.conn.execute(
                    "INSERT INTO time_actuals (on_date, minutes, work_item_key, note, created_at) "
                    "VALUES (?, ?, ?, ?, ?)", (day, minutes, key, note, m.now()))
                return UpsertResult(int(cursor.lastrowid), CREATED, key or day)
            if row["minutes"] == minutes and row["note"] == note:
                return UpsertResult(int(row["id"]), UNCHANGED, key or day)
            m.conn.execute("UPDATE time_actuals SET minutes = ?, note = ? WHERE id = ?",
                           (minutes, note, row["id"]))
            return UpsertResult(int(row["id"]), UPDATED, key or day,
                                {"minutes": [row["minutes"], minutes]})

    def accept_calibration(self, gap_minutes: int, lead_in_minutes: int, days_used: int,
                           mean_abs_error_min: float, bias_min: float, confirmed_by: str,
                           ambient_weight: Optional[float] = None) -> int:
        """Make a fitted calibration the active one. A person accepts it; nothing changes on its own.

        The old active row is deactivated first because the partial unique index allows only one.
        Past estimate runs keep the settings they used.
        """
        self._require("calibration_runs")
        m = self.m
        who = _person(confirmed_by)
        with m.transaction():
            m.conn.execute("UPDATE calibration_runs SET is_active = 0 WHERE is_active = 1")
            cursor = m.conn.execute(
                "INSERT INTO calibration_runs (created_at, gap_minutes, lead_in_minutes, days_used, "
                "mean_abs_error_min, bias_min, is_active, ambient_weight) VALUES (?, ?, ?, ?, ?, ?, 1, ?)",
                (m.now(), gap_minutes, lead_in_minutes, days_used, mean_abs_error_min, bias_min,
                 ambient_weight))
            calibration_id = int(cursor.lastrowid)
            m.emit("calibration.accepted", "calibration_runs", calibration_id,
                   payload={"by": who, "gap": gap_minutes, "lead_in": lead_in_minutes})
        return calibration_id

    # -- worklogs: the only thing that leaves Asgard -----------------------------------------
    def day_delta(self, local_date: str, work_item_key: str) -> Dict[str, int]:
        """approved, posted, pending and the amount still to offer, in minutes, for one day+ticket.

        `offer` is never negative. If a person approved less than has already been posted, `gap`
        says by how much, and nothing is offered: posted time is not retracted automatically.
        """
        day, key = to_date(local_date), jira_key(work_item_key)
        m = self.m
        approved = m._scalar(
            "SELECT minutes_final FROM day_proposals WHERE local_date = ? AND work_item_key = ? AND "
            "status = 'approved' ORDER BY decided_at DESC, id DESC LIMIT 1", (day, key)) or 0
        posted = (m._scalar(
            "SELECT coalesce(sum(w.seconds), 0) FROM worklogs w JOIN day_proposals q ON q.id = w.proposal_id "
            "WHERE q.local_date = ? AND q.work_item_key = ? AND w.state = 'posted'", (day, key)) or 0) // 60
        pending = (m._scalar(
            "SELECT coalesce(sum(w.seconds), 0) FROM worklogs w JOIN day_proposals q ON q.id = w.proposal_id "
            "WHERE q.local_date = ? AND q.work_item_key = ? AND w.state IN ('draft', 'approved')",
            (day, key)) or 0) // 60
        remaining = approved - posted - pending
        return {"approved": approved, "posted": posted, "pending": pending,
                "offer": max(0, remaining), "gap": max(0, -remaining)}

    def draft_worklog(self, proposal_id: int, started_at: str) -> Optional[int]:
        """Draft a worklog for the still-unposted part of an APPROVED proposal. None if nothing to offer.

        Needs the ticket in `work_items`, which only Odin can supply. Until Odin syncs to Muninn,
        Baldur stays report-only; the error says so.
        """
        self._require("worklogs")
        m = self.m
        with m.transaction():
            row = m.conn.execute("SELECT * FROM day_proposals WHERE id = ?", (proposal_id,)).fetchone()
            if row is None or row["status"] != "approved":
                raise RuleViolation("Only an approved proposal can become a worklog; proposal {} is {}."
                                    .format(proposal_id, "missing" if row is None else row["status"]))
            item = m.conn.execute("SELECT id FROM work_items WHERE key = ? AND deleted_at IS NULL",
                                  (row["work_item_key"],)).fetchone()
            if item is None:
                raise RuleViolation("{} is not in Muninn's work_items yet. Posting needs the ticket "
                                    "synced by Odin; until then Baldur is report-only.".format(
                                        row["work_item_key"]))
            delta = self.day_delta(row["local_date"], row["work_item_key"])
            if delta["offer"] <= 0:
                return None
            cursor = m.conn.execute(
                "INSERT INTO worklogs (work_item_id, origin, state, started_at, seconds, comment, "
                "proposal_id, basis_hash, created_at) VALUES (?, 'baldur', 'draft', ?, ?, ?, ?, ?, ?)",
                (item["id"], to_ts(started_at), delta["offer"] * 60, row["basis"][:_BASIS_LIMIT],
                 proposal_id, row["basis_hash"], m.now()))
            worklog_id = int(cursor.lastrowid)
            m.emit("worklog.drafted", "worklogs", worklog_id, ref=row["work_item_key"],
                   payload={"minutes": delta["offer"], "date": row["local_date"]})
        return worklog_id

    def approve_worklog(self, worklog_id: int, confirmed_by: str) -> None:
        self._transition_worklog(worklog_id, "draft", "approved", _person(confirmed_by))

    def reject_worklog(self, worklog_id: int, confirmed_by: str) -> None:
        self._transition_worklog(worklog_id, "draft", "rejected", _person(confirmed_by))

    def mark_worklog_posted(self, worklog_id: int, jira_worklog_id: str) -> None:
        """Record that the poster module created this worklog in Jira. Requires 'approved' first."""
        if not str(jira_worklog_id or "").strip():
            raise RuleViolation("mark_worklog_posted needs the id Jira returned for the worklog.")
        self._transition_worklog(worklog_id, "approved", "posted", None, str(jira_worklog_id).strip())

    def _transition_worklog(self, worklog_id: int, expect: str, to: str, who: Optional[str],
                            jira_id: Optional[str] = None) -> None:
        self._require("worklogs")
        m = self.m
        with m.transaction():
            row = m.conn.execute("SELECT state, origin, work_item_id FROM worklogs WHERE id = ?",
                                 (worklog_id,)).fetchone()
            if row is None:
                raise RuleViolation("Worklog {} does not exist.".format(worklog_id))
            if row["origin"] == "jira":
                raise RuleViolation("Worklog {} came from Jira and is not Baldur's to change.".format(worklog_id))
            if row["state"] != expect:
                raise RuleViolation("Worklog {} is {}; it must be {} to become {}. Rule 7: "
                                    "draft -> approved -> posted, in that order.".format(
                                        worklog_id, row["state"], expect, to))
            now = m.now()
            if to == "approved":
                m.conn.execute("UPDATE worklogs SET state = 'approved', approved_at = ? WHERE id = ?",
                               (now, worklog_id))
            elif to == "posted":
                m.conn.execute("UPDATE worklogs SET state = 'posted', jira_worklog_id = ?, posted_at = ? "
                               "WHERE id = ?", (jira_id, now, worklog_id))
            else:
                m.conn.execute("UPDATE worklogs SET state = 'rejected' WHERE id = ?", (worklog_id,))
            payload: Dict[str, Any] = {"state": to}
            if who:
                payload["by"] = who
            m.emit("worklog.{}".format(to), "worklogs", worklog_id, payload=payload)
