"""Baldur's collectors: repositories, commits, ticket links, reflog, and the calendar.

Everything here is metadata (rule 8). Commits keep their first line only, never a body or a diff.

Choices worth knowing
    * is_mine comes from `git_email` identities ONLY. The Baldur spec says so, and it is right:
      display names collide ("John Smith"), and a false positive credits someone else's commits to
      your timesheet. `git_name` identities are stored for other apps but never used here.
    * Commits are keyed per repository `(repo_id, sha)`. The same commit in two clones of one project
      is therefore stored twice, legitimately; de-duplicating across clones is the estimator's job,
      because it has to do it for cherry-picks too (that is what `patch_id` is for).
    * Repository paths are normalised (absolute, case-folded on Windows) before use as the natural
      key. Without that, `C:\\Src\\Odin` and `c:\\src\\odin` become two repositories with the same
      history.
    * No event per commit. A first scan writes thousands, and the design lists events for meaningful
      changes. One `sync_run.finished` event per run (run.py) summarises the batch.
"""
from __future__ import annotations

import os
from typing import Any, Dict, List, Mapping, Optional

from .baldur_estimates import EstimateMixin
from .common import (CREATED, RESTORED, UNCHANGED, UPDATED, BaseApi, UpsertResult, choice,
                     diff_fields, jira_key, non_negative_int, require_fields)
from .errors import RuleViolation
from .redact import first_line, scrub_text
from .timeutil import to_ts

_SHOW_AS = ("busy", "tentative", "free", "oof", "unknown")
_RESPONSE = ("organizer", "accepted", "tentative", "declined", "none")
# Migration 0004 added reflog and pull_request: the v2 spec's four key sources, in its order.
_LINK_METHODS = ("reflog", "branch", "pull_request", "message", "fuzzy", "llm", "manual")
_CAL_COLUMNS = ("title", "starts_at", "ends_at", "is_all_day", "show_as", "response", "is_cancelled",
                "logged_by", "meeting_id")
_SHA_LENGTHS = (40, 64)


def normalise_path(path: str) -> str:
    """Absolute and case-folded on Windows, so one folder is one repository however it was typed."""
    return os.path.normcase(os.path.abspath(os.path.expanduser(path)))


class BaldurApi(BaseApi, EstimateMixin):

    # -- repositories ------------------------------------------------------------------------
    def upsert_repo(self, name: str, local_path: Optional[str] = None, remote_url: Optional[str] = None,
                    default_branch: Optional[str] = None, source: Optional[str] = None) -> int:
        """Register a repository and return its id. Idempotent on the normalised local path."""
        self._require("repos")
        m = self.m
        if not str(name or "").strip():
            raise RuleViolation("A repository needs a name.")
        path = normalise_path(local_path) if local_path else None
        source_id = m.source_id(source) if source else None
        with m.transaction():
            if path:
                row = m.conn.execute("SELECT id FROM repos WHERE local_path = ?", (path,)).fetchone()
            else:
                row = m.conn.execute("SELECT id FROM repos WHERE local_path IS NULL AND name = ? AND "
                                     "coalesce(source_id, 0) = ?", (name, source_id or 0)).fetchone()
            if row is not None:
                m.conn.execute("UPDATE repos SET name = ?, remote_url = coalesce(?, remote_url), "
                               "default_branch = coalesce(?, default_branch), "
                               "source_id = coalesce(?, source_id) WHERE id = ?",
                               (name, remote_url, default_branch, source_id, row["id"]))
                return int(row["id"])
            cursor = m.conn.execute(
                "INSERT INTO repos (source_id, name, local_path, remote_url, default_branch, active, created_at) "
                "VALUES (?, ?, ?, ?, ?, 1, ?)", (source_id, name, path, remote_url, default_branch, m.now()))
            m.emit("repo.added", "repos", int(cursor.lastrowid), ref=name)
            return int(cursor.lastrowid)

    def set_repo_active(self, repo_id: int, active: bool) -> None:
        """Stop scanning a repository without losing its history."""
        self._require("repos")
        self.m.conn.execute("UPDATE repos SET active = ? WHERE id = ?", (1 if active else 0, repo_id))

    def touch_repo(self, repo_id: int) -> None:
        self._require("repos")
        self.m.conn.execute("UPDATE repos SET last_scanned_at = ? WHERE id = ?", (self.m.now(), repo_id))

    # -- commits -----------------------------------------------------------------------------
    def upsert_commit(self, repo_id: int, c: Mapping[str, Any]) -> UpsertResult:
        """Record one commit. Commits are immutable, so a repeat changes nothing but `is_mine`,
        the branch hint and the patch id, each only ever filled in or raised."""
        self._require("commits")
        run = self._need_run("Commits")
        m = self.m
        require_fields(c, ("sha", "author_name", "author_email", "authored_at", "committed_at", "subject"),
                       "Commit")
        sha = str(c["sha"]).strip().lower()
        if len(sha) not in _SHA_LENGTHS or any(ch not in "0123456789abcdef" for ch in sha):
            raise RuleViolation("sha {!r} must be a 40- or 64-character hex id.".format(c["sha"]))
        email = str(c["author_email"]).strip()
        mine = m.is_me("git_email", email)
        subject = scrub_text(first_line(str(c["subject"])))
        if not subject:
            raise RuleViolation("Commit {} has an empty subject.".format(sha[:12]))

        with m.transaction():
            row = m.conn.execute("SELECT id, is_mine, branch_hint, patch_id FROM commits "
                                 "WHERE repo_id = ? AND sha = ?", (repo_id, sha)).fetchone()
            if row is None:
                cursor = m.conn.execute(
                    "INSERT INTO commits (repo_id, sha, author_name, author_email, authored_at, committed_at, "
                    "subject, files_changed, additions, deletions, is_merge, is_mine, branch_hint, "
                    "first_seen_at, run_id, patch_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    (repo_id, sha, str(c["author_name"]).strip(), email, to_ts(c["authored_at"]),
                     to_ts(c["committed_at"]), subject,
                     non_negative_int(c.get("files_changed"), "files_changed", 0),
                     non_negative_int(c.get("additions"), "additions", 0),
                     non_negative_int(c.get("deletions"), "deletions", 0),
                     1 if c.get("is_merge") else 0, mine, c.get("branch_hint"), m.now(), run.id,
                     c.get("patch_id")))
                result = UpsertResult(int(cursor.lastrowid), CREATED, sha[:12])
            else:
                changes: Dict[str, List[Any]] = {}
                if mine and not row["is_mine"]:
                    changes["is_mine"] = [0, 1]
                if c.get("branch_hint") and not row["branch_hint"]:
                    changes["branch_hint"] = [None, c["branch_hint"]]
                if c.get("patch_id") and not row["patch_id"]:
                    changes["patch_id"] = [None, c["patch_id"]]
                if changes:
                    m.conn.execute("UPDATE commits SET is_mine = max(is_mine, ?), "
                                   "branch_hint = coalesce(branch_hint, ?), patch_id = coalesce(patch_id, ?) "
                                   "WHERE id = ?", (mine, c.get("branch_hint"), c.get("patch_id"), row["id"]))
                result = UpsertResult(int(row["id"]), UPDATED if changes else UNCHANGED, sha[:12], changes)
        self._saw("commits", result.outcome)
        return result

    def link_commit(self, commit_id: int, work_item_key: str, method: str, confidence: float) -> bool:
        """Tie a commit to a ticket. The key is kept even when the ticket is not synced (another
        team's issue); `work_item_id` fills in later via resolve_links(). A stronger link replaces a
        weaker one for the same pair; a weaker one never replaces a stronger."""
        self._require("commit_work_items")
        m = self.m
        key = jira_key(work_item_key)
        method = choice(method, _LINK_METHODS, "link method")
        if isinstance(confidence, bool) or not isinstance(confidence, (int, float)) or not 0 <= confidence <= 1:
            raise RuleViolation("confidence must be between 0 and 1, got {!r}.".format(confidence))
        with m.transaction():
            existing = m.conn.execute("SELECT confidence FROM commit_work_items WHERE commit_id = ? AND "
                                      "work_item_key = ?", (commit_id, key)).fetchone()
            if existing is not None:
                if confidence > existing["confidence"]:
                    m.conn.execute("UPDATE commit_work_items SET method = ?, confidence = ? WHERE "
                                   "commit_id = ? AND work_item_key = ?", (method, confidence, commit_id, key))
                    return True
                return False
            item = m.conn.execute("SELECT id FROM work_items WHERE key = ? AND deleted_at IS NULL",
                                  (key,)).fetchone()
            m.conn.execute("INSERT INTO commit_work_items (commit_id, work_item_key, work_item_id, method, "
                           "confidence) VALUES (?, ?, ?, ?, ?)",
                           (commit_id, key, item["id"] if item else None, method, confidence))
            return True

    def resolve_links(self) -> int:
        """Fill in work_item_id for links whose ticket Odin has since synced."""
        self._require("commit_work_items")
        return self.m.conn.execute(
            "UPDATE commit_work_items SET work_item_id = (SELECT w.id FROM work_items w WHERE w.key = "
            "commit_work_items.work_item_key AND w.deleted_at IS NULL) WHERE work_item_id IS NULL AND "
            "EXISTS (SELECT 1 FROM work_items w WHERE w.key = commit_work_items.work_item_key "
            "AND w.deleted_at IS NULL)").rowcount

    def record_reflog(self, repo_id: int, at: str, action: str, sha: str, message: Optional[str] = None) -> bool:
        """Reflog lines are activity evidence even when nothing was committed, and git expires them
        after 90 days, which is why collection has to be regular. Idempotent."""
        self._require("reflog_entries")
        cursor = self.m.conn.execute(
            "INSERT OR IGNORE INTO reflog_entries (repo_id, at, action, sha, message) VALUES (?, ?, ?, ?, ?)",
            (repo_id, to_ts(at), str(action).strip(), str(sha).strip().lower(),
             scrub_text(first_line(message or "")) or None))
        return cursor.rowcount == 1

    def recompute_ownership(self) -> int:
        """Apply newly added git_email identities to commits already stored. Only ever raises."""
        self._require("commits")
        m = self.m
        with m.transaction():
            count = m.conn.execute(
                "UPDATE commits SET is_mine = 1 WHERE is_mine = 0 AND EXISTS (SELECT 1 FROM identities i "
                "WHERE i.kind = 'git_email' AND i.value = commits.author_email COLLATE NOCASE)").rowcount
            if count:
                m.emit("ownership.recomputed", "commits", payload={"commits": count})
        return count

    # -- calendar ----------------------------------------------------------------------------
    def upsert_calendar_event(self, ev: Mapping[str, Any]) -> UpsertResult:
        """One calendar entry. Unlike Jira issues there is no trustworthy 'updated' field, so change is
        detected by comparing the fields themselves."""
        self._require("calendar_events")
        run = self._need_run("Calendar events")
        m = self.m
        require_fields(ev, ("external_id", "title", "starts_at", "ends_at"), "Calendar event")
        new: Dict[str, Any] = {
            "title": scrub_text(str(ev["title"]).strip()),
            "starts_at": to_ts(ev["starts_at"]), "ends_at": to_ts(ev["ends_at"]),
            "is_all_day": 1 if ev.get("is_all_day") else 0,
            "show_as": choice(ev.get("show_as", "busy"), _SHOW_AS, "show_as"),
            "response": choice(ev.get("response", "none"), _RESPONSE, "response"),
            "is_cancelled": 1 if ev.get("is_cancelled") else 0,
            "logged_by": ev.get("logged_by"), "meeting_id": ev.get("meeting_id"),
        }
        if new["ends_at"] < new["starts_at"]:
            raise RuleViolation("Event {!r} ends before it starts.".format(ev["external_id"]))
        external_id = str(ev["external_id"])

        with m.transaction():
            row = m.conn.execute("SELECT * FROM calendar_events WHERE source_id = ? AND external_id = ?",
                                 (run.source_id, external_id)).fetchone()
            now = m.now()
            if row is None:
                names = ("source_id", "external_id") + _CAL_COLUMNS + ("first_seen_at", "last_seen_at", "run_id")
                values = [run.source_id, external_id] + [new[c] for c in _CAL_COLUMNS] + [now, now, run.id]
                cursor = m.conn.execute("INSERT INTO calendar_events ({}) VALUES ({})".format(
                    ", ".join(names), ", ".join("?" * len(names))), values)
                result = UpsertResult(int(cursor.lastrowid), CREATED, external_id)
                m.emit("calendar_event.created", "calendar_events", result.id, ref=external_id)
            else:
                changes = diff_fields(row, new, _CAL_COLUMNS)
                restored = row["deleted_at"] is not None
                if changes or restored:
                    assignments = ["{} = ?".format(c) for c in changes] + \
                                  ["deleted_at = NULL", "run_id = ?", "last_seen_at = ?"]
                    m.conn.execute("UPDATE calendar_events SET {} WHERE id = ?".format(", ".join(assignments)),
                                   [new[c] for c in changes] + [run.id, now, row["id"]])
                    outcome = RESTORED if restored else UPDATED
                    m.emit("calendar_event.restored" if restored else "calendar_event.updated",
                           "calendar_events", int(row["id"]), ref=external_id,
                           payload={"changes": {k: v for k, v in changes.items() if k != "title"}})
                else:
                    m.conn.execute("UPDATE calendar_events SET last_seen_at = ? WHERE id = ?", (now, row["id"]))
                    outcome = UNCHANGED
                result = UpsertResult(int(row["id"]), outcome, external_id, changes)
        self._saw("calendar_events", result.outcome)
        return result

    # -- reads (filters repeated literally so SQLite can use the partial indexes) -------------
    def my_commits_between(self, start_ts: str, end_ts: str) -> List[Dict[str, Any]]:
        """Your commits in [start, end). `is_mine = 1` is written out because SQLite uses a partial
        index only when the query repeats the index's own filter."""
        rows = self.m.conn.execute(
            "SELECT c.id, c.repo_id, c.sha, c.authored_at, c.subject, c.branch_hint, c.patch_id FROM commits c "
            "WHERE c.is_mine = 1 AND c.authored_at >= ? AND c.authored_at < ? ORDER BY c.authored_at",
            (to_ts(start_ts), to_ts(end_ts))).fetchall()
        return [dict(r) for r in rows]

    def busy_meetings_between(self, start_ts: str, end_ts: str) -> List[Dict[str, Any]]:
        rows = self.m.conn.execute(
            "SELECT id, external_id, title, starts_at, ends_at, logged_by FROM v_busy_meetings "
            "WHERE starts_at >= ? AND starts_at < ? ORDER BY starts_at", (to_ts(start_ts), to_ts(end_ts))).fetchall()
        return [dict(r) for r in rows]

    def day_status(self, local_date: Optional[str] = None) -> List[Dict[str, Any]]:
        sql, params = "SELECT * FROM v_day_status", []        # type: str, List[Any]
        if local_date:
            sql += " WHERE local_date = ?"
            params.append(local_date)
        return [dict(r) for r in self.m.conn.execute(sql + " ORDER BY local_date, work_item_key", params)]
