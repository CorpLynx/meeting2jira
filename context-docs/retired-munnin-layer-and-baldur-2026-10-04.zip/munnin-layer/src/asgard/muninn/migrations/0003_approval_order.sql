-- =====================================================================
-- Muninn migration 0003: close the gaps in rule 7 (people approve anything
-- that leaves Asgard).
--
-- Found by running v1 rather than reading it. The design says CHECK
-- constraints enforce the approval order, and for `submissions` they do.
-- For the other two outbound tables they do not:
--
--   worklogs  a Baldur or manual row could be inserted directly as
--             state = 'posted' with approved_at NULL
--   blufs     a BLUF could be inserted directly as state = 'posted' with
--             approved_at NULL
--
-- The existing CHECKs cover "approved requires approved_at" and "posted
-- requires jira_worklog_id / posted_at + sent_via", but nothing says a
-- posted row must ALSO have been approved. So a bug, or a careless raw
-- INSERT, could post a worklog nobody confirmed.
--
-- These are triggers rather than CHECKs because SQLite cannot alter a CHECK
-- in place: changing one needs the create-copy-drop-rename recipe, which
-- for `worklogs` means also rebuilding its indexes and the FTS triggers
-- that reference neighbouring tables. Triggers are additive, cannot lose
-- data, and enforce exactly the same thing.
--
-- Rows from Jira itself (origin = 'jira') are exempt: Jira already holds
-- them, so there was nothing to approve.
--
-- NOT fixed here, on purpose: `submissions` cannot move draft -> withdrawn,
-- because its CHECK (state = 'draft' OR approved_at IS NOT NULL) rejects
-- 'withdrawn' without an approval, although the design says withdrawn ends
-- a submission "at any point". That table belongs to Heimdall and Bifrost,
-- which do not exist yet, and fixing it means rebuilding the table. It is
-- recorded in the README so it is settled when they are built, not
-- discovered then.
-- =====================================================================

BEGIN;

CREATE TRIGGER worklogs_posted_needs_approval_ins BEFORE INSERT ON worklogs
WHEN new.origin <> 'jira' AND new.state = 'posted' AND new.approved_at IS NULL
BEGIN
    SELECT RAISE(ABORT, 'rule 7: a worklog cannot be posted without being approved first');
END;

CREATE TRIGGER worklogs_posted_needs_approval_upd BEFORE UPDATE ON worklogs
WHEN new.origin <> 'jira' AND new.state = 'posted' AND new.approved_at IS NULL
BEGIN
    SELECT RAISE(ABORT, 'rule 7: a worklog cannot be posted without being approved first');
END;

CREATE TRIGGER worklogs_posted_after_approved_ins BEFORE INSERT ON worklogs
WHEN new.origin <> 'jira' AND new.posted_at IS NOT NULL AND new.approved_at IS NOT NULL
     AND new.posted_at < new.approved_at
BEGIN
    SELECT RAISE(ABORT, 'rule 7: a worklog cannot be posted before it was approved');
END;

CREATE TRIGGER worklogs_posted_after_approved_upd BEFORE UPDATE ON worklogs
WHEN new.origin <> 'jira' AND new.posted_at IS NOT NULL AND new.approved_at IS NOT NULL
     AND new.posted_at < new.approved_at
BEGIN
    SELECT RAISE(ABORT, 'rule 7: a worklog cannot be posted before it was approved');
END;

CREATE TRIGGER blufs_posted_needs_approval_ins BEFORE INSERT ON blufs
WHEN new.state = 'posted' AND new.approved_at IS NULL
BEGIN
    SELECT RAISE(ABORT, 'rule 7: a BLUF cannot be posted without being approved first');
END;

CREATE TRIGGER blufs_posted_needs_approval_upd BEFORE UPDATE ON blufs
WHEN new.state = 'posted' AND new.approved_at IS NULL
BEGIN
    SELECT RAISE(ABORT, 'rule 7: a BLUF cannot be posted without being approved first');
END;

CREATE TRIGGER blufs_posted_after_approved_ins BEFORE INSERT ON blufs
WHEN new.posted_at IS NOT NULL AND new.approved_at IS NOT NULL AND new.posted_at < new.approved_at
BEGIN
    SELECT RAISE(ABORT, 'rule 7: a BLUF cannot be posted before it was approved');
END;

CREATE TRIGGER blufs_posted_after_approved_upd BEFORE UPDATE ON blufs
WHEN new.posted_at IS NOT NULL AND new.approved_at IS NOT NULL AND new.posted_at < new.approved_at
BEGIN
    SELECT RAISE(ABORT, 'rule 7: a BLUF cannot be posted before it was approved');
END;

PRAGMA user_version = 3;

COMMIT;
