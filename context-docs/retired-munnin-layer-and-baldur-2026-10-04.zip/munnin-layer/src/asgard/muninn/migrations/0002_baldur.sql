-- Baldur additions to Muninn. Fold into v1, or apply as migration 0002.
BEGIN;

ALTER TABLE commits ADD COLUMN patch_id TEXT;  -- count a cherry-picked change once
CREATE INDEX ix_commits_patch_id ON commits (patch_id) WHERE patch_id IS NOT NULL;

CREATE TABLE calendar_events (
    id             INTEGER PRIMARY KEY,
    source_id      INTEGER NOT NULL REFERENCES sources(id),
    external_id    TEXT NOT NULL,
    title          TEXT NOT NULL,
    starts_at      TEXT NOT NULL CHECK (strftime('%Y-%m-%dT%H:%M:%SZ', starts_at) IS starts_at),
    ends_at        TEXT NOT NULL CHECK (strftime('%Y-%m-%dT%H:%M:%SZ', ends_at) IS ends_at),
    is_all_day     INTEGER NOT NULL DEFAULT 0 CHECK (is_all_day IN (0,1)),
    show_as        TEXT NOT NULL DEFAULT 'busy' CHECK (show_as IN ('busy','tentative','free','oof','unknown')),
    response       TEXT NOT NULL DEFAULT 'none' CHECK (response IN ('organizer','accepted','tentative','declined','none')),
    is_cancelled   INTEGER NOT NULL DEFAULT 0 CHECK (is_cancelled IN (0,1)),
    logged_by      TEXT,  -- 'odin' when Odin already logs this meeting in Jira
    meeting_id     INTEGER REFERENCES meetings(id) ON DELETE SET NULL,
    first_seen_at  TEXT NOT NULL CHECK (strftime('%Y-%m-%dT%H:%M:%SZ', first_seen_at) IS first_seen_at),
    last_seen_at   TEXT NOT NULL CHECK (strftime('%Y-%m-%dT%H:%M:%SZ', last_seen_at) IS last_seen_at),
    deleted_at     TEXT CHECK (strftime('%Y-%m-%dT%H:%M:%SZ', deleted_at) IS deleted_at),
    run_id         INTEGER REFERENCES sync_runs(id) ON DELETE SET NULL,
    UNIQUE (source_id, external_id),
    CHECK (ends_at >= starts_at)
) STRICT;
CREATE INDEX ix_calendar_events_starts ON calendar_events (starts_at) WHERE deleted_at IS NULL;

CREATE VIEW v_busy_meetings AS
    SELECT * FROM calendar_events
     WHERE deleted_at IS NULL AND is_all_day = 0 AND is_cancelled = 0
       AND response <> 'declined' AND show_as IN ('busy', 'tentative');

CREATE TABLE estimate_runs (
    id              INTEGER PRIMARY KEY,
    created_at      TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now'))
                    CHECK (strftime('%Y-%m-%dT%H:%M:%SZ', created_at) IS created_at),
    date_from       TEXT NOT NULL CHECK (date(date_from) IS date_from),
    date_to         TEXT NOT NULL CHECK (date(date_to) IS date_to),
    model_version   TEXT NOT NULL,  -- 'baldur-1'
    params          TEXT NOT NULL CHECK (json_valid(params) AND json_type(params) = 'object'),
    params_hash     TEXT NOT NULL,
    calibration_id  INTEGER REFERENCES calibration_runs(id),
    CHECK (date_to >= date_from)
) STRICT;

ALTER TABLE work_sessions ADD COLUMN estimate_run_id INTEGER REFERENCES estimate_runs(id) ON DELETE CASCADE;
ALTER TABLE work_sessions ADD COLUMN local_date TEXT CHECK (date(local_date) IS local_date);
ALTER TABLE work_sessions ADD COLUMN policy TEXT CHECK (policy IN ('ambient','overlap','independent'));
ALTER TABLE work_sessions ADD COLUMN focused_minutes REAL CHECK (focused_minutes >= 0);
ALTER TABLE work_sessions ADD COLUMN ambient_minutes REAL CHECK (ambient_minutes >= 0);
CREATE INDEX ix_sessions_run_day ON work_sessions (estimate_run_id, local_date);

CREATE TABLE session_commits (
    session_id  INTEGER NOT NULL REFERENCES work_sessions(id) ON DELETE CASCADE,
    commit_id   INTEGER NOT NULL REFERENCES commits(id),
    PRIMARY KEY (session_id, commit_id)
) STRICT, WITHOUT ROWID;

CREATE TABLE day_proposals (
    id                INTEGER PRIMARY KEY,
    estimate_run_id   INTEGER NOT NULL REFERENCES estimate_runs(id) ON DELETE CASCADE,
    local_date        TEXT NOT NULL CHECK (date(local_date) IS local_date),
    work_item_key     TEXT,  -- NULL = untracked
    work_item_id      INTEGER REFERENCES work_items(id),
    minutes_raw       REAL NOT NULL CHECK (minutes_raw >= 0),
    minutes_proposed  INTEGER NOT NULL CHECK (minutes_proposed >= 0),
    minutes_final     INTEGER CHECK (minutes_final >= 0),
    basis             TEXT NOT NULL,
    basis_hash        TEXT NOT NULL,
    review            TEXT NOT NULL DEFAULT '{}' CHECK (json_valid(review) AND json_type(review) = 'object'),
    status            TEXT NOT NULL DEFAULT 'proposed' CHECK (status IN ('proposed','approved','rejected','superseded')),
    decided_at        TEXT CHECK (strftime('%Y-%m-%dT%H:%M:%SZ', decided_at) IS decided_at),
    CHECK (minutes_proposed <= minutes_raw),
    CHECK (status <> 'approved' OR (decided_at IS NOT NULL AND minutes_final IS NOT NULL)),
    CHECK (work_item_key IS NOT NULL OR status IN ('proposed','superseded'))
) STRICT;
CREATE UNIQUE INDEX ux_day_proposals ON day_proposals (estimate_run_id, local_date, coalesce(work_item_key, ''));
CREATE INDEX ix_day_proposals_day ON day_proposals (local_date, work_item_key, status);

ALTER TABLE calibration_runs ADD COLUMN ambient_weight REAL CHECK (ambient_weight BETWEEN 0 AND 1);

ALTER TABLE worklogs ADD COLUMN proposal_id INTEGER REFERENCES day_proposals(id);
ALTER TABLE worklogs ADD COLUMN basis_hash TEXT;

-- Agreed and posted minutes per day and ticket: the base for delta logging.
CREATE VIEW v_day_status AS
    SELECT p.local_date, p.work_item_key,
           (SELECT a.minutes_final FROM day_proposals a
             WHERE a.local_date = p.local_date AND a.work_item_key = p.work_item_key
               AND a.status = 'approved'
             ORDER BY a.decided_at DESC, a.id DESC LIMIT 1) AS approved_minutes,
           coalesce((SELECT sum(w.seconds) FROM worklogs w JOIN day_proposals q ON q.id = w.proposal_id
                      WHERE q.local_date = p.local_date AND q.work_item_key = p.work_item_key
                        AND w.state = 'posted'), 0) / 60 AS posted_minutes
      FROM day_proposals p
     WHERE p.work_item_key IS NOT NULL
     GROUP BY p.local_date, p.work_item_key;

PRAGMA user_version = 2;
COMMIT;
