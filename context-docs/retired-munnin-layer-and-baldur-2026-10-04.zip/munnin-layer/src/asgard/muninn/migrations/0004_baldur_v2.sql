-- =====================================================================
-- Muninn migration 0004: what the Baldur v2 spec needs from the schema.
--
-- 1. Key sources. The spec finds a commit's Jira keys from, in order: the
--    reflog checkout, the branch, the pull request's head branch, then the
--    commit message, and stores which source each key came from. v1's
--    CHECK on commit_work_items.method allowed only message, branch, fuzzy,
--    llm and manual, so a reflog- or PR-derived key could not be stored.
--    A CHECK cannot be altered in place, so the table is rebuilt (create,
--    copy, drop, rename). Nothing references commit_work_items, and no
--    trigger or view reads it, so the rebuild touches nothing else.
--
-- 2. A decided proposal cannot be edited (spec: "a decided proposal can't
--    be edited, only superseded by a new row in the same transaction").
--    Approved rows may change in exactly one way: status -> superseded, all
--    else unchanged. Rejected and superseded rows are frozen.
--
-- 3. Superseding in the same run. v1's unique index on (run, day, ticket)
--    counted superseded rows, so changing an approval could never add the
--    new row the spec requires. The index now ignores superseded rows: at
--    most one LIVE row per run, day and ticket, plus any amount of history.
-- =====================================================================

BEGIN;

CREATE TABLE commit_work_items_new (
    commit_id      INTEGER NOT NULL REFERENCES commits(id) ON DELETE CASCADE,
    work_item_key  TEXT NOT NULL,
    work_item_id   INTEGER REFERENCES work_items(id),
    method         TEXT NOT NULL CHECK (method IN ('reflog','branch','pull_request','message',
                                                   'fuzzy','llm','manual')),
    confidence     REAL NOT NULL CHECK (confidence BETWEEN 0 AND 1),
    PRIMARY KEY (commit_id, work_item_key)
) STRICT, WITHOUT ROWID;

INSERT INTO commit_work_items_new (commit_id, work_item_key, work_item_id, method, confidence)
    SELECT commit_id, work_item_key, work_item_id, method, confidence FROM commit_work_items;

DROP TABLE commit_work_items;
ALTER TABLE commit_work_items_new RENAME TO commit_work_items;
CREATE INDEX ix_commit_items_key ON commit_work_items (work_item_key);

CREATE TRIGGER day_proposals_decided_are_frozen BEFORE UPDATE ON day_proposals
WHEN old.status IN ('rejected', 'superseded')
  OR (old.status = 'approved' AND (
          new.status IS NOT 'superseded'
       OR new.estimate_run_id IS NOT old.estimate_run_id
       OR new.local_date IS NOT old.local_date
       OR new.work_item_key IS NOT old.work_item_key
       OR new.work_item_id IS NOT old.work_item_id
       OR new.minutes_raw IS NOT old.minutes_raw
       OR new.minutes_proposed IS NOT old.minutes_proposed
       OR new.minutes_final IS NOT old.minutes_final
       OR new.basis IS NOT old.basis
       OR new.basis_hash IS NOT old.basis_hash
       OR new.review IS NOT old.review
       OR new.decided_at IS NOT old.decided_at))
BEGIN
    SELECT RAISE(ABORT, 'a decided proposal cannot be edited; supersede it with a new row');
END;

DROP INDEX ux_day_proposals;
CREATE UNIQUE INDEX ux_day_proposals ON day_proposals (estimate_run_id, local_date, coalesce(work_item_key, ''))
    WHERE status <> 'superseded';

PRAGMA user_version = 4;

COMMIT;
