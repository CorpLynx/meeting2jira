"""Rule 5: apps own their tables. Every app may READ every table; only the owner WRITES it.

This module is data, deliberately. A test asserts that every table in the schema appears here, so
when a migration adds a table nobody can forget to say who owns it: the suite fails until they do.

What this does and does not protect
    The writer checks ownership in Python, before issuing SQL. That stops an honest mistake: Baldur
    cannot accidentally overwrite a Jira issue. It is NOT a security boundary. Any code that can open
    the SQLite file can run raw SQL, and the design says plainly that discipline rests on apps going
    through the writer module. SQLite has no per-table permissions, so there is no database-level
    way to do better without a server, and the design rules a server out.
"""
from __future__ import annotations

from typing import Dict, FrozenSet

from .errors import OwnershipError

APPS = ("muninn", "huginn", "odin", "baldur", "loki", "freya", "heimdall", "bifrost",
        "ysildir", "valkyrie")

# Provenance and plumbing. The writer maintains these itself on behalf of whichever app is running;
# apps never write them directly. `events` is the one table every app appends to.
INFRASTRUCTURE: FrozenSet[str] = frozenset({
    "meta", "sources", "identities", "sync_runs", "sync_cursors", "events",
})

OWNERS: Dict[str, FrozenSet[str]] = {
    # Odin: Jira
    "work_items": frozenset({"odin"}),
    "work_item_transitions": frozenset({"odin"}),
    # Shared on purpose: Odin records what Jira already holds (origin 'jira'); Baldur drafts, and
    # later posts, its own (origin 'baldur'/'manual'). The writer splits them by origin.
    "worklogs": frozenset({"odin", "baldur"}),

    # Baldur: code, time
    "repos": frozenset({"baldur"}),
    "commits": frozenset({"baldur"}),
    "commit_work_items": frozenset({"baldur"}),
    "reflog_entries": frozenset({"baldur"}),
    "pull_requests": frozenset({"baldur"}),
    "pr_reviews": frozenset({"baldur"}),
    "calendar_events": frozenset({"baldur"}),
    "estimate_runs": frozenset({"baldur"}),
    "work_sessions": frozenset({"baldur"}),
    "session_commits": frozenset({"baldur"}),
    "session_allocations": frozenset({"baldur"}),
    "day_proposals": frozenset({"baldur"}),
    "calibration_runs": frozenset({"baldur"}),
    "time_actuals": frozenset({"baldur"}),

    # Loki: meetings
    "meetings": frozenset({"loki"}),
    "action_items": frozenset({"loki"}),
    "blufs": frozenset({"loki"}),

    # Freya: reviews. Citations are written by both texts' authors.
    "review_periods": frozenset({"freya"}),
    "review_drafts": frozenset({"freya"}),
    "citations": frozenset({"freya", "loki"}),

    # Heimdall (SeCcHm) and Bifrost (BEARs) share one table; `system` says which.
    "submissions": frozenset({"heimdall", "bifrost"}),
    "submission_status_history": frozenset({"heimdall", "bifrost"}),  # written by a trigger
}

# Objects SQLite or the schema creates that are not tables an app writes.
IGNORED_PREFIXES = ("sqlite_", "search")   # `search` is the FTS5 index and its shadow tables


def is_known_table(name: str) -> bool:
    return name in OWNERS or name in INFRASTRUCTURE or name.startswith(IGNORED_PREFIXES)


def require_owner(app: str, table: str) -> None:
    owners = OWNERS.get(table)
    if owners is None:
        raise OwnershipError(
            "`{}` is not in the ownership table, so no app may write it. Add it to "
            "asgard/muninn/ownership.py when the migration that creates it is written.".format(table))
    if app not in owners:
        raise OwnershipError(
            "`{}` may not write `{}`: it is owned by {}. Read it freely (every app may), or ask the "
            "owner's sync to write it. See rule 5.".format(app, table, " and ".join(sorted(owners))))
