"""Time at the edges (rule 4): everything stored is UTC, whole seconds, `YYYY-MM-DDTHH:MM:SSZ`.

The schema enforces that shape with `CHECK (strftime(...) IS col)`, so a sloppy value fails at write
time. This module is what makes it possible to WRITE the right shape from the messy things real
systems send:

    Jira         "2026-10-02T14:05:00.000+0000"    offset with no colon, fractional seconds
    Graph        "2026-10-02T14:05:00.0000000"     seven fractional digits, no offset at all
    git          "2026-10-02T14:05:00+02:00"       colon in the offset
    Python       datetime objects, aware or naive

None of those parse with Python 3.8's `datetime.fromisoformat`, which rejects `Z`, rejects `+0000`,
and accepts at most six fractional digits. So parsing is done here with an explicit grammar.

Two deliberate choices:

  * Fractional seconds are TRUNCATED, not rounded. Rounding 59.9s up would push a timestamp into
    the next minute, and in the worst case into the future.
  * A timestamp with no offset is REFUSED unless the caller says it is UTC. Guessing an offset is
    how a meeting ends up an hour out across a daylight-saving boundary, and Windows has no tz
    database without the tzdata package, so there is nothing trustworthy to guess with.
"""
from __future__ import annotations

import re
from datetime import date, datetime, timedelta, timezone
from typing import Callable, Optional, Union

from .errors import RuleViolation

UTC = timezone.utc
TS_FORMAT = "%Y-%m-%dT%H:%M:%SZ"

_TS_RE = re.compile(
    r"^(\d{4})-(\d{2})-(\d{2})[T ](\d{2}):(\d{2})(?::(\d{2}))?(?:[.,](\d+))?"
    r"\s*(Z|z|[+-]\d{2}(?::?\d{2})?)?$")
_DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")

Clock = Callable[[], datetime]


def system_clock() -> datetime:
    return datetime.now(UTC)


def _offset(text: str) -> timedelta:
    sign = -1 if text[0] == "-" else 1
    digits = text[1:].replace(":", "")
    hours, minutes = int(digits[:2]), int(digits[2:4] or 0)
    if hours > 23 or minutes > 59:
        raise ValueError("offset out of range")
    return sign * timedelta(hours=hours, minutes=minutes)


def parse_ts(value: Union[str, datetime], assume_utc: bool = False) -> datetime:
    """Parse to an aware UTC datetime with whole seconds. Raises RuleViolation if it cannot."""
    if isinstance(value, datetime):
        if value.tzinfo is None:
            if not assume_utc:
                raise RuleViolation(
                    "Got a datetime with no timezone. Pass an aware datetime, or say explicitly "
                    "that it is UTC (assume_utc=True). Muninn will not guess an offset.")
            value = value.replace(tzinfo=UTC)
        return value.astimezone(UTC).replace(microsecond=0)

    if not isinstance(value, str):
        raise RuleViolation("Expected a timestamp string or datetime, got {!r}.".format(value))
    match = _TS_RE.match(value.strip())
    if not match:
        raise RuleViolation(
            "{!r} is not a recognisable ISO-8601 timestamp (expected something like "
            "2026-10-02T14:05:00Z).".format(value))

    year, month, day, hour, minute, second, _fraction, zone = match.groups()
    try:
        naive = datetime(int(year), int(month), int(day), int(hour), int(minute), int(second or 0))
    except ValueError as exc:
        raise RuleViolation("{!r} is not a real date and time: {}.".format(value, exc)) from None

    if zone is None:
        if not assume_utc:
            raise RuleViolation(
                "{!r} has no UTC offset. Convert it at the source, or pass assume_utc=True if the "
                "system is known to send UTC. Muninn will not guess.".format(value))
        return naive.replace(tzinfo=UTC)
    if zone in ("Z", "z"):
        return naive.replace(tzinfo=UTC)
    try:
        return (naive - _offset(zone)).replace(tzinfo=UTC)
    except ValueError:
        raise RuleViolation("{!r} has an impossible UTC offset.".format(value)) from None


def to_ts(value: Union[str, datetime], assume_utc: bool = False) -> str:
    """The one stored timestamp format."""
    return parse_ts(value, assume_utc=assume_utc).strftime(TS_FORMAT)


def to_ts_or_none(value: Optional[Union[str, datetime]], assume_utc: bool = False) -> Optional[str]:
    return None if value in (None, "") else to_ts(value, assume_utc=assume_utc)


def now_text(clock: Optional[Clock] = None) -> str:
    return (clock or system_clock)().astimezone(UTC).strftime(TS_FORMAT)


def to_date(value: Union[str, date, datetime]) -> str:
    """A bare calendar date, `YYYY-MM-DD`. For review periods, local days, due dates."""
    if isinstance(value, datetime):
        raise RuleViolation("Expected a date, got a datetime. Convert it to the local day first.")
    if isinstance(value, date):
        return value.isoformat()
    if not isinstance(value, str) or not _DATE_RE.match(value.strip()):
        raise RuleViolation("{!r} is not a YYYY-MM-DD date.".format(value))
    try:
        parsed = date.fromisoformat(value.strip())
    except ValueError as exc:
        raise RuleViolation("{!r} is not a real date: {}.".format(value, exc)) from None
    return parsed.isoformat()


def to_date_or_none(value: Optional[Union[str, date]]) -> Optional[str]:
    """Jira's due dates arrive as `2026-10-02`, but sometimes with a time attached; keep the day."""
    if value in (None, ""):
        return None
    if isinstance(value, str) and len(value) > 10 and _DATE_RE.match(value[:10]):
        value = value[:10]
    return to_date(value)  # type: ignore[arg-type]


def days_before(now_ts: str, days: int) -> str:
    return (parse_ts(now_ts) - timedelta(days=days)).strftime(TS_FORMAT)
