"""Rule 8: no secrets, minimal content. A tripwire, not a vault.

What it is for
    Muninn stores summaries, keys and links. It must never become the place a credential ends up by
    accident: an exception message that echoes a request header, a commit subject where someone
    pasted a token, a payload built from a response object. So the writer runs two cheap checks:

        scrub_text()    REPLACES credential-shaped strings with [redacted], for text that is stored
                        as-is and has to survive (commit subjects, sync error messages).
        assert_clean()  REFUSES a structured payload that has a credential-shaped key or value,
                        for data the writer composes itself (event payloads), where finding a
                        secret means a bug worth failing loudly.

What it is NOT
    It cannot find an arbitrary password, and it is not data-loss prevention. It recognises the
    common shapes (bearer tokens, JWTs, GitHub and Slack tokens, AWS access keys, private-key
    headers, credentials embedded in a URL) and key names that say what they are. The real control is
    rule 8 itself: tokens live in Credential Manager and are never passed in here at all.

Messages never echo the offending value. Reporting a secret in the error that complains about it
would put it in the log it was being kept out of.
"""
from __future__ import annotations

import re
from typing import Any, Iterable

from .errors import RuleViolation

REDACTED = "[redacted]"

_SECRET_KEY = re.compile(
    r"(password|passwd|secret|token|authorization|api[_-]?key|credential|cookie|private[_-]?key|bearer)",
    re.IGNORECASE)

_SECRET_VALUES = [
    re.compile(r"\bBearer\s+[A-Za-z0-9._~+/=-]{16,}", re.IGNORECASE),
    re.compile(r"\beyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}"),       # JWT
    re.compile(r"\bgh[pousr]_[A-Za-z0-9]{30,}"),                                          # GitHub
    re.compile(r"\bgithub_pat_[A-Za-z0-9_]{30,}"),
    re.compile(r"\bxox[baprs]-[A-Za-z0-9-]{10,}"),                                         # Slack
    re.compile(r"\bAKIA[0-9A-Z]{16}\b"),                                                   # AWS key id
    re.compile(r"-----BEGIN [A-Z ]*PRIVATE KEY-----"),
    re.compile(r"://[^/\s:@]+:[^/\s@]+@"),                                                 # user:pass@host
]

MAX_PAYLOAD_CHARS = 64 * 1024


def scrub_text(text: str) -> str:
    """Replace credential-shaped substrings. Idempotent, and leaves everything else untouched."""
    if not text:
        return text
    for pattern in _SECRET_VALUES:
        text = pattern.sub(REDACTED, text)
    return text


def looks_secret(value: str) -> bool:
    return any(p.search(value) for p in _SECRET_VALUES)


def assert_clean(obj: Any, where: str = "payload", _depth: int = 0) -> None:
    """Raise RuleViolation if a dict/list/str holds a credential-shaped key or value."""
    if _depth > 12:
        raise RuleViolation("{} is nested too deeply to be a summary; store a reference, not the "
                            "object.".format(where))
    if isinstance(obj, dict):
        for key, value in obj.items():
            if isinstance(key, str) and _SECRET_KEY.search(key):
                raise RuleViolation(
                    "{}.{} looks like a credential by name. Muninn stores no secrets (rule 8): "
                    "keep tokens in Credential Manager and store a key or a link instead.".format(
                        where, key))
            assert_clean(value, "{}.{}".format(where, key), _depth + 1)
    elif isinstance(obj, (list, tuple)):
        for index, item in enumerate(obj):
            assert_clean(item, "{}[{}]".format(where, index), _depth + 1)
    elif isinstance(obj, str) and looks_secret(obj):
        raise RuleViolation(
            "A value in {} looks like a credential (token, key or password in a URL). Muninn "
            "stores no secrets (rule 8).".format(where))


def first_line(text: str, limit: int = 500) -> str:
    """Subject lines only: rule 8 says summaries, not bodies."""
    line = (text or "").strip().splitlines()[0] if (text or "").strip() else ""
    return line[:limit]


def check_size(serialised: str, where: str) -> None:
    if len(serialised) > MAX_PAYLOAD_CHARS:
        raise RuleViolation(
            "{} is {:,} characters, over the {:,} limit. Muninn keeps summaries and keys, not "
            "documents: store a reference to the full thing instead.".format(
                where, len(serialised), MAX_PAYLOAD_CHARS))


def any_secret_key(keys: Iterable[str]) -> bool:
    return any(_SECRET_KEY.search(k) for k in keys)
