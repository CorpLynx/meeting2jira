"""Small helpers shared by the Odin and Baldur APIs. No imports from the rest of the package except
errors, so nothing here can create an import cycle.

The important one is UpsertResult. The design detects "created vs updated" with
`first_seen_at = :now AS inserted`, which is wrong whenever an insert and a later update land in the
same second (timestamps are whole seconds): the update is reported as a create. Events are
append-only, so the wrong event could never be corrected. Here the outcome is decided by what the
writer actually did, under a write lock, and never inferred from a timestamp.
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence

from .errors import RuleViolation

from .ownership import require_owner

CREATED = "created"
UPDATED = "updated"
RESTORED = "restored"      # was soft-deleted at the source, seen again
UNCHANGED = "unchanged"

_JIRA_KEY = re.compile(r"^[A-Z][A-Z0-9_]*-[1-9][0-9]*$")


@dataclass
class UpsertResult:
    id: int
    outcome: str
    ref: str = ""
    changes: Dict[str, List[Any]] = field(default_factory=dict)   # column -> [old, new]

    @property
    def inserted(self) -> bool:
        """Kept so code written against the design's `row.inserted` reads the same way."""
        return self.outcome == CREATED

    @property
    def changed(self) -> bool:
        return self.outcome in (CREATED, UPDATED, RESTORED)


def require_fields(item: Mapping[str, Any], names: Sequence[str], what: str) -> None:
    missing = [n for n in names if item.get(n) in (None, "")]
    if missing:
        raise RuleViolation("{} is missing required field(s): {}.".format(what, ", ".join(missing)))


def diff_fields(old: Mapping[str, Any], new: Mapping[str, Any], columns: Iterable[str]) -> Dict[str, List[Any]]:
    """Columns whose stored value differs from the incoming one, as {column: [old, new]}."""
    return {c: [old[c], new[c]] for c in columns if old[c] != new[c]}


def json_list(value: Optional[Iterable[Any]], what: str) -> str:
    """A stable JSON array. Stable matters: it is compared as text to decide whether a row changed,
    so the same list must always serialise to the same string."""
    if value is None:
        return "[]"
    if isinstance(value, (str, bytes)) or not isinstance(value, (list, tuple, set, frozenset)):
        raise RuleViolation("{} must be a list, got {!r}.".format(what, value))
    items = list(value)
    if any(not isinstance(i, str) for i in items):
        raise RuleViolation("{} must be a list of strings.".format(what))
    if isinstance(value, (set, frozenset)):
        items.sort()
    return json.dumps(items, ensure_ascii=False, separators=(",", ":"))


def jira_key(value: Any, what: str = "work item key") -> str:
    """Keys are how commits and worklogs find their ticket, so a malformed one must not get in."""
    text = str(value or "").strip()
    if not _JIRA_KEY.match(text):
        raise RuleViolation("{} {!r} is not a Jira key such as ABC-123.".format(what, value))
    return text


def choice(value: Any, allowed: Sequence[str], what: str) -> str:
    text = str(value if value is not None else "").strip().lower()
    if text not in allowed:
        raise RuleViolation("{} {!r} is not one of: {}.".format(what, value, ", ".join(allowed)))
    return text


def non_negative_int(value: Any, what: str, default: Optional[int] = None) -> int:
    if value is None:
        if default is None:
            raise RuleViolation("{} is required.".format(what))
        return default
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        raise RuleViolation("{} must be a whole number >= 0, got {!r}.".format(what, value))
    return value


class BaseApi:
    """What OdinApi and BaldurApi share: a Muninn handle, an optional sync run, ownership checks.

    `run` is None on the handle-level API (`muninn.odin`) and set on the one a sync run hands out
    (`run.odin`). Operations that write synced facts need the run, because rule 2 says every such
    fact records the run that touched it; refusing without one is what keeps that true.
    """

    def __init__(self, muninn: Any, run: Any = None):
        self.m = muninn
        self.run = run

    def bound_to(self, run: Any) -> Any:
        return self.__class__(self.m, run)

    def _require(self, table: str) -> None:
        self.m._require_writable()
        require_owner(self.m.app, table)

    def _need_run(self, what: str) -> Any:
        if self.run is None:
            raise RuleViolation(
                "{} must be written inside a sync run so it carries provenance (rule 2): use "
                "`with muninn.run(source=..., stream=...) as run:` and call it on `run`.".format(what))
        return self.run

    def _saw(self, table: str, outcome: str) -> None:
        if self.run is not None:
            self.run.saw(table, outcome)
