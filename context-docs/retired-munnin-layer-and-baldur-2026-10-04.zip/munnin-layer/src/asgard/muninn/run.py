"""A sync run: provenance, one transaction, a cursor, and a careful deletion sweep.

The lifecycle is the design's "Write path", with the run row OUTSIDE the data transaction:

    1. INSERT a sync_runs row (status 'running') and read the stream's cursor.   [autocommit]
    2. BEGIN IMMEDIATE                       take the write lock now, not halfway through
    3. upserts, each touching last_seen_at and emitting events
    4. (full runs only) mark rows this run did not see as deleted
    5. advance the cursor, close the run, COMMIT

The run row is written first and on its own on purpose. If the data transaction rolls back, the
row survives and is marked 'failed', so a failure leaves a visible trace instead of vanishing with
the work it was doing.

Three decisions the design leaves open, each made in favour of "never silently lose or invent data":

  One bad item must not cost the sync.   `with run.item(ref):` isolates an item in a savepoint. If it
      is rejected (a date that is not a date, a key that is not a key) it is rolled back alone and
      recorded, the run finishes 'partial', and every other item still lands. Odin treats a
      malformed calendar entry the same way.

  A partial run does not advance the cursor.   Moving the high-water mark past an item that was
      skipped would mean it is never fetched again. Upserts are idempotent, so re-reading costs
      time and never correctness. The price is that one permanently bad item makes every later run
      re-read from the old cursor; that is visible (status 'partial') rather than silent.

  A full sync may not delete on suspicion.   Deletion is inferred from absence, and an empty or
      truncated API response (an expired token, a proxy error page, a timeout) looks exactly like
      "everything was deleted". A sweep that would remove rows after seeing nothing, or more than
      half of a sizeable set, is refused and the run fails instead. The data is left intact.
"""
from __future__ import annotations

import logging
import sqlite3
from contextlib import contextmanager
from typing import Any, Dict, Iterator, List, Optional, Tuple

from .errors import MuninnError, SyncError
from .redact import scrub_text
from .store import Muninn

log = logging.getLogger(__name__)

MAX_SWEEP_FRACTION = 0.5
MIN_LIVE_FOR_FRACTION = 10      # below this a high percentage is normal, not alarming
MAX_RECORDED_SKIPS = 20

# table -> (event noun, column naming the row in the event). Only tables with a deleted_at column
# and a per-source scope can be swept.
_SWEEPABLE: Dict[str, Tuple[str, str]] = {
    "work_items": ("work_item", "key"),
    "calendar_events": ("calendar_event", "external_id"),
}
_CHANGED = ("created", "updated", "restored")


class Run:
    def __init__(self, muninn: Muninn, source_id: int, stream: str, mode: str,
                 advance_cursor_on_partial: bool = False):
        if mode not in ("incremental", "full"):
            raise SyncError("Run mode must be 'incremental' or 'full', not {!r}.".format(mode))
        self.m = muninn
        self.source_id = source_id
        self.stream = stream
        self.mode = mode
        self.advance_cursor_on_partial = advance_cursor_on_partial
        self.id: int = 0
        self.started_at: str = ""
        self.cursor: Optional[str] = None
        self.items_seen = 0
        self.items_changed = 0
        self.skipped: List[Tuple[str, str]] = []
        self._new_cursor: Optional[str] = None
        self._seen_by_table: Dict[str, int] = {}
        self.odin = muninn.odin.bound_to(self)
        self.baldur = muninn.baldur.bound_to(self)

    # -- lifecycle ---------------------------------------------------------------------------
    def __enter__(self) -> "Run":
        m = self.m
        m._require_writable()
        if m._depth:
            raise SyncError("A sync run must be the outermost transaction; finish the current one first.")
        self.started_at = m.now()
        busy = ("Another process is writing to Muninn and did not finish in time ({}). Nothing was "
                "changed; try again shortly.")
        # Both the bookkeeping row and the data transaction need the write lock, so BOTH can find
        # the database busy. The bookkeeping INSERT used to sit outside the handler and a busy
        # database surfaced as a raw sqlite3 "database is locked" instead of this message.
        try:
            row = m.conn.execute("SELECT cursor FROM sync_cursors WHERE source_id = ? AND stream = ?",
                                 (self.source_id, self.stream)).fetchone()
            self.cursor = row["cursor"] if row else None
            cursor = m.conn.execute(
                "INSERT INTO sync_runs (app, source_id, stream, mode, started_at, status, cursor_before) "
                "VALUES (?, ?, ?, ?, ?, 'running', ?)",
                (m.app, self.source_id, self.stream, self.mode, self.started_at, self.cursor))
        except sqlite3.OperationalError as exc:
            raise SyncError(busy.format(exc)) from None     # nothing was written, so nothing to mark
        self.id = int(cursor.lastrowid)
        try:
            m._begin()
        except sqlite3.OperationalError as exc:
            self._mark_failed(exc)
            raise SyncError(busy.format(exc)) from None
        m._active_run = self
        return self

    def __exit__(self, exc_type: Any, exc: Any, tb: Any) -> bool:
        m = self.m
        try:
            if exc_type is None:
                try:
                    self._finish()
                    m._commit()
                except BaseException as failure:
                    m._rollback()
                    self._mark_failed(failure)
                    raise
            else:
                m._rollback()
                self._mark_failed(exc)
        finally:
            m._active_run = None
        return False

    # -- counting and isolation --------------------------------------------------------------
    def saw(self, table: str, outcome: str) -> None:
        """Called by the APIs after each upsert, so counts and the sweep stay honest."""
        self.items_seen += 1
        self._seen_by_table[table] = self._seen_by_table.get(table, 0) + 1
        if outcome in _CHANGED:
            self.items_changed += 1

    def skip(self, ref: str, reason: str) -> None:
        if len(self.skipped) < MAX_RECORDED_SKIPS:
            self.skipped.append((str(ref), scrub_text(reason)[:200]))
        else:
            self.skipped.append(("", ""))        # counted, not stored
        log.warning("Skipped %s in %s: %s", ref, self.stream, scrub_text(reason))

    @contextmanager
    def item(self, ref: str) -> Iterator[None]:
        """Isolate one item. A rejected item is rolled back and recorded; the run continues."""
        try:
            with self.m.transaction():
                yield
        except (MuninnError, sqlite3.Error, ValueError, KeyError, TypeError) as exc:
            self.skip(ref, "{}: {}".format(type(exc).__name__, exc))

    def advance_cursor(self, value: str) -> None:
        """Stage a new high-water mark. It is written only if the run commits (and, by default,
        only if nothing was skipped), so a crash re-reads instead of skipping."""
        if not isinstance(value, str) or not value:
            raise SyncError("A cursor must be a non-empty string.")
        self._new_cursor = value

    # -- the design's documented call style --------------------------------------------------
    def upsert_work_item(self, item: Dict[str, Any]) -> Any:
        return self.odin.upsert_work_item(item)

    # -- finishing ---------------------------------------------------------------------------
    def _finish(self) -> None:
        m = self.m
        status = "partial" if self.skipped else "ok"
        if self.mode == "full":
            self._sweep()

        cursor_after = self.cursor
        if self._new_cursor is not None:
            if self.skipped and not self.advance_cursor_on_partial:
                log.warning("Not advancing the cursor for %s: %d item(s) were skipped and would "
                            "otherwise never be fetched again.", self.stream, len(self.skipped))
            else:
                m.conn.execute(
                    "INSERT INTO sync_cursors (source_id, stream, cursor, updated_at, run_id) "
                    "VALUES (?, ?, ?, ?, ?) ON CONFLICT (source_id, stream) DO UPDATE SET "
                    "cursor = excluded.cursor, updated_at = excluded.updated_at, run_id = excluded.run_id",
                    (self.source_id, self.stream, self._new_cursor, m.now(), self.id))
                cursor_after = self._new_cursor

        error = "; ".join("{}: {}".format(r, why) for r, why in self.skipped[:MAX_RECORDED_SKIPS] if r)
        m.conn.execute(
            "UPDATE sync_runs SET finished_at = ?, status = ?, items_seen = ?, items_changed = ?, "
            "cursor_after = ?, error = ? WHERE id = ?",
            (m.now(), status, self.items_seen, self.items_changed, cursor_after,
             error[:1000] or None, self.id))
        m.emit("sync_run.finished", "sync_runs", self.id, ref=self.stream, run_id=self.id,
               payload={"stream": self.stream, "mode": self.mode, "status": status,
                        "seen": self.items_seen, "changed": self.items_changed,
                        "skipped": len(self.skipped)})

    def _sweep(self) -> None:
        """Design step 4: soft-delete what a FULL run did not see. Guarded; see the module note."""
        m = self.m
        for table, (noun, label) in _SWEEPABLE.items():
            seen = self._seen_by_table.get(table)
            if seen is None:
                continue
            live = int(m._scalar(
                'SELECT count(*) FROM "{}" WHERE source_id = ? AND deleted_at IS NULL'.format(table),
                (self.source_id,)))
            stale = m.conn.execute(
                'SELECT id, "{}" AS label FROM "{}" WHERE source_id = ? AND deleted_at IS NULL '
                "AND last_seen_at < ?".format(label, table), (self.source_id, self.started_at)).fetchall()
            if not stale:
                continue
            if seen == 0:
                raise SyncError(
                    "The full sync of {} returned nothing, which would mark all {} existing row(s) "
                    "as deleted. An empty response is far more likely an API, proxy or sign-in "
                    "problem than a mass deletion, so nothing was changed. Check the connection "
                    "and run it again.".format(self.stream, live))
            if live >= MIN_LIVE_FOR_FRACTION and len(stale) / float(live) > MAX_SWEEP_FRACTION:
                raise SyncError(
                    "The full sync of {} would mark {} of {} row(s) as deleted (over {:.0%}). That "
                    "usually means the response was truncated, so nothing was changed. If a bulk "
                    "deletion really happened at the source, remove the rows deliberately.".format(
                        self.stream, len(stale), live, MAX_SWEEP_FRACTION))
            now = m.now()
            for row in stale:
                m.conn.execute('UPDATE "{}" SET deleted_at = ?, run_id = ? WHERE id = ?'.format(table),
                               (now, self.id, row["id"]))
                m.emit("{}.deleted".format(noun), table, row["id"], ref=str(row["label"]), run_id=self.id)

    def _mark_failed(self, failure: BaseException) -> None:
        """Record the failure after the data has rolled back. Never raises: the caller is already
        propagating the real error, and a second one would hide it."""
        m = self.m
        text = scrub_text(str(failure) or type(failure).__name__)[:1000]
        try:
            m.conn.execute(
                "UPDATE sync_runs SET status = 'failed', finished_at = ?, items_seen = ?, "
                "items_changed = ?, error = ? WHERE id = ?",
                (m.now(), self.items_seen, self.items_changed, text, self.id))
            m.emit("sync_run.failed", "sync_runs", self.id, ref=self.stream, run_id=self.id,
                   payload={"stream": self.stream, "error": text[:300]})
        except sqlite3.Error as exc:
            log.error("Could not record the failure of run %s: %s", self.id, exc)
