"""Paths, preflight, connections, migrations and backups. Nothing here knows about any app's data.

Location
    %LOCALAPPDATA%\\Asgard\\muninn.db, or ~/.asgard/muninn.db off Windows. ASGARD_HOME overrides the
    folder, for tests and for running from removable media. It is never inside a program folder, so
    an app can be replaced wholesale without touching anyone's data.

Preflight
    The schema needs STRICT tables (SQLite 3.37+), FTS5, the JSON functions, RETURNING and
    VACUUM INTO. Python ships with whatever SQLite it was built against, and that differs by Python
    version and by platform: a Windows installer bundles its own copy. So every capability is
    PROBED by using it, not inferred from a version string, because a build can report a recent
    version and still have been compiled without FTS5. It runs before any file is created, so a
    machine that cannot run Muninn fails with instructions instead of leaving a half-made database.

Migrations
    Forward-only numbered files (`0001_initial.sql`, ...). Each file carries its own BEGIN/COMMIT and
    ends with `PRAGMA user_version = N`, so it applies all or nothing. Before any migration touches a
    database that already has data, a consistent copy is taken with VACUUM INTO, which is what makes
    "restore this morning's copy" a real recovery path.
"""
from __future__ import annotations

import itertools
import logging
import os
import re
import sqlite3
import sys
import tempfile
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional, Tuple

from .errors import MigrationError, PreflightError

log = logging.getLogger(__name__)

MIN_SQLITE = (3, 37, 0)
MIGRATIONS_DIR = Path(__file__).resolve().parent / "migrations"
_MIGRATION_NAME = re.compile(r"^(\d{4})_[a-z0-9_]+\.sql$")
_USER_VERSION = re.compile(r"PRAGMA\s+user_version\s*=\s*(\d+)\s*;", re.IGNORECASE)

_partial_counter = itertools.count()
STALE_PARTIAL_SECONDS = 3600         # a copy of a personal database finishes in well under a second
KEEP_DAILY_BACKUPS = 7       # design: "last 7 daily copies"
KEEP_MIGRATION_BACKUPS = 5   # not in the design; without a cap they would accumulate forever


# ---------------------------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------------------------
def data_dir() -> Path:
    override = os.environ.get("ASGARD_HOME")
    if override:
        return Path(override)
    local = os.environ.get("LOCALAPPDATA")
    return (Path(local) / "Asgard") if local else (Path.home() / ".asgard")


def db_path() -> Path:
    return data_dir() / "muninn.db"


def backups_dir(path: Optional[Path] = None) -> Path:
    return (Path(path).parent if path else data_dir()) / "backups"


# ---------------------------------------------------------------------------------------------
# Preflight
# ---------------------------------------------------------------------------------------------
@dataclass
class Preflight:
    sqlite_version: str
    python_version: str
    missing: List[str] = field(default_factory=list)

    @property
    def ok(self) -> bool:
        return not self.missing

    def lines(self) -> List[str]:
        out = ["Python {} with SQLite {}".format(self.python_version, self.sqlite_version)]
        out.extend("  MISSING: " + item for item in self.missing)
        if self.ok:
            out.append("  all required SQLite features are present")
        return out


def _probe(sql: str) -> Optional[str]:
    """Run sql on a throwaway in-memory database. None on success, the error text on failure."""
    conn = sqlite3.connect(":memory:")
    try:
        conn.executescript(sql)
        return None
    except sqlite3.Error as exc:
        return str(exc)
    finally:
        conn.close()


def preflight() -> Preflight:
    version = tuple(int(p) for p in sqlite3.sqlite_version.split(".")[:3])
    result = Preflight(sqlite_version=sqlite3.sqlite_version,
                       python_version="{}.{}.{}".format(*sys.version_info[:3]))
    if version < MIN_SQLITE:
        result.missing.append("SQLite {}.{}.{} or newer (this is {})".format(
            *MIN_SQLITE, sqlite3.sqlite_version))

    probes = [
        ("STRICT tables", "CREATE TABLE t (a INTEGER) STRICT;"),
        ("FTS5 with the porter tokenizer",
         "CREATE VIRTUAL TABLE f USING fts5(a, tokenize = 'porter unicode61');"),
        ("JSON functions", "SELECT json_valid('{}'), json_type('[]');"),
        ("RETURNING", "CREATE TABLE r (a); INSERT INTO r VALUES (1) RETURNING a;"),
        ("partial and expression indexes",
         "CREATE TABLE i (a, b); CREATE INDEX x ON i (b) WHERE a = 1; CREATE INDEX y ON i (coalesce(a, ''));"),
    ]
    for label, sql in probes:
        if _probe(sql) is not None:
            result.missing.append(label)

    # VACUUM INTO needs a real file; it cannot target :memory:.
    with tempfile.TemporaryDirectory() as tmp:
        try:
            conn = sqlite3.connect(str(Path(tmp) / "p.db"), isolation_level=None)
            conn.execute("CREATE TABLE t (a)")
            conn.execute("VACUUM INTO ?", (str(Path(tmp) / "q.db"),))
            conn.close()
        except sqlite3.Error:
            result.missing.append("VACUUM INTO (needed for backups)")
    return result


def require_preflight() -> Preflight:
    result = preflight()
    if not result.ok:
        raise PreflightError(
            "This Python cannot run Muninn.\n{}\n\n"
            "Muninn needs SQLite {}.{}+ with STRICT tables, FTS5, JSON and VACUUM INTO. The SQLite "
            "inside Python depends on the Python build, and older Python releases bundle older "
            "copies. Check yours with:\n"
            "  python -c \"import sqlite3; print(sqlite3.sqlite_version)\"\n"
            "Use a newer Python build whose SQLite passes, or ask IT for one. SQLCipher-style "
            "replacements are not an option: the design keeps Muninn pure-Python with no compiled "
            "extensions.".format("\n".join(result.lines()), *MIN_SQLITE[:2]))
    return result


# ---------------------------------------------------------------------------------------------
# Connections
# ---------------------------------------------------------------------------------------------
def connect(path: Path, read_only: bool = False, busy_timeout_ms: int = 5000) -> sqlite3.Connection:
    """Open a connection with the per-connection settings the design requires.

    isolation_level=None puts the sqlite3 module in autocommit mode so that transactions are
    exactly the ones the writer BEGINs. Left on its default, the module opens implicit transactions
    of its own in front of DML, and `BEGIN IMMEDIATE` (take the write lock up front rather than fail
    halfway on SQLITE_BUSY) could never be the first statement.
    """
    path = Path(path)
    if read_only:
        if not path.is_file():
            raise MigrationError("There is no Muninn database at {}. Open it once from a writing "
                                 "app first.".format(path))
        conn = sqlite3.connect(path.resolve().as_uri() + "?mode=ro", uri=True,
                               timeout=busy_timeout_ms / 1000.0, isolation_level=None)
    else:
        path.parent.mkdir(parents=True, exist_ok=True)
        created = not path.exists()
        conn = sqlite3.connect(str(path), timeout=busy_timeout_ms / 1000.0, isolation_level=None)
        if created:
            try:
                os.chmod(str(path), 0o600)     # best effort; NTFS ACLs on Windows govern instead
            except OSError:
                pass
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")                       # SQLite ships with it off
    conn.execute("PRAGMA busy_timeout = {:d}".format(int(busy_timeout_ms)))
    if not read_only:
        conn.execute("PRAGMA synchronous = NORMAL")                # safe with WAL, faster commits
        if conn.execute("PRAGMA journal_mode").fetchone()[0].lower() != "wal":
            try:
                conn.execute("PRAGMA journal_mode = WAL")          # persists in the file
            except sqlite3.OperationalError:
                # Only one connection can perform the switch and the others get "locked" while it
                # happens. That is expected when several apps start together, and the file ends up
                # in WAL regardless of which one wins, so it is not worth a warning. It is logged at
                # debug level in case it ever does persist.
                log.debug("Another connection was switching %s to WAL; leaving it to them.", path)
    return conn


# ---------------------------------------------------------------------------------------------
# Migrations
# ---------------------------------------------------------------------------------------------
@dataclass(frozen=True)
class Migration:
    number: int
    name: str
    path: Path


def migration_files(directory: Optional[Path] = None) -> List[Migration]:
    directory = Path(directory) if directory else MIGRATIONS_DIR
    found: List[Migration] = []
    for path in sorted(directory.glob("*.sql")):
        match = _MIGRATION_NAME.match(path.name)
        if not match:
            raise MigrationError("Migration file {} does not match NNNN_name.sql; rename it or "
                                 "remove it.".format(path.name))
        found.append(Migration(int(match.group(1)), path.name, path))
    numbers = [m.number for m in found]
    if numbers != list(range(1, len(numbers) + 1)):
        raise MigrationError("Migration numbers must run 1..N with no gaps; found {}.".format(numbers))
    return found


def latest_version(directory: Optional[Path] = None) -> int:
    files = migration_files(directory)
    return files[-1].number if files else 0


def schema_version(conn: sqlite3.Connection) -> int:
    return conn.execute("PRAGMA user_version").fetchone()[0]


def _validate_migration(migration: Migration, text: str) -> None:
    """A migration that is not self-transactional can leave the database half-migrated."""
    stated = _USER_VERSION.findall(text)
    if stated != [str(migration.number)]:
        raise MigrationError(
            "{} must set `PRAGMA user_version = {}` exactly once (found {}).".format(
                migration.name, migration.number, stated or "none"))
    body = re.sub(r"--[^\n]*", "", text)
    if not re.search(r"^\s*BEGIN\b", body, re.IGNORECASE | re.MULTILINE) or \
            not re.search(r"^\s*COMMIT\b", body, re.IGNORECASE | re.MULTILINE):
        raise MigrationError("{} must wrap itself in BEGIN ... COMMIT so it applies all or "
                             "nothing.".format(migration.name))


def _statements(text: str) -> List[str]:
    """Split a SQL script into complete statements.

    sqlite3.complete_statement understands triggers (whose bodies contain semicolons) and comments,
    so this never cuts a CREATE TRIGGER in half the way splitting on ';' would.
    """
    out: List[str] = []
    buffer = ""
    for line in text.splitlines(keepends=True):
        buffer += line
        if sqlite3.complete_statement(buffer):
            out.append(buffer)
            buffer = ""
    if buffer.strip() and re.sub(r"--[^\n]*", "", buffer).strip():
        out.append(buffer)
    return out


_TRANSACTION_CONTROL = {"BEGIN", "BEGIN TRANSACTION", "COMMIT", "END", "COMMIT TRANSACTION"}


def _is_transaction_control(statement: str) -> bool:
    bare = re.sub(r"--[^\n]*", "", statement).strip().rstrip(";").strip().upper()
    return bare in _TRANSACTION_CONTROL


def migrate(conn: sqlite3.Connection, path: Optional[Path] = None,
            directory: Optional[Path] = None, backup_to: Optional[Path] = None,
            stamp: str = "") -> List[int]:
    """Apply pending migrations in order. Returns the version numbers applied.

    The whole upgrade runs inside ONE `BEGIN IMMEDIATE`, which does two jobs:

      * It serialises concurrent openers. Two apps starting together on a fresh machine used to both
        read "version 0" and both try 0001; the loser crashed with "table meta already exists".
        Now whoever takes the lock migrates, and everyone behind it wakes up, re-reads the version
        under the lock, and finds nothing to do.
      * It makes the upgrade all-or-nothing across files, not just within each: a failure in 0003
        also rolls back 0001 and 0002.

    Each migration file still carries its own BEGIN ... COMMIT, so it stays runnable on its own with
    the `sqlite3` shell. Here those two statements are skipped and the rest run inside our
    transaction, because sqlite3's `executescript` COMMITS any open transaction before it starts,
    which would silently drop the lock at the exact moment it matters.
    """
    files = migration_files(directory)
    newest = files[-1].number if files else 0

    def plan() -> Tuple[int, List[Migration]]:
        current = schema_version(conn)
        if current > newest:
            raise MigrationError(
                "This database is at schema version {} but this code only knows up to {}. It was "
                "written by a newer Asgard; upgrade the apps rather than opening it with this one."
                .format(current, newest))
        return current, [m for m in files if m.number > current]

    current, pending = plan()
    if not pending:
        return []

    # VACUUM cannot run inside a transaction, so the safety copy is taken first. Racing openers
    # compute the same file name and the second finds it already there, so there is one copy, not many.
    if current > 0 and backup_to is not None:
        made = backup(conn, backup_to, "muninn-{}-before-v{:04d}.db".format(stamp or "now", pending[0].number))
        log.info("Backed up to %s before migrating from v%d.", made, current)

    conn.execute("BEGIN IMMEDIATE")
    try:
        current, pending = plan()            # re-read UNDER the lock: someone may have beaten us to it
        applied: List[int] = []
        for migration in pending:
            text = migration.path.read_text(encoding="utf-8")
            _validate_migration(migration, text)
            try:
                for statement in _statements(text):
                    if not _is_transaction_control(statement):
                        conn.execute(statement)
            except sqlite3.Error as exc:
                raise MigrationError(
                    "Migration {} failed and the whole upgrade was rolled back: {}. The database is "
                    "unchanged.".format(migration.name, exc)) from None
            if schema_version(conn) != migration.number:
                raise MigrationError("After {} the schema version is {}, expected {}.".format(
                    migration.name, schema_version(conn), migration.number))
            applied.append(migration.number)
            log.info("Applied %s", migration.name)
        violations = conn.execute("PRAGMA foreign_key_check").fetchall()
        if violations:
            raise MigrationError("The upgrade left {} foreign-key violation(s) and was rolled back."
                                 .format(len(violations)))
        conn.execute("COMMIT")
        return applied
    except BaseException:
        if conn.in_transaction:
            conn.execute("ROLLBACK")
        raise


# ---------------------------------------------------------------------------------------------
# Backups
# ---------------------------------------------------------------------------------------------
def backup(conn: sqlite3.Connection, directory: Path, filename: str) -> Path:
    """A consistent, compacted copy via VACUUM INTO, taken while readers keep working.

    VACUUM INTO refuses an existing target, so the copy is written under a temporary name and then
    renamed. A crash mid-copy therefore leaves a stray `.partial` file, never a truncated file
    that looks like a valid backup.
    """
    if conn.in_transaction:
        raise MigrationError("Cannot back up from inside a transaction.")
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=True)
    final = directory / filename
    if final.exists():
        return final

    # The temporary name is unique per attempt (process id + thread + a counter). With a shared name,
    # several apps starting together each decide today's backup is missing and all run VACUUM INTO
    # the same file: one deletes another's half-written copy, another trips over it. The symptoms
    # were "No such file", "disk I/O error" and "table meta already exists", all one bug.
    partial = directory / "{}.{}-{}-{}.partial".format(filename, os.getpid(), threading.get_ident(),
                                                       next(_partial_counter))
    try:
        conn.execute("VACUUM INTO ?", (str(partial),))
        # First rename wins. On POSIX os.replace silently overwrites, which is harmless here (both
        # copies are the same day's snapshot); on Windows it is an atomic replace as well.
        os.replace(str(partial), str(final))
    finally:
        if partial.exists():
            try:
                partial.unlink()
            except OSError:
                pass
    return final


def daily_backup(conn: sqlite3.Connection, directory: Path, today: str) -> Optional[Path]:
    """One copy per calendar day, taken on the first open. `today` is YYYYMMDD."""
    if schema_version(conn) == 0:
        return None
    name = "muninn-{}.db".format(today)
    if (Path(directory) / name).exists():
        return None
    made = backup(conn, directory, name)
    prune_backups(directory)
    return made


def prune_backups(directory: Path, keep_daily: int = KEEP_DAILY_BACKUPS,
                  keep_migration: int = KEEP_MIGRATION_BACKUPS) -> List[Path]:
    """Keep the newest N of each kind. Names sort chronologically, so no timestamps are read."""
    directory = Path(directory)
    removed: List[Path] = []
    groups: List[Tuple[re.Pattern, int]] = [
        (re.compile(r"^muninn-\d{8}\.db$"), keep_daily),
        (re.compile(r"^muninn-\d{8}-before-v\d{4}\.db$"), keep_migration),
    ]
    for pattern, keep in groups:
        matches = sorted((p for p in directory.glob("muninn-*.db") if pattern.match(p.name)),
                         key=lambda p: p.name)
        for old in matches[:-keep] if keep > 0 else matches:
            try:
                old.unlink()
                removed.append(old)
            except OSError as exc:
                log.warning("Could not remove old backup %s: %s", old, exc)
    # Leftovers from a backup that died mid-copy. Only ones old enough that no running backup can
    # still own them: deleting every *.partial would remove another process's copy that is being
    # written right now, which is the very bug unique temp names were introduced to prevent.
    cutoff = time.time() - STALE_PARTIAL_SECONDS
    for stray in directory.glob("*.partial"):
        try:
            if stray.stat().st_mtime < cutoff:
                stray.unlink()
        except OSError:
            pass
    return removed
