"""Odin's side of Muninn: Jira issues, their status history, and worklogs Jira already holds.

Odin owns `work_items` and `work_item_transitions`. `worklogs` is shared: Odin records rows that
came FROM Jira (origin 'jira'), Baldur drafts and posts its own (origin 'baldur'). The split is by
origin, enforced here and in baldur.py.

Where this deliberately departs from the design's sample upsert
    * "Created or updated" is decided by what the writer did under the write lock, not by comparing
      `first_seen_at` to the current second. The design's version calls an update a create whenever
      both happen in the same second, and events cannot be corrected afterwards.
    * A soft-deleted issue that reappears unchanged is RESTORED. In the design's statement the
      `WHERE excluded.updated_at > work_items.updated_at` gate sits on the same UPDATE that clears
      `deleted_at`, so an unchanged issue that comes back stays deleted forever.
    * The freshness gate is `>=`, not `>`. Timestamps are whole seconds, so two edits inside one
      second are indistinguishable by time; with `>` the second edit would be dropped until
      something else changed. A sync fetches the source's CURRENT state, so applying an equal-time
      difference is the safe reading. Strictly OLDER data is still ignored.
"""
from __future__ import annotations

import re
from typing import Any, Dict, List, Mapping, Optional

from .common import (CREATED, RESTORED, UNCHANGED, UPDATED, BaseApi, UpsertResult, diff_fields,
                     json_list, jira_key, require_fields)
from .errors import RuleViolation
from .redact import scrub_text
from .timeutil import to_date_or_none, to_ts, to_ts_or_none

_CATEGORY = {
    "todo": "todo", "to do": "todo", "new": "todo",
    "in_progress": "in_progress", "in progress": "in_progress", "indeterminate": "in_progress",
    "done": "done", "complete": "done",
}
_OPTIONAL_TEXT = ("priority", "epic_key", "parent_key", "assignee", "reporter", "sprint")
_COLUMNS = ("key", "project_key", "issue_type", "summary", "status", "status_category", "priority",
            "epic_key", "parent_key", "assignee", "reporter", "labels", "components", "story_points",
            "sprint", "url", "created_at", "updated_at", "resolved_at", "due_on")
_REQUIRED = ("jira_id", "key", "project_key", "issue_type", "summary", "status", "status_category",
             "url", "created_at", "updated_at")
_COMMENT_LIMIT = 1000


def category(value: Any) -> str:
    """Jira says 'new' / 'indeterminate' / 'done'; the schema says todo / in_progress / done."""
    found = _CATEGORY.get(str(value if value is not None else "").strip().lower())
    if found is None:
        raise RuleViolation("Status category {!r} is not one of: {}.".format(
            value, ", ".join(sorted(set(_CATEGORY)))))
    return found


def normalise_work_item(item: Mapping[str, Any]) -> Dict[str, Any]:
    """Validate and convert one Jira issue to column values. Raises RuleViolation when it is bad."""
    require_fields(item, _REQUIRED, "Work item")
    jira_id = str(item["jira_id"]).strip()
    if not re.match(r"^\d+$", jira_id):
        raise RuleViolation("jira_id {!r} must be Jira's numeric issue id (e.g. 10234), not the key."
                            .format(item["jira_id"]))
    key = jira_key(item["key"])
    project = str(item["project_key"]).strip()
    if key.split("-")[0] != project:
        raise RuleViolation("Key {} does not belong to project {}; the two disagree.".format(key, project))
    url = str(item["url"]).strip()
    if not re.match(r"^https?://", url):
        raise RuleViolation("url {!r} must be an http(s) link; it is what Freya cites.".format(url))

    out: Dict[str, Any] = {
        "jira_id": jira_id, "key": key, "project_key": project,
        "issue_type": str(item["issue_type"]).strip(),
        "summary": str(item["summary"]).strip(),
        "status": str(item["status"]).strip(),
        "status_category": category(item["status_category"]),
        "url": url,
        "created_at": to_ts(item["created_at"]),
        "updated_at": to_ts(item["updated_at"]),
        "resolved_at": to_ts_or_none(item.get("resolved_at")),
        "due_on": to_date_or_none(item.get("due_on")),
        "labels": json_list(item.get("labels"), "labels"),
        "components": json_list(item.get("components"), "components"),
    }
    for name in _OPTIONAL_TEXT:
        value = item.get(name)
        out[name] = str(value).strip() or None if value is not None else None
    for name in ("epic_key", "parent_key"):
        if out[name] is not None:
            out[name] = jira_key(out[name], name)
    points = item.get("story_points")
    if points is not None:
        if isinstance(points, bool) or not isinstance(points, (int, float)) or points < 0:
            raise RuleViolation("story_points must be a number >= 0, got {!r}.".format(points))
        points = float(points)
    out["story_points"] = points
    return out


class OdinApi(BaseApi):

    # -- issues ------------------------------------------------------------------------------
    def upsert_work_item(self, item: Mapping[str, Any]) -> UpsertResult:
        self._require("work_items")
        run = self._need_run("Work items")
        m = self.m
        new = normalise_work_item(item)
        mine = m.is_me("jira_user", new["assignee"])

        with m.transaction():
            row = m.conn.execute("SELECT * FROM work_items WHERE source_id = ? AND jira_id = ?",
                                 (run.source_id, new["jira_id"])).fetchone()
            now = m.now()

            if row is None:
                names = ("source_id", "jira_id") + _COLUMNS + ("is_mine", "first_seen_at",
                                                               "last_seen_at", "run_id")
                values = [run.source_id, new["jira_id"]] + [new[c] for c in _COLUMNS] + \
                         [mine, now, now, run.id]
                cursor = m.conn.execute(
                    "INSERT INTO work_items ({}) VALUES ({})".format(
                        ", ".join(names), ", ".join("?" * len(names))), values)
                result = UpsertResult(int(cursor.lastrowid), CREATED, new["key"])
                m.emit("work_item.created", "work_items", result.id, ref=new["key"],
                       payload={"key": new["key"]})
            else:
                changes: Dict[str, List[Any]] = {}
                if new["updated_at"] >= row["updated_at"]:
                    changes = diff_fields(row, new, _COLUMNS)
                sticky = max(row["is_mine"], mine)        # once assigned to me, always mine
                if sticky != row["is_mine"]:
                    changes["is_mine"] = [row["is_mine"], sticky]
                restored = row["deleted_at"] is not None

                if restored or changes:
                    assignments = ["{} = ?".format(c) for c in changes if c != "is_mine"]
                    values = [new[c] for c in changes if c != "is_mine"]
                    assignments += ["is_mine = ?", "deleted_at = NULL", "run_id = ?", "last_seen_at = ?"]
                    values += [sticky, run.id, now, row["id"]]
                    m.conn.execute("UPDATE work_items SET {} WHERE id = ?".format(", ".join(assignments)),
                                   values)
                    outcome = RESTORED if restored else UPDATED
                    kind = "work_item.restored" if restored else "work_item.updated"
                    m.emit(kind, "work_items", int(row["id"]), ref=new["key"],
                           payload={"key": new["key"], "changes": changes})
                else:
                    m.conn.execute("UPDATE work_items SET last_seen_at = ? WHERE id = ?", (now, row["id"]))
                    outcome = UNCHANGED
                result = UpsertResult(int(row["id"]), outcome, new["key"], changes)

        self._saw("work_items", result.outcome)
        return result

    def upsert_transition(self, work_item_id: int, t: Mapping[str, Any]) -> UpsertResult:
        """One status change from the Jira changelog. Idempotent on (work item, changelog id)."""
        self._require("work_item_transitions")
        self._need_run("Transitions")
        m = self.m
        require_fields(t, ("changelog_id", "at", "to_status", "to_category"), "Transition")
        item = m.conn.execute("SELECT key FROM work_items WHERE id = ?", (work_item_id,)).fetchone()
        if item is None:
            raise RuleViolation("Work item {} is not in Muninn, so its transition cannot be recorded. "
                                "Upsert the issue first.".format(work_item_id))
        author = t.get("author")
        by_me = m.is_me("jira_user", author)
        with m.transaction():
            cursor = m.conn.execute(
                "INSERT OR IGNORE INTO work_item_transitions "
                "(work_item_id, changelog_id, at, from_status, to_status, to_category, author, by_me) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                (work_item_id, str(t["changelog_id"]), to_ts(t["at"]), t.get("from_status"),
                 str(t["to_status"]).strip(), category(t["to_category"]), author, by_me))
            if cursor.rowcount == 1:
                result = UpsertResult(int(cursor.lastrowid), CREATED, item["key"])
                m.emit("work_item.transitioned", "work_item_transitions", result.id, ref=item["key"],
                       payload={"from": t.get("from_status"), "to": str(t["to_status"]).strip(),
                                "by_me": bool(by_me)})
            else:
                existing = m.conn.execute(
                    "SELECT id FROM work_item_transitions WHERE work_item_id = ? AND changelog_id = ?",
                    (work_item_id, str(t["changelog_id"]))).fetchone()
                result = UpsertResult(int(existing["id"]), UNCHANGED, item["key"])
        self._saw("work_item_transitions", result.outcome)
        return result

    # -- worklogs that already live in Jira --------------------------------------------------
    def upsert_jira_worklog(self, work_item_id: int, w: Mapping[str, Any]) -> UpsertResult:
        """A worklog as Jira reports it: the source of truth for what was actually posted.

        If Baldur posted it, the row already exists (same jira_worklog_id). Jira's figures win, but
        the row keeps its origin, so the audit trail still says where it came from.
        """
        self._require("worklogs")
        self._need_run("Worklogs")
        m = self.m
        require_fields(w, ("jira_worklog_id", "started_at", "seconds"), "Worklog")
        seconds = w["seconds"]
        if isinstance(seconds, bool) or not isinstance(seconds, int) or seconds <= 0:
            raise RuleViolation("Worklog seconds must be a whole number > 0, got {!r}.".format(seconds))
        if m.conn.execute("SELECT 1 FROM work_items WHERE id = ?", (work_item_id,)).fetchone() is None:
            raise RuleViolation("Work item {} is not in Muninn; upsert the issue first.".format(work_item_id))
        jira_id = str(w["jira_worklog_id"])
        started = to_ts(w["started_at"])
        comment = scrub_text(str(w.get("comment") or ""))[:_COMMENT_LIMIT] or None

        with m.transaction():
            row = m.conn.execute("SELECT * FROM worklogs WHERE work_item_id = ? AND jira_worklog_id = ?",
                                 (work_item_id, jira_id)).fetchone()
            if row is None:
                cursor = m.conn.execute(
                    "INSERT INTO worklogs (work_item_id, jira_worklog_id, origin, state, started_at, "
                    "seconds, comment, author, posted_at, created_at) "
                    "VALUES (?, ?, 'jira', 'posted', ?, ?, ?, ?, ?, ?)",
                    (work_item_id, jira_id, started, seconds, comment, w.get("author"),
                     to_ts_or_none(w.get("created_at")), m.now()))
                result = UpsertResult(int(cursor.lastrowid), CREATED, jira_id)
                m.emit("worklog.recorded", "worklogs", result.id, ref=jira_id,
                       payload={"seconds": seconds, "origin": "jira"})
            else:
                wanted = {"started_at": started, "seconds": seconds, "comment": comment,
                          "author": w.get("author")}
                changes = diff_fields(row, wanted, tuple(wanted))
                if changes:
                    m.conn.execute("UPDATE worklogs SET started_at = ?, seconds = ?, comment = ?, "
                                   "author = ? WHERE id = ?",
                                   (started, seconds, comment, w.get("author"), row["id"]))
                    m.emit("worklog.updated", "worklogs", int(row["id"]), ref=jira_id,
                           payload={"changes": {k: v for k, v in changes.items() if k != "comment"}})
                result = UpsertResult(int(row["id"]), UPDATED if changes else UNCHANGED, jira_id, changes)
        self._saw("worklogs", result.outcome)
        return result

    # -- ownership ---------------------------------------------------------------------------
    def recompute_ownership(self) -> int:
        """Apply newly added Jira identities to rows already written. Only ever raises a flag."""
        self._require("work_items")
        m = self.m
        with m.transaction():
            issues = m.conn.execute(
                "UPDATE work_items SET is_mine = 1 WHERE is_mine = 0 AND assignee IS NOT NULL AND "
                "EXISTS (SELECT 1 FROM identities i WHERE i.kind = 'jira_user' "
                "AND i.value = work_items.assignee COLLATE NOCASE)").rowcount
            moves = m.conn.execute(
                "UPDATE work_item_transitions SET by_me = 1 WHERE by_me = 0 AND author IS NOT NULL AND "
                "EXISTS (SELECT 1 FROM identities i WHERE i.kind = 'jira_user' "
                "AND i.value = work_item_transitions.author COLLATE NOCASE)").rowcount
            if issues or moves:
                m.emit("ownership.recomputed", "work_items", payload={"work_items": issues, "transitions": moves})
        return issues + moves

    # -- reads -------------------------------------------------------------------------------
    def my_open_items(self) -> List[Dict[str, Any]]:
        """Your open work, for the hub.

        Two details decide whether ix_work_items_open_mine is used at all, both checked with
        EXPLAIN QUERY PLAN:
          * the partial index's own filter is repeated literally (`is_mine = 1 AND deleted_at IS
            NULL`); SQLite ignores a partial index otherwise;
          * open is written `IN ('todo', 'in_progress')`, not `<> 'done'`. The index leads with
            status_category, and an inequality cannot seek it, so `<> 'done'` scans a different
            index instead. Equivalent today because the CHECK allows only these three values.
        """
        rows = self.m.conn.execute(
            "SELECT id, key, summary, status, status_category, updated_at FROM work_items "
            "WHERE is_mine = 1 AND deleted_at IS NULL AND status_category IN ('todo', 'in_progress') "
            "ORDER BY updated_at DESC").fetchall()
        return [dict(r) for r in rows]

    def find_by_key(self, key: str) -> Optional[Dict[str, Any]]:
        row = self.m.conn.execute("SELECT * FROM work_items WHERE key = ? AND deleted_at IS NULL",
                                  (key,)).fetchone()
        return dict(row) if row else None
