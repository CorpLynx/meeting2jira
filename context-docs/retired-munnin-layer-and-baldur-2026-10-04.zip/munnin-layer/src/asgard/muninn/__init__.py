"""Muninn: Asgard's shared data layer. One SQLite file, one writer module.

    from asgard import muninn

    with muninn.open("odin") as m:
        with m.run(source="jira-dc", stream="issues", kind="jira") as run:
            for issue in fetched:
                with run.item(issue["key"]):               # one bad issue cannot cost the sync
                    run.upsert_work_item(issue)
            run.advance_cursor(latest_updated)

The eight rules (see "Muninn data layer design.md") are the contract. This package enforces them so
that no app has to remember them: provenance on every synced row, idempotent upserts, UTC text times,
table ownership, append-only events, human approval before anything leaves, no secrets.

Open one handle per thread. Apps never run SQL; they call the methods on `m.odin`, `m.baldur` and
`run`.
"""
from __future__ import annotations

from .common import CREATED, RESTORED, UNCHANGED, UPDATED, UpsertResult
from .db import latest_version, preflight, require_preflight
from .errors import (MigrationError, MuninnError, OwnershipError, PreflightError, RuleViolation,
                     SyncError)
from .ownership import APPS, INFRASTRUCTURE, OWNERS
from .store import Muninn, fts_query
from .store import open_db as open  # noqa: A001  (deliberate: `muninn.open(...)`)

SCHEMA_VERSION = latest_version()

__all__ = [
    "open", "Muninn", "fts_query", "preflight", "require_preflight", "SCHEMA_VERSION",
    "UpsertResult", "CREATED", "UPDATED", "RESTORED", "UNCHANGED",
    "APPS", "OWNERS", "INFRASTRUCTURE",
    "MuninnError", "PreflightError", "MigrationError", "OwnershipError", "RuleViolation", "SyncError",
]
