"""Asgard: a suite of small local apps that share one data layer, Muninn.

This package currently contains only `asgard.muninn`. Each app (Odin, Baldur, Loki, Freya, ...) will
live beside it and reach Muninn through the import path, never by opening the database themselves.
"""
