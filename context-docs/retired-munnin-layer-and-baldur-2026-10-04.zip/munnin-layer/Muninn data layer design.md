# Muninn data layer design

Oct 2, 2026 · @Brandon

Muninn is one SQLite file of normalized facts, each keyed by its source system's ID, plus an append-only event log. Every app writes through one Python module, so the schema, provenance and migrations live in one place.

The executable version is `muninn_schema.sql`: 27 tables, 30 indexes, the search triggers and 5 views. It passed 58 automated checks on SQLite 3.45, covering constraints, triggers, upserts, search, views and index use.

## Rules every app follows

These eight rules are the contract. The writer module enforces them, so no app has to remember them.

1. **One writer module.** Apps call `muninn.upsert_*()` and `muninn.emit()`, never raw SQL. The module owns the schema, migrations and connection settings.
2. **Every fact carries provenance.** A row records its source system (`source_id`), its ID there (Jira key, commit SHA, meeting ID) and the sync run that last touched it.
3. **Upserts are idempotent.** Natural keys are `UNIQUE`, and writes use `INSERT … ON CONFLICT DO UPDATE`, so re-running a sync changes nothing unless the source changed. Items that vanish at the source get `deleted_at`, never a `DELETE`.
4. **Times are UTC ISO-8601 text**, like `2026-10-02T14:05:00Z`. Convert at the edges and display in local time; bare dates (`2026-10-02`) only for calendar facts such as review periods.
5. **Apps own their tables.** Only Odin writes `work_items`; only Baldur writes `commits`. Every app may read every table, and `events` is the one shared write target.
6. **Events are append-only.** Each meaningful change emits one `events` row (`work_item.updated`, `bluf.created`, `submission.state_changed`) that is never updated or deleted, so Freya and Ysildir can replay history.
7. **People approve anything that leaves Asgard.** Outbound rows (worklogs, sent BLUFs, submissions) must reach `approved` before they are posted or submitted, and only a confirm action in the UI sets `approved`. CHECK constraints enforce the order.
8. **No secrets, minimal content.** Tokens live in Credential Manager. Store summaries, keys and links rather than transcripts or full ticket descriptions, unless an open decision below says otherwise.

## Entity map

&#91;embedded content: Muninn tables by app · 27 tables\]

Baldur's link tables are foreign keys into `work_items`. Reviews and submissions point at tickets by key or cited ID, so an unsynced ticket breaks nothing.

## Conventions

One set of conventions keeps all 27 tables consistent, and SQLite enforces each one, so a bad value fails at write time instead of surfacing in Freya's output.

| Thing | Convention | Enforced by |
| --- | --- | --- |
| Tables | `STRICT`: a TEXT column rejects integers and vice versa | `STRICT` table option (SQLite 3.37+) |
| Row IDs | `id INTEGER PRIMARY KEY` | rowid alias |
| Source IDs | The source system's ID is a natural key: `(source_id, jira_id)`, `(repo_id, sha)` | `UNIQUE` constraint |
| Timestamps | TEXT, UTC, `YYYY-MM-DDTHH:MM:SSZ`, whole seconds; names end in `_at` | `CHECK (strftime('%Y-%m-%dT%H:%M:%SZ', col) IS col)` |
| Dates | TEXT `YYYY-MM-DD`; names end in `_on` | `CHECK (date(col) IS col)` |
| Booleans | INTEGER 0 or 1, named `is_*` or `by_me` | `CHECK (col IN (0,1))` |
| Enums | Lowercase TEXT from a closed list | `CHECK (col IN (…))` |
| JSON | TEXT holding an array or an object (`labels`, `payload`, `fields`) | `CHECK (json_valid(col) AND json_type(col) = 'array')` |
| Ownership | `is_mine` set at write time by matching `identities` | Writer module |
| Provenance | `source_id`, `first_seen_at`, `last_seen_at`, `run_id` on synced tables | Schema + writer |
| Removal | `deleted_at` instead of `DELETE` | Writer module |
| Names | snake\_case plural tables; `ix_` and `ux_` index prefixes | Review |

The timestamp check uses `IS`, not `=`. `strftime()` returns NULL for garbage, and a CHECK that evaluates to NULL passes; `IS` makes it fail while still allowing NULL in optional columns. It rejects spaces, a missing `Z`, fractional seconds and impossible dates such as month 13.

The writer module sets these on every connection; the preflight script reports your SQLite version.

```sql
-- once per database file (persists)
PRAGMA journal_mode = WAL;     -- readers never block the writer
-- every connection
PRAGMA foreign_keys = ON;      -- SQLite ships with foreign keys off
PRAGMA busy_timeout = 5000;    -- wait up to 5 s for another writer
PRAGMA synchronous = NORMAL;   -- safe with WAL, faster commits
```

## Provenance and sync tables

Six tables record where every fact came from and when; none of them holds work data. `meta` is plain key/value pairs (`owner_upn`, `timezone`, `created_at`, `asgard_version`).

**`sources`**: one row per external system.

| Column | Type | Rules | Notes |
| --- | --- | --- | --- |
| `id` | INTEGER | primary key |  |
| `kind` | TEXT | jira, confluence, git, github, teams, secchm, manual | `manual` = pasted or file input |
| `name` | TEXT | `UNIQUE` | `jira-dc`, `github`, `local-git`, `paste` |
| `base_url` | TEXT | nullable | NULL for local git and pasted input |
| `created_at` | ts | defaults to now |  |

**`identities`**: your accounts in each system. Every `is_mine` and `by_me` flag comes from matching these at write time.

| Column | Type | Rules | Notes |
| --- | --- | --- | --- |
| `id` | INTEGER | primary key |  |
| `kind` | TEXT | git\_email, git\_name, jira\_user, github\_login, m365\_upn, display\_name |  |
| `value` | TEXT | `COLLATE NOCASE`; `UNIQUE (kind, value)` | `Me@Agency.gov` matches `me@agency.gov` |
| `source_id` | INTEGER | FK `sources`, nullable |  |

**`sync_runs`**: one row per collector run.

| Column | Type | Rules | Notes |
| --- | --- | --- | --- |
| `id` | INTEGER | primary key |  |
| `app` | TEXT | muninn, huginn, odin, baldur, loki, freya, heimdall, bifrost, ysildir, valkyrie |  |
| `source_id` | INTEGER | FK `sources` |  |
| `stream` | TEXT | not null | `issues`, `commits:<repo>`, `meetings` |
| `mode` | TEXT | incremental, full | Only full runs may set `deleted_at` |
| `started_at`, `finished_at` | ts | start defaults to now |  |
| `status` | TEXT | running, ok, partial, failed |  |
| `items_seen`, `items_changed` | INTEGER | ≥ 0 |  |
| `cursor_before`, `cursor_after` | TEXT |  | Lets you replay a bad run |
| `error` | TEXT |  |  |

**`sync_cursors`**: the high-water mark per `(source_id, stream)`, such as Jira's last `updated` time or a repo's last SHA. The writer advances it only after the run's transaction commits, so a crash re-reads instead of skipping.

**`events`**: the append-only change log and the one table every app writes.

| Column | Type | Rules | Notes |
| --- | --- | --- | --- |
| `id` | INTEGER | primary key |  |
| `at` | ts | defaults to now |  |
| `app` | TEXT | same list as `sync_runs.app` |  |
| `kind` | TEXT | `noun.verb`, checked by GLOB | `work_item.updated`, `bluf.posted` |
| `entity_type`, `entity_id` | TEXT, INTEGER | type not null | Table name and row id |
| `ref` | TEXT |  | External ID: Jira key, SHA |
| `run_id` | INTEGER | no foreign key, by design | Events outlive pruned runs |
| `payload` | TEXT | JSON object | Changed fields, old and new |

Triggers `events_no_update` and `events_no_delete` abort any UPDATE or DELETE on `events`.

## Work tables (Odin)

Odin owns three tables: Jira issues, their status history and worklogs. The numeric `jira_id` is the real key, because an issue's `key` changes when it moves projects.

**`work_items`**: one row per Jira issue.

| Column | Type | Rules | Notes |
| --- | --- | --- | --- |
| `id` | INTEGER | primary key |  |
| `source_id` | INTEGER | FK `sources` |  |
| `jira_id` | TEXT | `UNIQUE (source_id, jira_id)` | Stable numeric id, `10234` |
| `key` | TEXT | `UNIQUE (source_id, key)` | `ABC-123`; rewritten when the issue moves |
| `project_key`, `issue_type` | TEXT | not null |  |
| `summary` | TEXT | not null | No description column yet (open decision) |
| `status` | TEXT | not null | As named in your workflow |
| `status_category` | TEXT | todo, in\_progress, done | Jira's category, renamed |
| `priority`, `epic_key`, `parent_key`, `assignee`, `reporter`, `sprint` | TEXT | nullable |  |
| `is_mine` | INTEGER | 0 or 1 | Assigned to you now or ever; never flips back to 0 |
| `labels`, `components` | TEXT | JSON array |  |
| `story_points` | REAL | ≥ 0 |  |
| `url` | TEXT | not null | The link Freya cites |
| `created_at`, `updated_at`, `resolved_at` | ts | Jira's own times | `updated_at` gates every upsert |
| `due_on` | date |  |  |
| `first_seen_at`, `last_seen_at` | ts | not null | The deletion sweep reads `last_seen_at` |
| `deleted_at` | ts |  | Set by full syncs only |
| `run_id` | INTEGER | FK `sync_runs`, set null on prune |  |

**`work_item_transitions`**: status changes from Jira's changelog, which give Baldur and Freya real start and finish times.

| Column | Type | Rules | Notes |
| --- | --- | --- | --- |
| `id` | INTEGER | primary key |  |
| `work_item_id` | INTEGER | FK `work_items`, cascade |  |
| `changelog_id` | TEXT | `UNIQUE (work_item_id, changelog_id)` | Jira's history id |
| `at` | ts | not null |  |
| `from_status`, `to_status` | TEXT | `to_status` not null |  |
| `to_category` | TEXT | todo, in\_progress, done |  |
| `author` | TEXT |  |  |
| `by_me` | INTEGER | 0 or 1 | Feeds `v_activity` |

**`worklogs`**: pulled from Jira or drafted by Baldur. Its checks enforce rule 7 at the database level.

| Column | Type | Rules | Notes |
| --- | --- | --- | --- |
| `id` | INTEGER | primary key |  |
| `work_item_id` | INTEGER | FK `work_items` |  |
| `jira_worklog_id` | TEXT | `UNIQUE (work_item_id, jira_worklog_id)` | Set once posted |
| `origin` | TEXT | jira, baldur, manual |  |
| `state` | TEXT | draft, approved, posted, rejected |  |
| `started_at` | ts | not null |  |
| `seconds` | INTEGER | > 0 |  |
| `comment`, `author` | TEXT |  |  |
| `session_id` | INTEGER | FK `work_sessions`, set null | The Baldur session it came from |
| `approved_at`, `posted_at`, `created_at` | ts |  |  |

Three table checks: `posted` requires `jira_worklog_id`, `approved` requires `approved_at`, and rows from Jira must be `posted`.

## Code and time tables (Baldur)

Baldur owns ten tables in two groups: what happened in git, as metadata only (no code, no diffs), and the time estimates built from it.

### Git facts

**`repos`**: one row per repository Baldur scans.

| Column | Type | Rules | Notes |
| --- | --- | --- | --- |
| `id` | INTEGER | primary key |  |
| `source_id` | INTEGER | FK `sources`, nullable | The GitHub source, when the repo has a remote there |
| `name` | TEXT | not null | `owner/repo` or the folder name |
| `local_path` | TEXT | `UNIQUE`, nullable | NULL for remote-only repos |
| `remote_url`, `default_branch` | TEXT |  |  |
| `active` | INTEGER | 0 or 1 | Set 0 to stop scanning without losing history |
| `last_scanned_at`, `created_at` | ts |  |  |

**`commits`**: one row per commit.

| Column | Type | Rules | Notes |
| --- | --- | --- | --- |
| `id` | INTEGER | primary key |  |
| `repo_id` | INTEGER | FK `repos` |  |
| `sha` | TEXT | length 40 or 64; `UNIQUE (repo_id, sha)` | SHA-1 or SHA-256 repos |
| `author_name`, `author_email` | TEXT | email `COLLATE NOCASE` | Matched against `identities` |
| `authored_at`, `committed_at` | ts | not null | Baldur uses `authored_at`; rebases rewrite the other |
| `subject` | TEXT | not null | First line only |
| `files_changed`, `additions`, `deletions` | INTEGER | ≥ 0 | From `git log --numstat` |
| `is_merge`, `is_mine` | INTEGER | 0 or 1 |  |
| `branch_hint` | TEXT |  | Branch it was first seen on |
| `first_seen_at` | ts | not null |  |
| `run_id` | INTEGER | FK `sync_runs`, set null |  |

**`pull_requests`**: one row per PR, `UNIQUE (repo_id, number)`.

| Column | Type | Rules | Notes |
| --- | --- | --- | --- |
| `id`, `repo_id`, `number` | INTEGER | number > 0 |  |
| `title`, `author`, `url` | TEXT | not null |  |
| `is_mine` | INTEGER | 0 or 1 |  |
| `state` | TEXT | open, closed, merged | `merged` requires `merged_at` |
| `created_at`, `updated_at`, `merged_at`, `closed_at` | ts | first two not null |  |
| `additions`, `deletions` | INTEGER | ≥ 0 |  |
| `first_seen_at`, `last_seen_at`, `run_id` | ts, ts, INTEGER |  | Same provenance as `work_items` |

The three link and activity tables:

- **`commit_work_items`**: `commit_id` FK (cascade), `work_item_key` TEXT, `work_item_id` FK nullable, `method` (message, branch, fuzzy, llm, manual), `confidence` REAL 0–1. Primary key `(commit_id, work_item_key)`. The key is kept even for another team's ticket; `work_item_id` fills in once Odin syncs it.
- **`reflog_entries`**: `repo_id` FK, `at` ts, `action` (checkout, commit, rebase, reset, merge, pull), `sha`, `message`; `UNIQUE (repo_id, at, sha, action)`. Git expires reflog entries after 90 days by default, so Baldur collects weekly.
- **`pr_reviews`**: `pr_id` FK (cascade), `github_id` (unique per PR), `reviewer`, `is_mine`, `state` (approved, changes\_requested, commented, dismissed), `submitted_at` ts, `comment_count`.

### Time estimates

**`work_sessions`**: Baldur's estimated blocks of work.

| Column | Type | Rules | Notes |
| --- | --- | --- | --- |
| `id` | INTEGER | primary key |  |
| `started_at`, `ended_at` | ts | `ended_at >= started_at` |  |
| `estimated_minutes` | INTEGER | ≥ 0 | From the active calibration |
| `confirmed_minutes` | INTEGER | required once confirmed or edited | What you agreed to |
| `status` | TEXT | draft, confirmed, edited, discarded |  |
| `calibration_id` | INTEGER | FK `calibration_runs` | Which parameters produced it |
| `signal_count` | INTEGER | ≥ 0 | Activity rows inside the session |
| `confidence` | REAL | 0–1 |  |
| `created_at` | ts | defaults to now |  |

- **`session_allocations`**: `session_id` FK (cascade), `work_item_key`, `work_item_id` FK nullable, `minutes` ≥ 0, `method` (commit\_share, manual). Primary key `(session_id, work_item_key)`. Leftover minutes appear in `v_session_unlinked`; there is no catch-all row.
- **`calibration_runs`**: `gap_minutes` > 0, `lead_in_minutes` ≥ 0, `days_used` > 0, `mean_abs_error_min` (per day), `bias_min` (signed, per day), `is_active`. A partial unique index allows exactly one active row.
- **`time_actuals`**: `on_date` date, `minutes` 0–1440, `work_item_key` (NULL = the whole day), `note`. The expression index `ux_time_actuals_day_item` allows one row per day and ticket, including one whole-day row.

## Meeting and BLUF tables (Loki)

Loki owns three tables. They keep what a BLUF needs (titles, Copilot's notes, decisions, owners) and nothing from raw transcripts.

**`meetings`**: one row per meeting Loki has notes for.

| Column | Type | Rules | Notes |
| --- | --- | --- | --- |
| `id` | INTEGER | primary key |  |
| `source_id` | INTEGER | FK `sources` | `teams`, or `paste` for pasted recaps |
| `external_id` | TEXT | `UNIQUE (source_id, external_id)` | Graph meeting id; for pasted recaps, a hash of title and start |
| `title` | TEXT | not null |  |
| `starts_at`, `ends_at` | ts | `ends_at >= starts_at` |  |
| `organizer` | TEXT |  |  |
| `attendee_count` | INTEGER | ≥ 0 |  |
| `recap_origin` | TEXT | graph\_insights, graph\_transcript, paste, file | Which of Loki's paths produced it |
| `source_link` | TEXT |  | Recap or join link: what a BLUF cites |
| `notes_summary` | TEXT |  | Copilot's notes or the pasted recap, never the transcript |
| `first_seen_at` | ts | not null |  |
| `run_id` | INTEGER | FK `sync_runs`, set null |  |

**`action_items`**: `meeting_id` FK (cascade), `text`, `owner`, `is_mine`, `due_on` date, `status` (open, done, dropped), `work_item_key` for a Jira issue created from it, `created_at`.

**`blufs`**: every BLUF Loki drafts, for meetings and code changes alike.

| Column | Type | Rules | Notes |
| --- | --- | --- | --- |
| `id` | INTEGER | primary key |  |
| `subject_type` | TEXT | meeting, commit\_range, pull\_request, work\_item, adhoc |  |
| `subject_ref` | TEXT | not null | Meeting `external_id`, `repo:sha1..sha2`, PR URL or Jira key |
| `bottom_line` | TEXT | not null | The one sentence |
| `body_md` | TEXT | not null | The full message as sent |
| `sections` | TEXT | JSON object | `{"decisions":[],"actions":[],"risks":[],"asks":[]}`; Freya reads decisions here |
| `tier` | TEXT | api, mcp, clipboard, manual |  |
| `model` | TEXT |  | NULL for clipboard and manual |
| `prompt_version` | TEXT | not null | `loki-v3`: ties output changes to prompt changes |
| `state` | TEXT | draft, approved, posted, rejected |  |
| `sent_via` | TEXT | clipboard, mailto, graph\_mail, teams |  |
| `created_at`, `approved_at`, `posted_at` | ts |  |  |

Two table checks: `approved` requires `approved_at`, and `posted` requires both `posted_at` and `sent_via`. The IDs a BLUF cites go in `citations`, described with Freya's tables.

## Review tables (Freya)

Freya owns three tables, and the third is the guardrail: every ID a generated text cites must resolve to a real row before the text can be marked final.

**`review_periods`**: `id`, `label` (`UNIQUE`, such as `FY2026 annual`), `starts_on` and `ends_on` dates (end on or after start), and `rubric`, a JSON array of your performance elements and standards, entered once per period.

**`review_drafts`**: one row per generated section.

| Column | Type | Rules | Notes |
| --- | --- | --- | --- |
| `id` | INTEGER | primary key |  |
| `period_id` | INTEGER | FK `review_periods` |  |
| `element` | TEXT | not null | Performance element from the rubric |
| `version` | INTEGER | ≥ 1; `UNIQUE (period_id, element, version)` | Every regeneration is a new version |
| `text` | TEXT | not null |  |
| `tier` | TEXT | api, mcp, clipboard, manual |  |
| `model`, `prompt_version` | TEXT | prompt version not null |  |
| `status` | TEXT | draft, final, discarded |  |
| `created_at` | ts | defaults to now |  |

**`citations`**: every ID cited by a BLUF or a review draft.

| Column | Type | Rules | Notes |
| --- | --- | --- | --- |
| `id` | INTEGER | primary key |  |
| `owner_type` | TEXT | bluf, review\_draft |  |
| `owner_id` | INTEGER | not null | The citing row; two possible tables, so no foreign key |
| `evidence_type` | TEXT | work\_item, commit, pull\_request, meeting, bluf, work\_session |  |
| `evidence_ref` | TEXT | `UNIQUE (owner_type, owner_id, evidence_type, evidence_ref)` | Exactly what the text cites: `XYZ-45`, a SHA, `asgard#7` |
| `evidence_id` | INTEGER |  | Resolved row id; NULL until resolved |
| `verified` | INTEGER | 0 or 1; 1 requires `evidence_id` |  |

How the guardrail runs:

1. Freya's prompt asks for IDs in brackets; the writer parses them into `citations` with `verified = 0`.
2. The checker resolves each `evidence_ref` against its table and sets `evidence_id` and `verified = 1`.
3. Any row left in `v_unverified_citations` blocks marking the draft final. In testing, an invented `XYZ-999` stayed unverified while the real key resolved.

## Submission tables (Heimdall, Bifrost)

Heimdall and Bifrost share one `submissions` table with a `system` column, plus a history table that a trigger fills, so no app can forget to log a status change. States run draft → approved → submitted → in\_review → accepted or returned, and withdrawn ends a submission at any point.

**`submissions`**: one row per SeCcHm request or BEARs workbook.

| Column | Type | Rules | Notes |
| --- | --- | --- | --- |
| `id` | INTEGER | primary key |  |
| `system` | TEXT | secchm, bears |  |
| `title` | TEXT | not null |  |
| `state` | TEXT | draft, approved, submitted, in\_review, accepted, returned, withdrawn |  |
| `external_id` | TEXT | `UNIQUE (system, external_id)` | SeCcHm number, or the Confluence page id for BEARs |
| `external_url` | TEXT |  |  |
| `fields` | TEXT | JSON object | The values filled in, by field name |
| `artifact_path` | TEXT |  | The generated .xlsx for BEARs |
| `attachment_id`, `attachment_version` | TEXT, INTEGER | version ≥ 1 | The Confluence attachment; re-uploads bump the version |
| `work_item_key` | TEXT |  | Related Jira issue, if any |
| `created_at`, `approved_at`, `submitted_at` | ts |  |  |
| `last_polled_at`, `next_poll_at` | ts |  | The poll queue reads `next_poll_at` |
| `last_status_raw` | TEXT |  | Status text exactly as the system shows it |

Two table checks carry rule 7: any state past draft requires `approved_at`, and submitted or later requires `submitted_at`.

**`submission_status_history`**: `submission_id` FK (cascade), `at` ts (defaults to now), `from_state`, `to_state`, `raw_status`. Triggers `submissions_first_history` and `submissions_state_history` add a row on insert and on every state change; in testing, a draft taken through three changes produced four rows.

`fields` can hold the same sensitive detail as the systems themselves, so it gets the same handling as their exports.

## Search and views

One FTS5 table indexes text from seven tables, and five views reshape the normalized tables into what Baldur and Freya actually read.

**`search`** is an FTS5 table with `title`, `body` and an unindexed `kind`, using the `porter unicode61` tokenizer so "submit" also finds "submitted". Its rowid packs the source row as `entity_id * 16 + type code`, decoded with `rowid >> 4` and `rowid & 15`, so each trigger updates one row by rowid instead of scanning.

| Code | Table | `title` | `body` |
| --- | --- | --- | --- |
| 1 | `work_items` | key + summary | epic, type, labels, components |
| 2 | `commits` | subject | short SHA, branch |
| 3 | `pull_requests` | title | number, author |
| 4 | `meetings` | title | `notes_summary` |
| 5 | `action_items` | text | owner, Jira key |
| 6 | `blufs` | bottom line | `body_md` |
| 7 | `submissions` | title | system, external ID, Jira key |

Insert, update and delete triggers on each table keep the index current. In testing, an issue moved from `ABC-123` to `XYZ-45` left no stale hit.

```sql
SELECT kind, rowid >> 4 AS entity_id, title
  FROM search
 WHERE search MATCH 'bears'
 ORDER BY bm25(search)
 LIMIT 20;
```

| View | Returns | Read by |
| --- | --- | --- |
| `v_activity` | Your commits, reflog entries, PR reviews, Jira transitions and meetings as one timeline: `at`, `kind`, `repo_id`, `ref_id`, `label` | Baldur's session builder |
| `v_session_unlinked` | Minutes per session not yet tied to a ticket | The hub's review screen |
| `v_time_by_item_month` | Confirmed minutes per ticket per month | Freya |
| `v_review_evidence` | Your resolved issues, merged PRs and posted BLUFs inside each review period | Freya, Ysildir |
| `v_unverified_citations` | Citations the checker could not resolve | Freya's final-draft gate |

## Indexes and the queries they serve

Each of the 30 explicit indexes exists for a named query; the seven marked checked were confirmed with `EXPLAIN QUERY PLAN`. `UNIQUE` constraints already index the natural keys, so they are not repeated here.

| Index | On (partial filter) | Serves | Checked |
| --- | --- | --- | --- |
| `ix_events_at` | `events (at)` | Ysildir: what changed since a time |  |
| `ix_events_entity` | `events (entity_type, entity_id)` | History of one row | Yes |
| `ix_events_kind_at` | `events (kind, at)` | One kind of change over a period |  |
| `ix_sync_runs_app_started` | `sync_runs (app, started_at)` | Hub: last run per app |  |
| `ix_work_items_mine_resolved` | `work_items (resolved_at)` where `is_mine = 1` | Freya: your resolved issues in a period | Yes |
| `ix_work_items_open_mine` | `work_items (status_category, updated_at)` where mine and not deleted | Hub: your open work |  |
| `ix_work_items_updated` | `work_items (source_id, updated_at)` | Odin: incremental sync |  |
| `ix_work_items_epic` | `work_items (epic_key)` where not null | Freya: grouping by epic |  |
| `ix_work_items_last_seen` | `work_items (source_id, last_seen_at)` where not deleted | Odin: deletion sweep after a full sync | Yes |
| `ix_transitions_mine_at` | `work_item_transitions (at)` where `by_me = 1` | `v_activity` |  |
| `ix_commits_mine_authored` | `commits (authored_at)` where `is_mine = 1` | Baldur: your commits in a window | Yes |
| `ix_commits_repo_authored` | `commits (repo_id, authored_at)` | Per-repo history; Loki's commit ranges |  |
| `ix_commit_items_key` | `commit_work_items (work_item_key)` | Commits for a ticket | Yes |
| `ix_reflog_at` | `reflog_entries (at)` | `v_activity` |  |
| `ix_prs_mine_merged` | `pull_requests (merged_at)` where `is_mine = 1` | Freya's evidence |  |
| `ix_pr_reviews_mine_at` | `pr_reviews (submitted_at)` where `is_mine = 1` | `v_activity` |  |
| `ux_calibration_active` | `calibration_runs (is_active)` where active; unique | Exactly one active calibration |  |
| `ix_sessions_started` | `work_sessions (started_at)` | Sessions by day |  |
| `ix_allocations_key` | `session_allocations (work_item_key)` | Time per ticket |  |
| `ix_worklogs_item_started` | `worklogs (work_item_id, started_at)` | Duplicate check before posting |  |
| `ix_worklogs_pending` | `worklogs (state, created_at)` where draft or approved | Hub: approval queue | Yes |
| `ux_time_actuals_day_item` | `time_actuals (on_date, coalesce(work_item_key, ''))`; unique | One actual per day and ticket |  |
| `ix_meetings_starts` | `meetings (starts_at)` | Meetings by day; `v_activity` |  |
| `ix_action_items_open` | `action_items (due_on)` where open | Open actions by due date |  |
| `ix_blufs_subject` | `blufs (subject_type, subject_ref)` | BLUFs about one meeting or ticket |  |
| `ix_blufs_posted` | `blufs (posted_at)` where posted | Freya's evidence |  |
| `ix_citations_evidence` | `citations (evidence_type, evidence_ref)` | Where a ticket is cited |  |
| `ix_citations_unverified` | `citations (owner_type, owner_id)` where unverified | Final-draft gate |  |
| `ix_submissions_poll` | `submissions (next_poll_at)` where submitted or in review | Heimdall and Bifrost poll queue | Yes |
| `ix_submission_history` | `submission_status_history (submission_id, at)` | Status timeline |  |

SQLite uses a partial index only when the query repeats its filter, so `WHERE is_mine = 1` must appear literally in Freya's and Baldur's queries. The approval queue reads two states, so SQLite sorts its few rows in memory; that is fine at this size.

## Write path

Every sync follows the same five steps inside one transaction, so a crash leaves the database exactly as it was before the run.

1. Open a `sync_runs` row (`running`) and read the stream's cursor from `sync_cursors`.
2. `BEGIN IMMEDIATE`, so the run takes the write lock up front instead of failing halfway on `SQLITE_BUSY`.
3. For each item, run the upsert below, then touch `last_seen_at`; when the upsert returns a row, emit an event.
4. On full syncs only, set `deleted_at` on rows this run did not see.
5. Advance the cursor, close the run, `COMMIT`.

The upsert, as tested:

```sql
INSERT INTO work_items (source_id, jira_id, key, project_key, issue_type, summary,
                        status, status_category, is_mine, labels, url,
                        created_at, updated_at, resolved_at,
                        first_seen_at, last_seen_at, run_id)
VALUES (:source_id, :jira_id, :key, :project_key, :issue_type, :summary,
        :status, :status_category, :is_mine, :labels, :url,
        :created_at, :updated_at, :resolved_at, :now, :now, :run_id)
ON CONFLICT (source_id, jira_id) DO UPDATE SET
    key = excluded.key, project_key = excluded.project_key,
    issue_type = excluded.issue_type, summary = excluded.summary,
    status = excluded.status, status_category = excluded.status_category,
    is_mine = max(work_items.is_mine, excluded.is_mine),
    labels = excluded.labels, url = excluded.url,
    updated_at = excluded.updated_at, resolved_at = excluded.resolved_at,
    deleted_at = NULL, run_id = excluded.run_id
WHERE excluded.updated_at > work_items.updated_at
RETURNING id, first_seen_at = :now AS inserted;

UPDATE work_items SET last_seen_at = :now
 WHERE source_id = :source_id AND jira_id = :jira_id;
```

- **No-op when unchanged.** The `WHERE` skips the update when Jira's `updated_at` hasn't moved, so `RETURNING` yields nothing and no event is written. A repeat run in testing returned no row.
- **Created or updated.** `inserted` tells `work_item.created` from `work_item.updated`.
- **Ownership sticks.** `max()` keeps `is_mine` at 1 once you were ever assigned.
- **Seen, not changed.** The separate touch keeps `last_seen_at` current for the deletion sweep.

A sketch of how an app calls the writer, with the transaction and rollback handled by the context manager:

```python
with muninn.run(app="odin", source="jira-dc", stream="issues") as run:
    for issue in jira.search(jql, updated_since=run.cursor):
        row = run.upsert_work_item(issue)        # None when unchanged
        if row:
            run.emit("work_item.created" if row.inserted else "work_item.updated",
                     entity=row, payload=row.changes)
    run.advance_cursor(latest_updated)
```

## Migrations, backup and retention

Schema changes are forward-only numbered SQL files, each applied after an automatic backup, so recovering from a bad migration means restoring the morning's copy.

- **Version.** `PRAGMA user_version` holds the schema version; `muninn_schema.sql` sets it to 1.
- **Files.** Later changes are `migrations/0002_<name>.sql`, `0003_…`, each wrapped in `BEGIN`/`COMMIT` and ending with `PRAGMA user_version = N`. At startup the writer applies any newer files in order; nothing runs backward.
- **Constraint changes.** SQLite's `ALTER TABLE` adds and renames columns but cannot change a CHECK. Those use the create-copy-drop-rename recipe, with `PRAGMA foreign_keys = OFF` around it and `PRAGMA foreign_key_check` after.
- **Backups.** Before every migration, and on the first open each day, the writer runs `VACUUM INTO` to `%LOCALAPPDATA%\Asgard\backups\muninn-YYYYMMDD.db`: a consistent, compacted copy taken while readers keep working.
- **Export.** Valhalla's export is the same `VACUUM INTO` copy, zipped to a folder you pick.

Proposed retention defaults:

| Data | Kept | Why |
| --- | --- | --- |
| Facts: work items, commits, PRs, meetings, BLUFs, submissions | Life of the database | Freya needs at least a full year, and rows are small |
| `events` | Life of the database | Append-only by trigger; history is the point |
| `sync_runs` | 180 days, then pruned | Operational only; facts' `run_id` becomes NULL |
| `reflog_entries` | 1 year | Only recent calibration uses them |
| Transcripts | Never stored | Rule 8 |
| Backups | Last 7 daily copies | Undo window for a bad migration or sync |

Rows are short text, so a year of one engineer's work should stay in the tens of megabytes.

## Open decisions

- [ ] **Jira descriptions.** Freya writes better with them, but they enlarge the CUI footprint. Default: summaries only.
- [ ] **Scope.** One database per engineer (this design), or a team view later? A team view needs a server, which this design avoids.
- [ ] **Raw API payloads.** Keep them for debugging? Default: no, only `sync_runs.error`.
- [ ] **Versions.** Keep every BLUF and review-draft version, or prune superseded ones once a period closes?
- [ ] **Baldur's day.** Which time zone defines a day? Proposed: `meta.timezone`, set by Valkyrie from Windows.
- [ ] **Encryption beyond BitLocker.** SQLCipher needs a compiled extension, which breaks the pure-Python rule.
- [ ] **Retention.** Confirm the defaults above against your records schedule.
