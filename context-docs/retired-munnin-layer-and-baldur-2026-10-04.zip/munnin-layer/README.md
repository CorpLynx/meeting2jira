# Muninn: the writer module

`src/asgard/muninn/` implements the design in [Muninn data layer design.md](Muninn%20data%20layer%20design.md).
It is the only code that should open `muninn.db`. Apps call methods; they never write SQL.

Standard library only (`sqlite3`, `json`, `re`), Python 3.8+. Needs SQLite 3.37+ with FTS5, JSON,
`RETURNING` and `VACUUM INTO`. A preflight probes each of those before any file is created.

```python
from asgard import muninn

with muninn.open("odin") as m:                        # %LOCALAPPDATA%\Asgard\muninn.db
    m.add_identity("jira_user", "bjones")
    with m.run(source="jira-dc", stream="issues", kind="jira") as run:
        for issue in fetched:
            with run.item(issue["key"]):              # one bad issue cannot cost the whole sync
                run.upsert_work_item(issue)           # returns UpsertResult(outcome=created|updated|restored|unchanged)
        run.advance_cursor(latest_updated)
```

`ASGARD_HOME` overrides the data folder (tests, removable media).

## Layout

```
muninn_schema.sql             the design's schema, unchanged
src/asgard/muninn/
  migrations/
    0001_initial.sql          byte-identical copy of muninn_schema.sql (a test enforces it)
    0002_baldur.sql           extracted verbatim from the Baldur spec's SQL block
    0003_approval_order.sql   closes a rule-7 gap found by testing v1 (see below)
  db.py                       paths, preflight, connections, migrations, backups
  store.py                    Muninn: transactions, events, sources, identities, search, housekeeping
  run.py                      a sync run: provenance, cursor, guarded deletion sweep
  odin.py                     Odin's API: work items, transitions, Jira worklogs
  baldur.py                   Baldur's collectors: repos, commits, links, reflog, calendar
  baldur_estimates.py         estimate runs, sessions, day proposals, approval, worklogs
  ownership.py                rule 5 as data: which app may write which table
  timeutil.py redact.py common.py errors.py
tests/                        177 tests, stdlib unittest
```

## How the eight rules are enforced

| Rule | Where |
|---|---|
| 1 One writer | Apps get methods, not SQL. Read-only handles (`read_only=True`) refuse every write. |
| 2 Provenance | Synced facts can only be written inside a `run`, which stamps `source_id`, `run_id`, `first/last_seen_at`. |
| 3 Idempotent | Re-running changes nothing and emits nothing. Soft-delete only; rows are never `DELETE`d. |
| 4 UTC text | `timeutil` converts Jira's `+0000`, Graph's 7-digit fractions and git's offsets. A timestamp with no offset is refused, never guessed. |
| 5 Ownership | `ownership.OWNERS`; a test fails if a migration adds a table without an owner. |
| 6 Append-only events | One event per real change, in the same transaction as the change. Triggers forbid update/delete. |
| 7 People approve | Database triggers (0003) plus the writer: approval needs a person's name, and an app's name is refused. |
| 8 No secrets | Event payloads with credential-shaped keys or values are refused; commit subjects and error text are scrubbed. |

Ownership is a guard against honest mistakes, not a security boundary: SQLite has no per-table
permissions, so anything that can open the file can bypass it. The design accepts this.

## Where this departs from the design, and why

Each item was found by running the design's SQL, not by reading it. Each has a regression test.

1. **Rule 7 had a hole.** v1's CHECKs let a `worklogs` or `blufs` row be inserted straight as
   `posted` with no approval. Migration 0003 adds triggers that refuse it, including posting
   timestamped before approval. Jira-origin worklogs are exempt.
2. **The sample upsert misreports updates as creates.** `first_seen_at = :now AS inserted` is true
   for an update in the same second as the insert, so the wrong event would be written, and events
   cannot be corrected. The writer decides the outcome from what it did.
3. **A deleted issue that comes back unchanged stayed deleted forever.** The `WHERE updated_at >`
   gate blocked the same `UPDATE` that clears `deleted_at`. Now it is `restored`.
4. **Equal-time edits were dropped.** With whole-second timestamps, `>` ignores a second edit in the
   same second. The gate is `>=`; strictly older data is still ignored.
5. **Searching a Jira key crashed.** FTS5 reads `ABC-123` as "ABC minus 123". Queries are quoted per
   word, so what people type never raises.
6. **The conventions table overstates STRICT.** STRICT does not reject an integer into a TEXT column;
   SQLite converts anything losslessly convertible. Types are validated in the writer instead. A test
   pins the real behaviour.

Additions the design leaves open, each in favour of never silently losing data:

- `run.item()` isolates one item in a savepoint; a bad item is recorded and the run ends `partial`.
- A `partial` run does not advance its cursor, so skipped items are fetched again.
- A full sync that sees nothing, or would delete more than half of 10+ rows, is refused. An empty
  API response looks exactly like a mass deletion.
- A run is recorded `failed` even when its data rolls back, so failures stay visible.
- Runs left `running` by a dead process for 6+ hours are marked failed on the next open.

## Two bugs found by stress-testing, now fixed

Both only appear when several apps start at once, which is the normal start of a working day.

- **First run on a fresh machine:** 75 of 90 simultaneous opens failed with "table meta already
  exists". The whole upgrade now runs under one write lock and re-checks the version once it holds
  it. It is also atomic across files, so a failure in 0003 also rolls back 0001 and 0002.
- **The daily backup:** 150 of 180 simultaneous opens on a new day failed to back up, because every
  process wrote the same temporary file. Temp names are now unique per attempt.

## Verifying

```
cd munnin-layer
PYTHONPATH=src python -m unittest discover -s tests -v
```

177 tests pass with `-W error::ResourceWarning`. Mutation testing broke each guard on purpose:
32 of 32 mutants were caught (24 in the writer, 8 in the 0003 triggers). Ruff is clean, and vermin
1.8.0 reports a minimum of Python 3.7.

Everything above ran on macOS with Python 3.14 and SQLite 3.53. **Not yet verified on the target
Windows workstation.** The one real risk is that machine's SQLite: the preflight will say so plainly
if its Python bundles one older than 3.37 or built without FTS5. Run this there first:

```
py -3 -c "import sqlite3; print(sqlite3.sqlite_version)"
```

## Open decisions

- **Submissions cannot be withdrawn from draft.** The design says withdrawn ends a submission "at any
  point", but v1's CHECK requires `approved_at` for every state except draft, so `draft -> withdrawn`
  fails. Fixing it means rebuilding the table. It belongs to Heimdall and Bifrost, so settle it when
  they are built.
- **Baldur's day boundary.** `local_date` comes from the caller. The design's proposal is
  `meta.timezone`, set by Valkyrie; nothing writes it yet.
- The design's own list (Jira descriptions, team scope, raw payloads, versions, encryption,
  retention) is unchanged.
